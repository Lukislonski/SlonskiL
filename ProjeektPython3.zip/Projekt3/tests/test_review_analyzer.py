# tests/test_review_analyzer.py

import unittest
from src.analyzers.review_analyzer import ReviewAnalyzer

class TestReviewAnalyzer(unittest.TestCase):
    def setUp(self):
        self.analyzer = ReviewAnalyzer()

    def test_analyze_review_positive(self):
        review_text = "Wspaniałe widoki! Byłem 15.08.2023, pogoda dopisała, trasa super. Ocena 9/10."
        result = self.analyzer.analyze_review(review_text)
        self.assertEqual(result['sentiment'], 'pozytywny')
        self.assertAlmostEqual(result['rating_normalized'], 4.5) # 9/10 = 4.5/5
        self.assertIn('widoki', result['aspects'])
        self.assertIn('pogoda', result['aspects'])
        self.assertEqual(result['date'], '15.08.2023')
        self.assertEqual(result['season'], 'lato')

    def test_analyze_review_negative(self):
        review_text = "Trasa trudna, kiepskie oznakowanie miejscami. Byłem w lipcu 2022, lało cały dzień. Ocena 2/5."
        result = self.analyzer.analyze_review(review_text)
        self.assertEqual(result['sentiment'], 'negatywny')
        self.assertAlmostEqual(result['rating_normalized'], 2.0)
        self.assertIn('trudność', result['aspects'])
        self.assertIn('oznakowanie', result['aspects'])
        self.assertIn('pogoda', result['aspects'])
        self.assertEqual(result['date'], 'lipcu 2022') # Data wyłapana jako string
        self.assertEqual(result['season'], 'lato')

    def test_analyze_review_neutral(self):
        review_text = "Średnia trasa. Nic specjalnego. Gwiazdki: ★★★."
        result = self.analyzer.analyze_review(review_text)
        self.assertEqual(result['sentiment'], 'neutralny')
        self.assertAlmostEqual(result['rating_normalized'], 3.0)
        self.assertFalse(result['aspects']) # Brak konkretnych aspektów

    def test_extract_ratings(self):
        self.assertAlmostEqual(self.analyzer.analyze_review("Ocena: 4.5/5")['rating_normalized'], 4.5)
        self.assertAlmostEqual(self.analyzer.analyze_review("Daję 7/10")['rating_normalized'], 3.5)
        self.assertAlmostEqual(self.analyzer.analyze_review("To jest ★★★★ trasa")['rating_normalized'], 4.0)
        self.assertIsNone(self.analyzer.analyze_review("Bez oceny")['rating_normalized'])

    def test_get_season_from_date(self):
        self.assertEqual(self.analyzer._get_season_from_date("01.01.2023"), 'zima')
        self.assertEqual(self.analyzer._get_season_from_date("15-04-2024"), 'wiosna')
        self.assertEqual(self.analyzer._get_season_from_date("lipiec 2023"), 'lato')
        self.assertEqual(self.analyzer._get_season_from_date("2023-11-20"), 'jesień')
        self.assertIsNone(self.analyzer._get_season_from_date("nieznana data"))