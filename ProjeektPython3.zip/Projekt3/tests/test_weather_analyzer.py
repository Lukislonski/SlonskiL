# tests/test_weather_analyzer.py

import unittest
from src.models.weather_data import WeatherData
from src.analyzers.weather_analyzer import WeatherAnalyzer
from datetime import date

class TestWeatherAnalyzer(unittest.TestCase):

    def test_is_sunny_day(self):
        sunny_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=0, sunshine_hours=7.0, cloud_cover=20
        )
        analyzer = WeatherAnalyzer(sunny_weather)
        self.assertTrue(analyzer.is_sunny_day())

        cloudy_weather1 = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=0, sunshine_hours=5.9, cloud_cover=20
        )
        analyzer = WeatherAnalyzer(cloudy_weather1)
        self.assertFalse(analyzer.is_sunny_day())

        cloudy_weather2 = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=0, sunshine_hours=7.0, cloud_cover=31
        )
        analyzer = WeatherAnalyzer(cloudy_weather2)
        self.assertFalse(analyzer.is_sunny_day())

        edge_case_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=0, sunshine_hours=6.0, cloud_cover=30
        )
        analyzer = WeatherAnalyzer(edge_case_weather)
        self.assertTrue(analyzer.is_sunny_day())


    def test_is_rainy_day(self):
        rainy_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=1.1, sunshine_hours=0, cloud_cover=100
        )
        analyzer = WeatherAnalyzer(rainy_weather)
        self.assertTrue(analyzer.is_rainy_day())

        no_rain_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=0.0, sunshine_hours=8, cloud_cover=20
        )
        analyzer = WeatherAnalyzer(no_rain_weather)
        self.assertFalse(analyzer.is_rainy_day())

        edge_case_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Test", avg_temp=20, min_temp=15, max_temp=25,
            precipitation=1.0, sunshine_hours=5, cloud_cover=70
        )
        analyzer = WeatherAnalyzer(edge_case_weather)
        self.assertFalse(analyzer.is_rainy_day())


    def test_comfort_index(self):
        ideal_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Ideal", avg_temp=20, min_temp=18, max_temp=22,
            precipitation=0.0, sunshine_hours=8.0, cloud_cover=10
        )
        analyzer = WeatherAnalyzer(ideal_weather)
        self.assertEqual(analyzer.comfort_index(), 100)

        cool_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Cool", avg_temp=17, min_temp=10, max_temp=20,
            precipitation=0.0, sunshine_hours=6.0, cloud_cover=50
        )
        analyzer = WeatherAnalyzer(cool_weather)
        self.assertEqual(analyzer.comfort_index(), 80)

        rainy_warm_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Rainy", avg_temp=25, min_temp=20, max_temp=28,
            precipitation=2.0, sunshine_hours=2.0, cloud_cover=80
        )
        analyzer = WeatherAnalyzer(rainy_warm_weather)
        self.assertEqual(analyzer.comfort_index(), 70)

        bad_weather = WeatherData(
            date=date(2023, 8, 12), location_id="Bad", avg_temp=5, min_temp=0, max_temp=10,
            precipitation=10.0, sunshine_hours=0.0, cloud_cover=90
        )
        analyzer = WeatherAnalyzer(bad_weather)
        self.assertEqual(analyzer.comfort_index(), 45)

        very_bad_weather = WeatherData(
            date=date(2023, 8, 12), location_id="VeryBad", avg_temp=0, min_temp=-5, max_temp=5,
            precipitation=20.0, sunshine_hours=0.0, cloud_cover=100
        )
        analyzer = WeatherAnalyzer(very_bad_weather)
        index = analyzer.comfort_index()
        self.assertGreaterEqual(index, 0)
        self.assertLessEqual(index, 100)