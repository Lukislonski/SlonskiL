#src/extractors/html_route_extractor.py
import re
from bs4 import BeautifulSoup

class HTMLRouteExtractor:
    def extract_route_data(self, html_content, rules):
        if not html_content or not rules:
            print("Błąd: Brak treści HTML lub reguł do ekstrakcji.")
            return {}

        soup = BeautifulSoup(html_content, 'html.parser')
        extracted_data = {}
        for field, rule_config in rules.items():
            selector = rule_config.get('selector')
            extract_type = rule_config.get('type')
            regex = rule_config.get('regex')

            if not selector:
                continue

            if extract_type == 'text':
                element = soup.select_one(selector)
                if element:
                    text_content = element.get_text(strip=True)
                    if regex:
                        match = re.search(regex, text_content)
                        if match:
                            extracted_data[field] = match.group(1).strip() if len(match.groups()) > 0 else text_content
                        else:
                            extracted_data[field] = None
                    else:
                        extracted_data[field] = text_content
                else:
                    extracted_data[field] = None

            elif extract_type == 'list':
                elements = soup.select(selector)
                if elements:
                    item_rules = rule_config.get('item_rules', {})
                    extracted_list = []
                    for item_element in elements:
                        item_data = {}
                        for item_field, item_rule_config in item_rules.items():
                            item_selector = item_rule_config.get('selector')
                            item_regex = item_rule_config.get('regex')
                            if item_selector:
                                sub_element = item_element.select_one(item_selector)
                                if sub_element:
                                    text_content = sub_element.get_text(strip=True)
                                    if item_regex:
                                        match = re.search(item_regex, text_content)
                                        if match:
                                            item_data[item_field] = match.group(1).strip() if len(match.groups()) > 0 else text_content
                                        else:
                                            item_data[item_field] = None
                                    else:
                                        item_data[item_field] = text_content
                                else:
                                    item_data[item_field] = None
                        if item_data:
                            extracted_list.append(item_data)
                    extracted_data[field] = extracted_list
                else:
                    extracted_data[field] = []
        # Długość
        if 'length_km' in extracted_data and extracted_data['length_km'] is not None:
            try:
                extracted_data['length_km'] = float(extracted_data['length_km'].replace(',', '.'))
            except (ValueError, TypeError):
                extracted_data['length_km'] = None

        # Przewyższenie
        if 'elevation_gain' in extracted_data and extracted_data['elevation_gain'] is not None:
            try:
                extracted_data['elevation_gain'] = int(extracted_data['elevation_gain'])
            except (ValueError, TypeError):
                extracted_data['elevation_gain'] = None

        # Trudność
        if 'difficulty' in extracted_data and extracted_data['difficulty'] is not None:
            try:
                extracted_data['difficulty'] = int(extracted_data['difficulty'])
            except (ValueError, TypeError):
                extracted_data['difficulty'] = None
        
        return extracted_data