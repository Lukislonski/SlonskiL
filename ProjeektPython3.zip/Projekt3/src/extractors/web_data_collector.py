#src/extractors/web_data_collerctor.py
import os
import json
import requests
from datetime import datetime, timedelta

class WebDataCollector:
    def __init__(self, cache_dir="cache", cache_expiry_hours=24):
        self.cache_dir = cache_dir
        self.cache_expiry = timedelta(hours=cache_expiry_hours)
        os.makedirs(self.cache_dir, exist_ok=True)

    def _get_cache_filepath(self, identifier, extension):
        safe_id = identifier.replace("/", "_").replace(":", "_")
        return os.path.join(self.cache_dir, f"{safe_id}.{extension}")

    def _is_cache_valid(self, filepath):
        if not os.path.exists(filepath):
            return False
        file_mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
        if datetime.now() - file_mtime > self.cache_expiry:
            return False
        return True

    def fetch_html(self, url, filename):
        filepath = os.path.join(self.cache_dir, filename)
        if self._is_cache_valid(filepath):
            print(f"Pobieranie HTML z cache: {filepath}")
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        print(f"Pobieranie HTML z sieci: {url}")
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(response.text)
            return response.text
        except requests.RequestException as e:
            print(f"Błąd pobierania HTML: {e}")
            return None

    def fetch_json_from_api(self, api_url, identifier, params=None, headers=None):
        filepath = self._get_cache_filepath(identifier, 'json')
        if self._is_cache_valid(filepath):
            print(f"Pobieranie JSON z cache: {filepath}")
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"Błąd dekodowania JSON z pliku cache, pobieram ponownie")
                os.remove(filepath)

        print(f"Pobieranie JSON z API: {api_url}")
        try:
            response = requests.get(api_url, params=params, headers=headers, timeout=10)
            response.raise_for_status()
            json_data = response.json()
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4)
            return json_data
        except requests.RequestException as e:
            print(f"Błąd pobierania JSON z API: {e}")
            return None

    def fetch_json_post(self, api_url, identifier, json_body=None, headers=None):
        filepath = self._get_cache_filepath(identifier, 'json')
        if self._is_cache_valid(filepath):
            print(f"Pobieranie JSON (POST) z cache: {filepath}")
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"Błąd dekodowania JSON z cache, pobieram ponownie")
                os.remove(filepath)

        print(f"Pobieranie JSON (POST) z API: {api_url}")
        try:
            response = requests.post(api_url, json=json_body, headers=headers, timeout=10)
            response.raise_for_status()
            json_data = response.json()
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4)
            return json_data
        except requests.RequestException as e:
            print(f"Błąd pobierania JSON (POST) z API: {e}")
            return None
