# src/analyzers/review_analyzer.py

import re
from typing import List, Dict, Any, Optional
from datetime import datetime

class ReviewAnalyzer:
    """
    Klasa do analizy recenzji użytkowników, w tym sentymentu, ocen,
    wspominanych aspektów oraz dat i sezonowości.
    """
    _RATING_PATTERNS = r'(\d(?:\.\d)?)/5|(\d{1,2})/10|★{1,5}'
    _DATE_PATTERNS = r'(\d{1,2}[-./]\d{1,2}[-./]\d{2,4})|(\b(?:styczeń|luty|marzec|kwiecień|maj|czerwiec|lipiec|sierpień|wrzesień|październik|listopad|grudzień)\s+\d{4}\b)'

    _POSITIVE_KEYWORDS = ['wspaniałe', 'super', 'piękne', 'cudowne', 'świetne', 'polecam', 'dobrze', 'fajne', 'zachwycające', 'świetna']
    _NEGATIVE_KEYWORDS = ['trudna', 'kiepskie', 'złe', 'słabe', 'problemy', 'nie polecam', 'męczące', 'nudne', 'rozczarowanie', 'lało']
    _ASPECT_KEYWORDS = {
        'widoki': ['widoki', 'krajobrazy', 'panorama', 'widok', 'góry'],
        'trudność': ['trudność', 'wymagająca', 'łatwa', 'ciężka', 'kondycja'],
        'oznakowanie': ['oznakowanie', 'szlak', 'oznaczenia', 'zgubić się'],
        'pogoda': ['pogoda', 'słońce', 'deszcz', 'śnieg', 'upał', 'zimno', 'lało'],
        'atrakcje': ['atrakcje', 'ciekawe miejsca', 'interesujące', 'coś zobaczyć']
    }

    def analyze_review(self, review_text: str) -> Dict[str, Any]:
        """
        Analizuje pojedynczą recenzję i zwraca słownik z wyekstrahowanymi danymi.
        """
        analysis = {
            'text': review_text,
            'rating_raw': None,
            'rating_normalized': None,
            'sentiment': 'neutralny',
            'aspects': [],
            'date': None,
            'season': None
        }
        rating_match = re.search(self._RATING_PATTERNS, review_text)
        if rating_match:
            analysis['rating_raw'] = rating_match.group(0)
            if '/5' in analysis['rating_raw']:
                analysis['rating_normalized'] = float(analysis['rating_raw'].replace('/5', ''))
            elif '/10' in analysis['rating_raw']:
                analysis['rating_normalized'] = float(analysis['rating_raw'].replace('/10', '')) / 2
            elif '★' in analysis['rating_raw']:
                analysis['rating_normalized'] = analysis['rating_raw'].count('★')

        positive_score = sum(1 for kw in self._POSITIVE_KEYWORDS if kw in review_text.lower())
        negative_score = sum(1 for kw in self._NEGATIVE_KEYWORDS if kw in review_text.lower())

        if positive_score > negative_score:
            analysis['sentiment'] = 'pozytywny'
        elif negative_score > positive_score:
            analysis['sentiment'] = 'negatywny'

        found_aspects = set()
        for aspect_name, keywords in self._ASPECT_KEYWORDS.items():
            if any(kw in review_text.lower() for kw in keywords):
                found_aspects.add(aspect_name)
        analysis['aspects'] = list(found_aspects)

        date_match = re.search(self._DATE_PATTERNS, review_text, re.IGNORECASE)
        if date_match:
            date_str = date_match.group(0)
            analysis['date'] = date_str
            analysis['season'] = self._get_season_from_date(date_str)

        return analysis

    def _get_season_from_date(self, date_str: str) -> Optional[str]:
        """Próbuje określić sezon na podstawie stringa z datą."""
        try:
            for fmt in ['%d.%m.%Y', '%d/%m/%Y', '%d-%m-%Y', '%Y-%m-%d']:
                try:
                    dt_obj = datetime.strptime(date_str, fmt)
                    month = dt_obj.month
                    break
                except ValueError:
                    pass
            else:
                month_map = {
                    'styczeń': 1, 'luty': 2, 'marzec': 3, 'kwiecień': 4,
                    'maj': 5, 'czerwiec': 6, 'lipiec': 7, 'sierpień': 8,
                    'wrzesień': 9, 'październik': 10, 'listopad': 11, 'grudzień': 12
                }
                month_name_match = re.search(r'\b(styczeń|luty|marzec|kwiecień|maj|czerwiec|lipiec|sierpień|wrzesień|październik|listopad|grudzień)\b', date_str, re.IGNORECASE)
                if month_name_match:
                    month = month_map.get(month_name_match.group(1).lower())
                else:
                    return None

            if 3 <= month <= 5:
                return 'wiosna'
            elif 6 <= month <= 8:
                return 'lato'
            elif 9 <= month <= 11:
                return 'jesień'
            elif month == 12 or month <= 2:
                return 'zima'
        except Exception:
            pass
        return None