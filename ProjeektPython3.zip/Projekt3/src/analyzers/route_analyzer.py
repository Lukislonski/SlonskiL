# src/analyzers/route_analyzer.py

from src.models.route import Route
from typing import List

class RouteAnalyzer:
    """
    Przeprowadza analizę pojedynczej trasy, np. szacuje czas przejścia
    i kategoryzuje trasę.
    """
    def __init__(self, route: Route):
        self.route = route

    def estimate_travel_time(self) -> float:
        """
        Szacuje czas przejścia trasy w minutach, uwzględniając typ terenu,
        długość, przewyższenie i trudność.
        """
        base_speed_km_h = self._get_base_speed(self.route.terrain_type)
        if base_speed_km_h == 0:
            return 0.0

        time_distance_min = (self.route.length_km / base_speed_km_h) * 60
        time_elevation_min = (self.route.elevation_gain / 10)

        difficulty_multiplier = self._get_difficulty_factor(self.route.difficulty)

        total_time_min = (time_distance_min + time_elevation_min) * difficulty_multiplier
        return round(total_time_min)

    def categorize_route(self) -> List[str]:
        categories = []
        tags = set(self.route.tags)

        if self.route.difficulty <= 2 and self.route.length_km <= 8 and self.route.elevation_gain < 100:
            categories.append("Rodzinna")

        if "viewpoint" in tags or "scenic" in tags:
            categories.append("Widokowa")

        if self.route.difficulty >= 3 or self.route.elevation_gain >= 300:
            categories.append("Sportowa")

        if self.route.difficulty >= 4 or "alpine" in tags:
            categories.append("Ekstremalna")

        if not categories:
            categories.append("Ogólna")

        return categories

    def _get_base_speed(self, terrain_type: str) -> float:
        """Zwraca bazową prędkość przejścia (km/h) dla danego typu terenu."""
        speeds = {
            "coastal": 5.0,
            "forest": 4.0,
            "urban-hill": 4.0,
            "urban-wild": 4.0,
            "lake": 4.0,
            "mountain": 3.0,
            "dunes": 3.5,
            "rails": 4.5,
        }
        return speeds.get(terrain_type.lower(), 4.0)

    def _get_difficulty_factor(self, difficulty: int) -> float:
        """Zwraca mnożnik trudności trasy."""
        factors = {
            1: 1.0,
            2: 1.2,
            3: 1.5,
            4: 1.7,
            5: 1.9
        }
        return factors.get(difficulty, 1.0)