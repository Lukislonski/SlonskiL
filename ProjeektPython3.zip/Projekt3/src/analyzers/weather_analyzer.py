# src/analyzers/weather_analyzer.py

from src.models.weather_data import WeatherData

class WeatherAnalyzer:
    """
    Przeprowadza analizę danych pogodowych, np. sprawdza warunki słoneczne/deszczowe
    i oblicza indeks komfortu pogodowego.
    """
    def __init__(self, weather_data: WeatherData):
        self.weather = weather_data

    def is_sunny_day(self) -> bool:
        """Sprawdza, czy dzień spełnia kryteria słonecznego dnia."""
        return self.weather.sunshine_hours >= 6.0 and self.weather.cloud_cover <= 30

    def is_rainy_day(self) -> bool:
        """Sprawdza, czy dzień spełnia kryteria deszczowego dnia."""
        return self.weather.precipitation > 1.0

    def comfort_index(self) -> int:
        """
        Oblicza indeks komfortu pogodowego na podstawie temperatury, opadów i zachmurzenia.
        Wynik w skali 0-100.
        """
        score = 100

        # Temperatura
        if self.weather.avg_temp < 16 or self.weather.avg_temp > 26:
            score -= 15
        elif self.weather.avg_temp < 18 or self.weather.avg_temp > 24:
            score -= 5

        # Opady
        if self.weather.precipitation > 5.0:
            score -= 25
        elif self.weather.precipitation > 1.0:
            score -= 10

        # Zachmurzenie
        if self.weather.cloud_cover > 70:
            score -= 15
        elif self.weather.cloud_cover > 40:
            score -= 5

        return max(0, min(score, 100))