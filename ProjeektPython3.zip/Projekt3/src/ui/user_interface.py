# src/ui/user_interface.py
from typing import List, Dict, Any, Optional
from src.models.user_preferences import UserPreferences

class UserInterface:
    """
    Klasa odpowiedzialna za interakcję z użytkownikiem,
    taką jak pobieranie preferencji i wyświetlanie rekomendacji.
    """

    def get_user_preferences(self) -> UserPreferences:
        """
        Pobiera preferencje użytkownika dotyczące tras.
        """
        print("\n--- Podaj swoje preferencje dotyczące tras ---")
        
        preferred_temperature = self._get_float_input("Podaj preferowaną temperaturę (np. 20.5, pozostaw puste aby pominąć): ")
        max_precipitation = self._get_float_input("Podaj dopuszczalne opady (w mm, 0.0 dla braku opadów, pozostaw puste aby pominąć): ")
        max_difficulty = self._get_int_input("Podaj maksymalną trudność trasy (1-5, pozostaw puste aby pominąć): ")
        max_length_km = self._get_float_input("Podaj maksymalną długość trasy (w km, np. 15.0, pozostaw puste aby pominąć): ")

        preferences = UserPreferences(
            preferred_temperature=preferred_temperature,
            max_precipitation=max_precipitation,
            max_difficulty=max_difficulty,
            max_length_km=max_length_km
        )
        print("\nTwoje preferencje zostały zapisane.")
        return preferences

    def _get_float_input(self, prompt: str) -> Optional[float]:
        while True:
            value = input(prompt).strip()
            if value == "":
                return None
            try:
                return float(value)
            except ValueError:
                print("Nieprawidłowy format. Podaj liczbę lub pozostaw puste.")

    def _get_int_input(self, prompt: str) -> Optional[int]:
        while True:
            value = input(prompt).strip()
            if value == "":
                return None
            try:
                return int(value)
            except ValueError:
                print("Nieprawidłowy format. Podaj liczbę całkowitą lub pozostaw puste.")

    def display_recommendations(self, recommendations: List[Dict[str, Any]]):
        """Wyświetla rekomendowane trasy w konsoli."""
        if not recommendations:
            print("Brak rekomendacji tras spełniających Twoje kryteria.")
            return

        print("\n--- Rekomendowane Trasy ---")
        for i, route_info in enumerate(recommendations):
            description = route_info.get("description", "")
            
            if len(description) > 150:
                description = description[:147] + "..."

            print(f"\n{i+1}. {route_info.get('name', 'N/A')}")
            print(f"  Region: {route_info.get('region', 'N/A')}")
            print(f"  Długość: {route_info.get('length_km', 'N/A')} km")
            print(f"  Przewyższenie: {route_info.get('elevation_gain', 'N/A')} m")
            print(f"  Trudność: {route_info.get('difficulty', 'N/A')}/5")
            print(f"  Typ terenu: {route_info.get('terrain_type', 'N/A')}")
            print(f"  Tagi: {', '.join(route_info.get('tags', []))}")
            print(f"  Opis: {description}")
            
            num_reviews = route_info.get('num_reviews', 0)
            print(f"  Liczba recenzji: {num_reviews}")

            if num_reviews > 0:
                print(f"  Średnia ocena z recenzji (0-1): {route_info.get('avg_review_rating', 0.0):.2f}")
                print(f"  Wynik sentymentu (pozytywne/negatywne): {route_info.get('overall_sentiment_score', 0.0):.2f}")
                
                aspect_mentions = route_info.get('aspect_mentions', {})
                if aspect_mentions:
                    print("  Wzmianki o aspektach w recenzjach:")
                    for aspect, count in aspect_mentions.items():
                        print(f"    - {aspect}: {count}")
            else:
                print("  Brak recenzji do wyświetlenia.")
            
            current_weather = route_info.get('current_weather')
            if current_weather:
                print("  Aktualna pogoda w regionie (pobrana z API):")
                print(f"    Temperatura: {current_weather.get('avg_temp', 'N/A')}°C")
                print(f"    Opady: {current_weather.get('precipitation', 'N/A')} mm")
                print(f"    Opis: {current_weather.get('weather_description', 'N/A')}")
            else:
                print("  Brak danych o aktualnej pogodzie dla tej trasy.")

            extracted_times = route_info.get('extracted_times', [])
            if extracted_times:
                print(f"  Wyodrębnione czasy (surowe): {extracted_times}")
            
            extracted_times_minutes = route_info.get('extracted_times_minutes')
            if extracted_times_minutes is not None and extracted_times_minutes > 0:
                print(f"  Szacowany czas (minuty): {extracted_times_minutes:.0f} min")
            else:
                print(f"  Szacowany czas (minuty): N/A min")

            characteristic_points = route_info.get('characteristic_points', [])
            if characteristic_points:
                print(f"  Punkty charakterystyczne: {', '.join(characteristic_points)}")
            
            warnings = route_info.get('warnings', [])
            if warnings:
                print(f"  Ostrzeżenia: {', '.join(warnings)}")

            extracted_coords = route_info.get('extracted_coords')
            if extracted_coords:
                if isinstance(extracted_coords, str):
                    print(f"  Wyodrębnione współrzędne: {extracted_coords}")
                elif isinstance(extracted_coords, list) and all(isinstance(coord_pair, tuple) for coord_pair in extracted_coords):
                    formatted_coords = [f"({lat}, {lon})" for lat, lon in extracted_coords]
                    print(f"  Wyodrębnione współrzędne: {', '.join(formatted_coords)}")
                else:
                    print(f"  Wyodrębnione współrzędne: N/A (nieoczekiwany format: {type(extracted_coords)})")
            else:
                print(f"  Wyodrębnione współrzędne: Brak")


            extracted_elevations = route_info.get('extracted_elevations', [])
            if extracted_elevations:
                print(f"  Wyodrębnione wysokości (m n.p.m.): {extracted_elevations}")
            
            print("-" * 30)