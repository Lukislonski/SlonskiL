# src/recommenders/route_recommender.py
import pandas as pd
from typing import List, Dict, Any, Optional
from datetime import date
from src.models.route import Route
from src.models.weather_data import WeatherData
from src.models.user_preferences import UserPreferences
from src.services.weather_service import WeatherService

class RouteRecommender:
    def __init__(self, routes: List[Route], weather_data: List[WeatherData]):
        self.routes = routes
        self.weather_df = self._create_weather_dataframe(weather_data)
        self.weather_service = WeatherService()
        self.temperature_tolerance = 5

    def _create_weather_dataframe(self, weather_data: List[WeatherData]) -> pd.DataFrame:
        if not weather_data:
            print("  [RouteRecommender] Brak danych pogodowych (historycznych/plikowych) do utworzenia DataFrame.")
            return pd.DataFrame()
        
        data = []
        for wd in weather_data:
            data.append({
                'date': wd.date,
                'location_id': wd.location_id,
                'avg_temp': wd.avg_temp,
                'min_temp': wd.min_temp,
                'max_temp': wd.max_temp,
                'precipitation': wd.precipitation,
                'sunshine_hours': wd.sunshine_hours,
                'cloud_cover': wd.cloud_cover,
                'wind_speed': wd.wind_speed,
                'weather_description': wd.weather_description,
                'humidity': wd.humidity,
                'pressure': wd.pressure
            })
        df = pd.DataFrame(data)
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date']).dt.date
        print(f"  [RouteRecommender] Utworzono DataFrame pogodowy z {len(df)} rekordów (z CSV).")
        return df

    def get_weather_for_location_from_csv(self, location_id: str, target_date: date) -> Optional[WeatherData]:

        if self.weather_df.empty:
            print(f"  [RouteRecommender] DataFrame pogodowy jest pusty. Nie można pobrać danych dla {location_id} z CSV.")
            return None
        
        if not isinstance(target_date, date):
            if isinstance(target_date, pd.Timestamp):
                target_date = target_date.date()
            else:
                try:
                    target_date = date.fromisoformat(str(target_date))
                except (ValueError, TypeError):
                    print(f"  [RouteRecommender] Nieprawidłowy format daty: {target_date} dla {location_id}.")
                    return None

        filtered_weather = self.weather_df[
            (self.weather_df['location_id'] == location_id) & 
            (self.weather_df['date'] == target_date)
        ]
        
        if not filtered_weather.empty:
            row = filtered_weather.iloc[0]
            print(f"  [RouteRecommender] Pobrano pogodę z CSV dla {location_id} ({target_date}): Temp={row['avg_temp']}, Opady={row['precipitation']}")
            return WeatherData(
                date=row['date'],
                location_id=row['location_id'],
                avg_temp=row['avg_temp'],
                min_temp=row['min_temp'],
                max_temp=row['max_temp'],
                precipitation=row['precipitation'],
                sunshine_hours=row['sunshine_hours'],
                cloud_cover=row['cloud_cover'],
                wind_speed=row['wind_speed'],
                weather_description=row['weather_description'],
                humidity=row['humidity'],
                pressure=row['pressure']
            )
        print(f"  [RouteRecommender] Brak danych pogodowych w CSV dla {location_id} na dzień {target_date}.")
        return None

    def generate_recommendations(self, preferences: UserPreferences) -> List[Dict[str, Any]]:
        """
        Generuje rekomendacje tras na podstawie preferencji użytkownika,
        uwzględniając aktualną pogodę z API.
        """
        recommended_routes = []
        
        print("\n--- [RouteRecommender] Rozpoczynam generowanie rekomendacji ---")
        print(f"  [RouteRecommender] Preferencje użytkownika: Temp={preferences.preferred_temperature}°C, Opady={preferences.max_precipitation}mm, Trudność<={preferences.max_difficulty}, Długość<={preferences.max_length_km}km")

        for route in self.routes:
            route_info = {
                "id": route.id,
                "name": route.name,
                "region": route.region,
                "length_km": route.length_km,
                "elevation_gain": route.elevation_gain,
                "difficulty": route.difficulty,
                "terrain_type": route.terrain_type,
                "tags": route.tags,
                "description": route.description if route.description is not None else "", 
                "num_reviews": len(route.reviews) if route.reviews else 0,
                "avg_review_rating": 0.0,
                "overall_sentiment_score": 0.0,
                "positive_reviews_count": 0,
                "negative_reviews_count": 0,
                "aspect_mentions": {},
                "extracted_times": route.extracted_times,
                "extracted_times_minutes": route.extracted_times_minutes,
                "characteristic_points": route.characteristic_points,
                "warnings": route.warnings,
                "extracted_coords": route.extracted_coords,
                "extracted_elevations": route.extracted_elevations,
                "current_weather": None
            }

            print(f"\n  [RouteRecommender] Analizuję trasę: '{route.name}' (ID: {route.id}, Region: {route.region})")

            # Filtr 1: Trudność
            if preferences.max_difficulty is not None:
                if route.difficulty is None:
                    print(f"    [RouteRecommender] OSTRZEŻENIE: Brak danych o trudności dla trasy '{route.name}'. Pomijam filtr trudności.")
                elif route.difficulty > preferences.max_difficulty:
                    print(f"    [RouteRecommender] ODRZUCONO: Trudność ({route.difficulty}) > preferowana maks. ({preferences.max_difficulty}).")
                    continue

            # Filtr 2: Długość
            if preferences.max_length_km is not None:
                if route.length_km is None:
                    print(f"    [RouteRecommender] OSTRZEŻENIE: Brak danych o długości dla trasy '{route.name}'. Pomijam filtr długości.")
                elif route.length_km > preferences.max_length_km:
                    print(f"    [RouteRecommender] ODRZUCONO: Długość ({route.length_km} km) > preferowana maks. ({preferences.max_length_km} km).")
                    continue

            current_weather_data_from_api = None
            if route.start_lat is not None and route.start_lon is not None:
                current_weather_data_from_api = self.weather_service.get_current_weather_for_coords(route.start_lat, route.start_lon)
            else:
                print(f"    [RouteRecommender] Brak współrzędnych startowych dla trasy '{route.name}'. Nie można pobrać aktualnej pogody z API.")

            weather_meets_criteria = True
            if preferences.preferred_temperature is not None or preferences.max_precipitation is not None:
                if current_weather_data_from_api:
                    avg_temp = current_weather_data_from_api.get('avg_temp')
                    precipitation = current_weather_data_from_api.get('precipitation')

                    # Filtr 3a: Temperatura
                    if preferences.preferred_temperature is not None and avg_temp is not None:
                        temp_diff = abs(avg_temp - preferences.preferred_temperature)
                        if temp_diff > self.temperature_tolerance:
                            print(f"    [RouteRecommender] ODRZUCONO (Pogoda): Temp. ({avg_temp}°C) poza tolerancją (+/- {self.temperature_tolerance}°C) od preferowanej ({preferences.preferred_temperature}°C).")
                            weather_meets_criteria = False
                        else:
                            print(f"    [RouteRecommender] Pogoda (temp): OK ({avg_temp}°C, różnica: {temp_diff:.1f}°C).")
                    elif preferences.preferred_temperature is not None:
                         print(f"    [RouteRecommender] ODRZUCONO (Pogoda): Preferowana temperatura ustawiona, ale brak danych temperatury z API dla tej trasy.")
                         weather_meets_criteria = False

                    # Filtr 3b: Opady
                    if weather_meets_criteria and preferences.max_precipitation is not None and precipitation is not None:
                        if precipitation > preferences.max_precipitation:
                            print(f"    [RouteRecommender] ODRZUCONO (Pogoda): Opady ({precipitation}mm) > preferowane maks. ({preferences.max_precipitation}mm).")
                            weather_meets_criteria = False
                        else:
                            print(f"    [RouteRecommender] Pogoda (opady): OK ({precipitation}mm <= {preferences.max_precipitation}mm).")
                    elif weather_meets_criteria and preferences.max_precipitation is not None:
                        print(f"    [RouteRecommender] ODRZUCONO (Pogoda): Preferowane opady ustawione, ale brak danych opadów z API dla tej trasy.")
                        weather_meets_criteria = False

                else:
                    print(f"    [RouteRecommender] ODRZUCONO (Pogoda): Brak aktualnych danych pogodowych z API dla trasy '{route.name}', a preferencje pogodowe są ustawione.")
                    weather_meets_criteria = False
            else:
                print("    [RouteRecommender] Brak preferencji pogodowych użytkownika. Pomijam filtr pogodowy.")


            if not weather_meets_criteria:
                continue

            avg_review_rating = 0.0
            total_sentiment = 0.0
            positive_reviews_count = 0
            negative_reviews_count = 0
            aspect_mentions: Dict[str, int] = {} 
            overall_sentiment_score = 0.0 

            if route.reviews:
                valid_ratings_count = 0
                for review in route.reviews:
                    if 'rating_normalized' in review and review['rating_normalized'] is not None:
                        avg_review_rating += review['rating_normalized']
                        valid_ratings_count += 1
                    
                    if 'sentiment' in review:
                        if review['sentiment'] == 'positive':
                            total_sentiment += 1
                            positive_reviews_count += 1
                        elif review['sentiment'] == 'negative':
                            total_sentiment -= 1
                            negative_reviews_count += 1
                    
                    if 'aspects' in review and isinstance(review['aspects'], dict):
                        for aspect, mentions_count in review['aspects'].items():
                            aspect_mentions[aspect] = aspect_mentions.get(aspect, 0) + mentions_count
                    elif 'aspects' in review and isinstance(review['aspects'], list):
                        for aspect in review['aspects']:
                             aspect_mentions[aspect] = aspect_mentions.get(aspect, 0) + 1

                if valid_ratings_count > 0:
                    avg_review_rating /= valid_ratings_count
                
                overall_sentiment_score = total_sentiment / len(route.reviews)
            
            comfort_index = 0.0
            
            # Wpływ trudności (im niższa trudność, tym wyższy komfort)
            if route.difficulty is not None:
                comfort_index += (6 - route.difficulty) * 0.5
            
            # Wpływ długości (im krótsza, tym większy komfort, do pewnego stopnia)
            if route.length_km is not None and route.length_km > 0:
                comfort_index += max(0, 5 - (route.length_km / 5)) 
                
            # Wpływ pogody
            if current_weather_data_from_api and preferences.preferred_temperature is not None:
                avg_temp = current_weather_data_from_api.get('avg_temp')
                if avg_temp is not None:
                    temp_diff = abs(avg_temp - preferences.preferred_temperature)
                    comfort_index += max(0, 2 - (temp_diff / self.temperature_tolerance) * 2)
            elif preferences.preferred_temperature is None:
                if current_weather_data_from_api and current_weather_data_from_api.get('avg_temp') is not None:
                    comfort_index += 1.0
            
            # Wpływ sentymentu z recenzji
            if route_info["num_reviews"] > 0:
                comfort_index += overall_sentiment_score * 1.5

            if route.warnings:
                comfort_index -= len(route.warnings) * 0.5

            comfort_index = max(0, min(10, comfort_index))

            route_info.update({
                "avg_review_rating": round(avg_review_rating, 2),
                "overall_sentiment_score": round(overall_sentiment_score, 2), 
                "positive_reviews_count": positive_reviews_count,
                "negative_reviews_count": negative_reviews_count,
                "aspect_mentions": aspect_mentions,
                "current_weather": current_weather_data_from_api,
                "comfort_index": round(comfort_index, 2)
            })

            recommended_routes.append(route_info)
            print(f"    [RouteRecommender] TRASA ZAAKCEPTOWANA: '{route.name}'. Comfort Index: {route_info['comfort_index']:.2f}")
        
        # Sortowanie rekomendacji
        recommended_routes.sort(key=lambda x: x.get("avg_review_rating", 0), reverse=True)
        print(f"\n--- [RouteRecommender] Zakończono generowanie rekomendacji. Znaleziono: {len(recommended_routes)} tras. ---")
        return recommended_routes