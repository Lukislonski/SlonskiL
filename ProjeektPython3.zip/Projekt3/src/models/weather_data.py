# src/models/weather_data.py
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

@dataclass
class WeatherData:
    """
    Reprezentuje dane pogodowe dla określonej lokalizacji i daty.
    """
    date: date
    location_id: str
    avg_temp: Optional[float] = None
    min_temp: Optional[float] = None
    max_temp: Optional[float] = None
    precipitation: Optional[float] = None  # Opady, np. w mm
    sunshine_hours: Optional[float] = None # Godziny słoneczne
    cloud_cover: Optional[int] = None      # Zachmurzenie w procentach (0-100)
    wind_speed: Optional[float] = None     # Prędkość wiatru, np. w km/h
    weather_description: Optional[str] = None # Opis tekstowy pogody
    humidity: Optional[int] = None
    pressure: Optional[int] = None

    def __post_init__(self):
        # Konwersja na float dla temperatur i opadów, jeśli nie są None
        if self.avg_temp is not None:
            try:
                self.avg_temp = float(self.avg_temp)
            except (ValueError, TypeError):
                self.avg_temp = None

        if self.min_temp is not None:
            try:
                self.min_temp = float(self.min_temp)
            except (ValueError, TypeError):
                self.min_temp = None

        if self.max_temp is not None:
            try:
                self.max_temp = float(self.max_temp)
            except (ValueError, TypeError):
                self.max_temp = None

        if self.precipitation is not None:
            try:
                self.precipitation = float(self.precipitation)
            except (ValueError, TypeError):
                self.precipitation = None

        if self.sunshine_hours is not None:
            try:
                self.sunshine_hours = float(self.sunshine_hours)
            except (ValueError, TypeError):
                self.sunshine_hours = None

        if self.cloud_cover is not None:
            try:
                self.cloud_cover = int(self.cloud_cover)
            except (ValueError, TypeError):
                self.cloud_cover = None

        if self.wind_speed is not None:
            try:
                self.wind_speed = float(self.wind_speed)
            except (ValueError, TypeError):
                self.wind_speed = None

        if self.humidity is not None:
            try:
                self.humidity = int(self.humidity)
            except (ValueError, TypeError):
                self.humidity = None

        if self.pressure is not None:
            try:
                self.pressure = int(self.pressure)
            except (ValueError, TypeError):
                self.pressure = None


    def to_dict(self):
        return {
            "date": self.date.isoformat() if self.date else None,
            "location_id": self.location_id,
            "avg_temp": self.avg_temp,
            "min_temp": self.min_temp,
            "max_temp": self.max_temp,
            "precipitation": self.precipitation,
            "sunshine_hours": self.sunshine_hours,
            "cloud_cover": self.cloud_cover,
            "wind_speed": self.wind_speed,
            "weather_description": self.weather_description,
            "humidity": self.humidity,
            "pressure": self.pressure
        }

    @classmethod
    def from_dict(cls, data: dict):
        _date = date.fromisoformat(data['date']) if data.get('date') else None
        return cls(
            date=_date,
            location_id=data.get('location_id'),
            avg_temp=data.get('avg_temp'),
            min_temp=data.get('min_temp'),
            max_temp=data.get('max_temp'),
            precipitation=data.get('precipitation'),
            sunshine_hours=data.get('sunshine_hours'),
            cloud_cover=data.get('cloud_cover'),
            wind_speed=data.get('wind_speed'),
            weather_description=data.get('weather_description'),
            humidity=data.get('humidity'),
            pressure=data.get('pressure')
        )

    def __str__(self):
        return (f"Pogoda dla {self.location_id} w dniu {self.date}: "
                f"Temp: {self.avg_temp}°C (min: {self.min_temp}°C, max: {self.max_temp}°C), "
                f"Opady: {self.precipitation}mm, Zachmurzenie: {self.cloud_cover}%, "
                f"Wiatr: {self.wind_speed} km/h, Opis: {self.weather_description}")