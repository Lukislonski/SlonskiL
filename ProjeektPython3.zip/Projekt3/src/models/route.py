# src/models/route.py
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Any, Dict
import json

@dataclass
class Route:
    id: int
    name: str
    region: str
    start_lat: float
    start_lon: float
    end_lat: float
    end_lon: float
    length_km: Optional[float] = None
    elevation_gain: Optional[int] = None
    difficulty: Optional[int] = None
    terrain_type: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    description: Optional[str] = None
    
    # Recenzje użytkowników
    reviews: List[Dict[str, Any]] = field(default_factory=list) 

    extracted_times: List[str] = field(default_factory=list)           # Surowe formaty czasów (np. "8-10 godzin", "2h 30min")
    extracted_times_minutes: Optional[int] = None                      # Czas przejścia w minutach
    characteristic_points: List[str] = field(default_factory=list)     # Lista zidentyfikowanych punktów (np. "schronisko", "szczyt")
    warnings: List[str] = field(default_factory=list)                  # Lista rozpoznanych ostrzeżeń (np. "śliskie kamienie")
    extracted_coords: List[Tuple[float, float]] = field(default_factory=list) # Lista wyodrębnionych współrzędnych (Float dla lat/lon)
    extracted_elevations: List[int] = field(default_factory=list)      # Lista wyodrębnionych wysokości (np. [2499])
    
    gallery_urls: List[str] = field(default_factory=list)              
    map_url: Optional[str] = None                                    

    def to_dict(self) -> Dict[str, Any]:
        coords_for_json = [list(coord) for coord in self.extracted_coords]

        reviews_for_json = self.reviews

        return {
            "id": self.id,
            "name": self.name,
            "region": self.region,
            "start_lat": self.start_lat,
            "start_lon": self.start_lon,
            "end_lat": self.end_lat,
            "end_lon": self.end_lon,
            "length_km": self.length_km,
            "elevation_gain": self.elevation_gain,
            "difficulty": self.difficulty,
            "terrain_type": self.terrain_type,
            "tags": self.tags,
            "description": self.description,
            "reviews": reviews_for_json,
            "extracted_times": self.extracted_times,
            "extracted_times_minutes": self.extracted_times_minutes,
            "characteristic_points": self.characteristic_points,
            "warnings": self.warnings,
            "extracted_coords": coords_for_json,
            "extracted_elevations": self.extracted_elevations,
            "gallery_urls": self.gallery_urls,
            "map_url": self.map_url
        }

    @classmethod
    def _deserialize_list_field(cls, data_dict: Dict[str, Any], key: str, default_value: List[Any]) -> List[Any]:
        value = data_dict.get(key, default_value)
        if isinstance(value, str):
            try:
                return json.loads(value) if value else default_value
            except json.JSONDecodeError:
                print(f"Ostrzeżenie: Nieprawidłowy format JSON dla pola '{key}'. Użyto wartości domyślnej.")
                return default_value
        return value

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        required_fields = ['id', 'name', 'region', 'start_lat', 'start_lon', 'end_lat', 'end_lon']
        for field_name in required_fields:
            if field_name not in data or data[field_name] is None:
                raise ValueError(f"Brakujące obowiązkowe pole '{field_name}' w danych trasy.")

        _tags = cls._deserialize_list_field(data, 'tags', [])
        _reviews = cls._deserialize_list_field(data, 'reviews', [])
        _extracted_times = cls._deserialize_list_field(data, 'extracted_times', [])
        _characteristic_points = cls._deserialize_list_field(data, 'characteristic_points', [])
        _warnings = cls._deserialize_list_field(data, 'warnings', [])
        _extracted_elevations = cls._deserialize_list_field(data, 'extracted_elevations', [])
        _gallery_urls = cls._deserialize_list_field(data, 'gallery_urls', [])
        _extracted_coords_raw = data.get('extracted_coords', [])
        _extracted_coords: List[Tuple[float, float]] = []
        if isinstance(_extracted_coords_raw, str):
            try:
                _extracted_coords_raw = json.loads(_extracted_coords_raw) if _extracted_coords_raw else []
            except json.JSONDecodeError:
                print("Ostrzeżenie: Nieprawidłowy format JSON dla 'extracted_coords'. Użyto wartości domyślnej.")
                _extracted_coords_raw = []

        for coord_pair in _extracted_coords_raw:
            if isinstance(coord_pair, (list, tuple)) and len(coord_pair) == 2:
                try:
                    _extracted_coords.append((float(coord_pair[0]), float(coord_pair[1])))
                except (ValueError, TypeError):
                    print(f"Ostrzeżenie: Nieprawidłowy format współrzędnej {coord_pair}. Pominięto.")
            else:
                print(f"Ostrzeżenie: Nieprawidłowy format elementu współrzędnej {coord_pair}. Pominięto.")


        return cls(
            id=data['id'],
            name=data['name'],
            region=data['region'],
            start_lat=data['start_lat'],
            start_lon=data['start_lon'],
            end_lat=data['end_lat'],
            end_lon=data['end_lon'],
            length_km=data.get('length_km'),
            elevation_gain=data.get('elevation_gain'),
            difficulty=data.get('difficulty'),
            terrain_type=data.get('terrain_type'),
            tags=_tags,
            description=data.get('description'),
            reviews=_reviews,
            extracted_times=_extracted_times,
            extracted_times_minutes=data.get('extracted_times_minutes'),
            characteristic_points=_characteristic_points,
            warnings=_warnings,
            extracted_coords=_extracted_coords,
            extracted_elevations=_extracted_elevations,
            gallery_urls=_gallery_urls,
            map_url=data.get('map_url')
        )

    def __str__(self):
        description_snippet = (self.description[:100] + "...") if self.description and len(self.description) > 100 else (self.description if self.description else 'Brak opisu')
        return (f"Trasa: {self.name} (ID: {self.id})\n"
                f"  Region: {self.region}\n"
                f"  Długość: {self.length_km if self.length_km is not None else 'N/A'} km, Przewyższenie: {self.elevation_gain if self.elevation_gain is not None else 'N/A'} m, Trudność: {self.difficulty if self.difficulty is not None else 'N/A'}/5\n"
                f"  Opis: {description_snippet}\n"
                f"  Punkty charakterystyczne: {', '.join(self.characteristic_points) if self.characteristic_points else 'Brak'}\n"
                f"  Ostrzeżenia: {', '.join(self.warnings) if self.warnings else 'Brak'}\n"
                f"  Liczba recenzji: {len(self.reviews)}\n")