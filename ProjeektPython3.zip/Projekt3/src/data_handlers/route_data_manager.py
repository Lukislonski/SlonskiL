# src/data_handlers/route_data_manager.py

import csv
from src.models.route import Route
from typing import List, Dict, Any

class RouteDataManager:
    @staticmethod
    def load_routes(path: str) -> List[Route]:
        routes = []
        try:
            with open(path, newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    try:
                        # Konwersja typów podczas ładowania. Nowe pola będą domyślnie puste/None.
                        route = Route(
                            id=int(row['id']),
                            name=row['name'],
                            region=row['region'],
                            start_lat=float(row['start_lat']),
                            start_lon=float(row['start_lon']),
                            end_lat=float(row['end_lat']),
                            end_lon=float(row['end_lon']),
                            length_km=float(row['length_km']),
                            elevation_gain=int(row['elevation_gain']),
                            difficulty=int(row['difficulty']),
                            terrain_type=row['terrain_type'],
                            tags=[tag.strip() for tag in row['tags'].split(',') if tag.strip()]
                        )
                        routes.append(route)
                    except (ValueError, KeyError) as e:
                        print(f"Błąd konwersji lub brak klucza w wierszu CSV (wiersz pominięty): {row}. Błąd: {e}")
                        continue
        except FileNotFoundError:
            print(f"Błąd: Plik '{path}' nie został znaleziony.")
        except Exception as e:
            print(f"Wystąpił nieoczekiwany błąd podczas ładowania tras: {e}")
        return routes

    @staticmethod
    def save_routes(routes: List[Route], path: str):
        if not routes:
            print("Brak tras do zapisania.")
            return
        fieldnames = [
            'id', 'name', 'region', 'start_lat', 'start_lon',
            'end_lat', 'end_lon', 'length_km', 'elevation_gain',
            'difficulty', 'terrain_type', 'tags'
        ]
        try:
            with open(path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for route in routes:
                    route_data = {
                        'id': route.id,
                        'name': route.name,
                        'region': route.region,
                        'start_lat': route.start_lat,
                        'start_lon': route.start_lon,
                        'end_lat': route.end_lat,
                        'end_lon': route.end_lon,
                        'length_km': route.length_km,
                        'elevation_gain': route.elevation_gain,
                        'difficulty': route.difficulty,
                        'terrain_type': route.terrain_type,
                        'tags': ','.join(route.tags)
                    }
                    writer.writerow(route_data)
        except IOError as e:
            print(f"Błąd zapisu pliku '{path}': {e}")
        except Exception as e:
            print(f"Wystąpił nieoczekiwany błąd podczas zapisywania tras: {e}")