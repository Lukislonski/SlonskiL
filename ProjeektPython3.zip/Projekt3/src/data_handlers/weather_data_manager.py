# src/data_handlers/weather_data_manager.py

import csv
from src.models.weather_data import WeatherData
from typing import List
from datetime import datetime

class WeatherDataManager:
    @staticmethod
    def load_weather_data(path: str) -> List[WeatherData]:
        weather_data = []
        try:
            with open(path, newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    try:
                        weather = WeatherData(
                            date=datetime.strptime(row['date'], '%Y-%m-%d').date(),
                            location_id=row['location_id'],
                            avg_temp=float(row['avg_temp']),
                            min_temp=float(row['min_temp']),
                            max_temp=float(row['max_temp']),
                            precipitation=float(row['precipitation']),
                            sunshine_hours=float(row['sunshine_hours']),
                            cloud_cover=float(row['cloud_cover'])
                        )
                        weather_data.append(weather)
                    except (ValueError, KeyError) as e:
                        print(f"Błąd konwersji lub brak klucza w wierszu CSV (wiersz pominięty): {row}. Błąd: {e}")
                        continue
        except FileNotFoundError:
            print(f"Błąd: Plik '{path}' nie został znaleziony.")
        except Exception as e:
            print(f"Wystąpił nieoczekiwany błąd podczas ładowania danych pogodowych: {e}")
        return weather_data

    @staticmethod
    def save_weather_data(weather_data: List[WeatherData], path: str):
        if not weather_data:
            print("Brak danych pogodowych do zapisania.")
            return

        fieldnames = [
            'date', 'location_id', 'avg_temp', 'min_temp', 'max_temp',
            'precipitation', 'sunshine_hours', 'cloud_cover'
        ]
        try:
            with open(path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for weather in weather_data:
                    weather_data_dict = {
                        'date': weather.date.strftime('%Y-%m-%d'),
                        'location_id': weather.location_id,
                        'avg_temp': weather.avg_temp,
                        'min_temp': weather.min_temp,
                        'max_temp': weather.max_temp,
                        'precipitation': weather.precipitation,
                        'sunshine_hours': weather.sunshine_hours,
                        'cloud_cover': weather.cloud_cover
                    }
                    writer.writerow(weather_data_dict)
        except IOError as e:
            print(f"Błąd zapisu pliku '{path}': {e}")
        except Exception as e:
            print(f"Wystąpił nieoczekiwany błąd podczas zapisywania danych pogodowych: {e}")