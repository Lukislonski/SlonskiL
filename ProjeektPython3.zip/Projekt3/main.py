import sys
import os
import json
import re

current_project_dir = os.path.dirname(os.path.abspath(__file__))
if current_project_dir not in sys.path:
    sys.path.insert(0, current_project_dir)

# Importy z pakietu 'src'
from src.data_handlers.route_data_manager import RouteDataManager
from src.data_handlers.weather_data_manager import WeatherDataManager
from src.recommenders.route_recommender import RouteRecommender
from src.ui.user_interface import UserInterface
from src.extractors.web_data_collector import WebDataCollector
from src.extractors.html_route_extractor import HTMLRouteExtractor
from src.extractors.scraping_rules_manager import ScrapingRulesManager
from src.reporters.pdf_report_generator import PDFReportGenerator
from src.reporters.chart_generator import ChartGenerator
from src.models.route import Route
from src.models.weather_data import WeatherData
from src.analyzers.text_processor import TextProcessor
from src.analyzers.review_analyzer import ReviewAnalyzer
from src.models.user_preferences import UserPreferences
from src.config.api_keys import OPENWEATHER_API_KEY, OPENROUTESERVICE_API_KEY
from datetime import date

def fetch_route_ors(web_collector, start_lon, start_lat, end_lon, end_lat):
    api_url = "https://api.openrouteservice.org/v2/directions/foot-walking"
    headers = {
        "Authorization": OPENROUTESERVICE_API_KEY,
        "Content-Type": "application/json"
    }
    json_body = {
        "coordinates": [
            [start_lon, start_lat],
            [end_lon, end_lat]
        ]
    }

    cache_id = f"ors_route_{start_lon}_{start_lat}_{end_lon}_{end_lat}"

    data = web_collector.fetch_json_post(
        api_url,
        cache_id,
        json_body=json_body,
        headers=headers
    )
    return data

def main():
    """
    Główna funkcja aplikacji do rekomendacji tras turystycznych.
    Integruje ładowanie danych, zbieranie danych z sieci, analizę,
    rekomendacje i generowanie raportów.
    """
    ui = UserInterface()
    web_collector = WebDataCollector(cache_dir=os.path.join(current_project_dir, 'data', 'html_cache'))
    html_extractor = HTMLRouteExtractor()
    scraping_rules_manager = ScrapingRulesManager(rules_dir=os.path.join(current_project_dir, 'data', 'scraping_rules'))
    
    # Inicjalizacja nowych klas
    text_processor = TextProcessor()
    review_analyzer = ReviewAnalyzer()

    print("--- System Rekomendacji Tras Turystycznych ---")

    print("\nŁadowanie podstawowych danych tras i pogody z plików CSV...")
    routes = RouteDataManager.load_routes(os.path.join(current_project_dir, 'data', 'routes', 'routes.csv'))
    weather_data = WeatherDataManager.load_weather_data(os.path.join(current_project_dir, 'data', 'weather', 'weather.csv'))

    if not routes:
        print("Nie udało się załadować żadnych tras. Zakończenie programu.")
        return
    if not weather_data:
        print("Nie udało się załadować żadnych danych pogodowych. Kontynuuję bez danych pogodowych z plików CSV, ale spróbuję pobrać z API.")

    print("\nPobieranie i przetwarzanie danych HTML dla przykładowej trasy 'Szlak na Rysy' z użyciem reguł...")
    
    rysy_html_filepath = os.path.join(current_project_dir, 'data', 'html_cache', 'rysy.html')
    portal_name_for_rysy = "RysyPortalExample"
    
    rysy_rules = scraping_rules_manager.get_rules(portal_name_for_rysy)

    extracted_route_details = {}
    if rysy_rules:
        html_content = None
        if os.path.exists(rysy_html_filepath):
            try:
                with open(rysy_html_filepath, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                print(f"Pomyślnie wczytano HTML z lokalnego pliku: {rysy_html_filepath}")
            except Exception as e:
                print(f"Błąd podczas wczytywania lokalnego pliku HTML '{rysy_html_filepath}': {e}")
        else:
            print(f"Błąd: Lokalny plik HTML '{rysy_html_filepath}' nie istnieje. Upewnij się, że został utworzony przez sekcję if __name__ == '__main__':")

        if html_content:
            extracted_route_details = html_extractor.extract_route_data(html_content, rysy_rules['rules'])
            if extracted_route_details:
                print("Pomyślnie wyodrębniono dane z HTML z użyciem reguł.")
                
                # --- INTEGRACJA TEXT_PROCESSOR I REVIEW_ANALYZER ---
                route_description = extracted_route_details.get('description', '')

                # 1. Przetwarzanie opisu trasy za pomocą TextProcessor
                extracted_times_raw = text_processor.extract_times(route_description)
                estimated_time_str = extracted_route_details.get('estimated_time')
                if estimated_time_str:
                    extracted_time_minutes = text_processor.convert_time_to_minutes(estimated_time_str)
                else:
                    extracted_time_minutes = None
                    if extracted_times_raw:
                        extracted_time_minutes = text_processor.convert_time_to_minutes(extracted_times_raw[0])
                
                characteristic_points = text_processor.identify_characteristic_points(route_description)
                warnings = text_processor.recognize_warnings(route_description)
                extracted_coords = text_processor.standardize_coordinates(route_description)
                extracted_elevations = text_processor.extract_elevations(route_description)
                
                extracted_elevations_int = []
                for elev_str in extracted_elevations:
                    try:
                        num_match = re.search(r'(\d+)', elev_str)
                        if num_match:
                            extracted_elevations_int.append(int(num_match.group(1)))
                    except ValueError:
                        pass

                # 2. Analiza recenzji za pomocą ReviewAnalyzer
                analyzed_reviews = []
                raw_reviews = extracted_route_details.get('reviews', [])
                for review_entry in raw_reviews:
                    if isinstance(review_entry, dict) and 'text' in review_entry:
                        analyzed_review_data = review_analyzer.analyze_review(review_entry['text'])
                        analyzed_reviews.append({**review_entry, **analyzed_review_data})
                    elif isinstance(review_entry, str):
                        analyzed_review_data = review_analyzer.analyze_review(review_entry)
                        analyzed_reviews.append({'text': review_entry, **analyzed_review_data})

                # --- KONIEC INTEGRACJI ---

                rysy_route_name = extracted_route_details.get('name', 'Szlak na Rysy (z HTML)')
                
                existing_route_index = -1
                for i, r in enumerate(routes):
                    if r.id == 999 or (isinstance(r, Route) and r.name == rysy_route_name):
                        existing_route_index = i
                        break

                # Dane do obiektu Route
                route_id = 999
                route_region = "Tatry"
                route_start_lat = 49.22
                route_start_lon = 20.08
                route_end_lat = 49.18
                route_end_lon = 20.07
                route_terrain_type = "mountain"
                route_tags = ["alpine", "high-mountain", "scenic"]

                # Próba konwersji długości, przewyższenia, trudności na liczby
                length_km = extracted_route_details.get('length_km')
                elevation_gain = extracted_route_details.get('elevation_gain')
                difficulty = extracted_route_details.get('difficulty')

                try:
                    if isinstance(length_km, str):
                        length_km = float(length_km.replace(',', '.'))
                except (ValueError, TypeError):
                    length_km = None

                try:
                    if isinstance(elevation_gain, str):
                        elevation_gain = int(elevation_gain)
                except (ValueError, TypeError):
                    elevation_gain = None
                
                try:
                    if isinstance(difficulty, str):
                        difficulty = int(difficulty)
                except (ValueError, TypeError):
                    difficulty = None

                rysy_route = Route(
                    id=route_id,
                    name=rysy_route_name,
                    region=route_region,
                    start_lat=route_start_lat, start_lon=route_start_lon,
                    end_lat=route_end_lat, end_lon=route_end_lon,
                    length_km=length_km,
                    elevation_gain=elevation_gain,
                    difficulty=difficulty,
                    terrain_type=route_terrain_type,
                    tags=route_tags,
                    description=route_description,
                    reviews=analyzed_reviews,
                    extracted_times=extracted_times_raw,
                    extracted_times_minutes=extracted_time_minutes,
                    characteristic_points=characteristic_points,
                    warnings=warnings,
                    extracted_coords=extracted_coords,
                    extracted_elevations=extracted_elevations_int
                )
                
                if existing_route_index != -1:
                    routes[existing_route_index] = rysy_route
                    print(f"Trasa '{rysy_route.name}' została zaktualizowana o dane z HTML i przetworzone.")
                else:
                    routes.append(rysy_route)
                    print(f"Trasa '{rysy_route.name}' została dodana o dane z HTML i przetworzone.")
            else:
                print("Nie udało się wyodrębnić danych z HTML. Brak szczegółów trasy.")
        else:
            print("Brak zawartości HTML do przetworzenia. Kontynuuję bez niej.")
    else:
        print(f"Błąd: Nie znaleziono reguł dla portalu '{portal_name_for_rysy}'. Kontynuuję bez przetwarzania HTML.")


    # --- Przykładowe pobieranie danych o POI z API turystycznego (OPENROUTESERVICE) ---
    print("\nPobieranie przykładowej trasy pieszej z OpenRouteService...")
    start_lon, start_lat = 18.646, 54.352  # Gdańsk
    end_lon, end_lat = 18.650, 54.355

    route_data = fetch_route_ors(web_collector, start_lon, start_lat, end_lon, end_lat)

    if route_data is None:
        print("Nie udało się pobrać trasy z OpenRouteService.")
    else:
        try:
            summary = route_data['features'][0]['properties']['summary']
            distance_km = summary['distance'] / 1000
            duration_min = summary['duration'] / 60
            print(f"Pomyślnie pobrano trasę z ORS. Długość: {distance_km:.2f} km, Czas: {duration_min:.0f} min.")
        except Exception as e:
            print(f"Nie udało się wyciągnąć podsumowania trasy z OpenRouteService: {e}")
            distance_km = None
            duration_min = None

        route = Route(
            id="ors_example_1",
            name="Przykładowa trasa OpenRouteService (Gdańsk)",
            region="Gdańsk",
            start_lat=start_lat, start_lon=start_lon,
            end_lat=end_lat, end_lon=end_lon,
            length_km=distance_km if distance_km is not None else 0,
            elevation_gain=0,
            difficulty=3,
            terrain_type="urban",
            tags=["city_walk", "historical"],
            description="Trasa piesza pobrana z OpenRouteService API.",
            reviews=[],
            extracted_times=[],
            extracted_times_minutes=duration_min if duration_min is not None else 0,
            characteristic_points=[],
            warnings=[],
            extracted_coords=[],
            extracted_elevations=[]
        )
        routes.append(route)
        print(f"Trasa '{route.name}' została dodana do listy tras.")
    # --- KONIEC ZMIAN DLA API TURYSTYCZNEGO ---


    # 3. Pobieranie preferencji użytkownika
    user_preferences = ui.get_user_preferences()

    if not user_preferences:
        print("Nie udało się pobrać poprawnych preferencji użytkownika. Zakończenie programu.")
        return

    # 4. Generowanie rekomendacji
    print("\nGenerowanie rekomendacji tras...")
    recommender = RouteRecommender(routes, weather_data)
    recommendations = recommender.generate_recommendations(user_preferences)
    ui.display_recommendations(recommendations)

    # 6. Generowanie wykresów do raportu
    print("\nGenerowanie wykresów do raportu PDF...")
    charts_to_add = []

    # Przykładowe dane do wykresu profilu wysokościowego
    rysy_elevation_profile_data = [
        (0, 1000), (2, 1200), (5, 1500), (8, 1800), (10, 2000), (12, 2300), (14, 2499)
    ]

    # Przykładowe dane do wykresu radarowego
    rysy_radar_scores = {
        "Widoki": 0.9,
        "Trudność": 0.8,
        "Oznakowanie": 0.6,
        "Długość": 0.7,
        "Atrakcje": 0.8
    }

    # Inicjalizacja ChartGenerator i PDFReportGenerator
    output_report_dir = os.path.join(current_project_dir, 'reports')
    output_charts_dir = os.path.join(output_report_dir, 'charts')
    os.makedirs(output_charts_dir, exist_ok=True)
    chart_generator = ChartGenerator(output_charts_dir)
    pdf_generator = PDFReportGenerator(output_report_dir)

    if recommendations:
        charts_to_add.append(chart_generator.generate_length_histogram(recommendations))
        charts_to_add.append(chart_generator.generate_category_pie_chart(recommendations))
        charts_to_add.append(chart_generator.generate_user_rating_bar_chart(recommendations))
        charts_to_add.append(chart_generator.generate_popularity_heatmap(recommendations))

        found_rysy_rec = None
        for r in routes:
            if r.id == 999 or r.name == "Szlak na Rysy - Opis Trasy":
                found_rysy_rec = r
                break

        if found_rysy_rec:
            route_name_for_chart = found_rysy_rec.name
            charts_to_add.append(chart_generator.generate_elevation_profile(route_name_for_chart, rysy_elevation_profile_data))
            charts_to_add.append(chart_generator.generate_radar_chart(route_name_for_chart, rysy_radar_scores))
        else:
            print("Nie znaleziono przetworzonej trasy 'Rysy' (ID 999 lub konkretna nazwa) do generowania wykresów.")


        # Filtruje ścieżki, żeby nie było None
        charts_to_add = [c for c in charts_to_add if c is not None]
    else:
        print("Brak rekomendacji, nie generuję wykresów.")

    # 7. Generowanie raportu PDF
    print("\nGenerowanie raportu PDF...")
    report_filename = f"raport_tras_{date.today().strftime('%Y%m%d')}.pdf"
    pdf_generator.generate_report(report_filename, recommendations, user_preferences.__dict__, charts_to_add)

    print("\n--- Zakończono działanie systemu ---")
    print(f"Sprawdź katalog '{pdf_generator.output_dir}' aby znaleźć wygenerowany raport i wykresy.")

if __name__ == "__main__":
    base_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    html_cache_dir = os.path.join(base_data_dir, 'html_cache')
    scraping_rules_dir = os.path.join(base_data_dir, 'scraping_rules')
    
    os.makedirs(html_cache_dir, exist_ok=True)
    os.makedirs(scraping_rules_dir, exist_ok=True)
    os.makedirs(os.path.join(base_data_dir, 'routes'), exist_ok=True)
    os.makedirs(os.path.join(base_data_dir, 'weather'), exist_ok=True)

    rysy_html_path = os.path.join(html_cache_dir, 'rysy.html')
    if not os.path.exists(rysy_html_path):
        with open(rysy_html_path, 'w', encoding='utf-8') as f:
            f.write("""
            <div class="route-info">
                <h1>Szlak na Rysy - Opis Trasy</h1>
                <p class="route-description">
                    To jest wymagająca trasa w Tatrach Wysokich. Czas przejścia to około <b>8h 30min</b> w jedną stronę.
                    Po drodze znajduje się <b>schronisko</b> w Dolinie Pięciu Stawów Polskich. Uważaj na wysokie przewyższenia.
                    Szczyt Rysów znajduje się na wysokości 2499 m n.p.m.
                    Współrzędne początku trasy: N49°11′46″ E20°05′33″.
                    Wiosną (kwiecień) i wczesnym latem (czerwiec) mogą występować płaty śniegu.
                    Ostrzeżenie: Trasa bardzo wymagająca technicznie, tylko dla doświadczonych turystów.
                </p>
                <table class="route-params">
                    <tr><td>Długość całkowita:</td><td>18.5 km</td></tr>
                    <tr><td>Szacowany czas:</td><td>8-10 godzin</td></tr>
                    <tr><td>Przewyższenie:</td><td>1650 m</td></tr>
                    <tr><td>Trudność:</td><td>5/5</td></tr>
                </table>
                <div class="user-review">
                    <span class="rating">★★★★★</span>
                    <p>Wspaniałe widoki! Byłem 15.08.2023, pogoda dopisała, trasa super. Ocena 9/10.</p>
                </div>
                <div class="user-review">
                    <span class="rating">★★★☆☆</span>
                    <p>Trasa trudna, kiepskie oznakowanie miejscami. Byłem w lipcu 2022, lało cały dzień.</p>
                </div>
                <div class="gallery"></div>
                <div id="map"></div>
            </div>
            """)
        print(f"Stworzono przykładowy plik HTML w: {rysy_html_path}")
    
    rysy_rules_path = os.path.join(scraping_rules_dir, 'rysy_portal.json')
    if not os.path.exists(rysy_rules_path):
        with open(rysy_rules_path, 'w', encoding='utf-8') as f:
            json.dump({
                "portal_name": "RysyPortalExample",
                "base_url": "https://www.example.com/",
                "rules": {
                    "name": {
                        "selector": "div.route-info h1",
                        "type": "text"
                    },
                    "description": {
                        "selector": "p.route-description",
                        "type": "text"
                    },
                    "length_km": {
                        "selector": "table.route-params tr:nth-child(1) td:nth-child(2)",
                        "type": "text",
                        "regex": "([\\d.]+)\\s*km"
                    },
                    "estimated_time": {
                        "selector": "table.route-params tr:nth-child(2) td:nth-child(2)",
                        "type": "text"
                    },
                    "elevation_gain": {
                        "selector": "table.route-params tr:nth-child(3) td:nth-child(2)",
                        "type": "text",
                        "regex": "([\\d.]+)\\s*m"
                    },
                    "difficulty": {
                        "selector": "table.route-params tr:nth-child(4) td:nth-child(2)",
                        "type": "text",
                        "regex": "(\\d+)/5"
                    },
                    "reviews": {
                        "selector": "div.user-review",
                        "type": "list",
                        "item_rules": {
                            "rating": {
                                "selector": "span.rating",
                                "type": "text",
                                "regex": "(\u2605+)"
                            },
                            "text": {
                                "selector": "p",
                                "type": "text"
                            }
                        }
                    }   
                }
            }, f, indent=4)
        print(f"Stworzono przykładowy plik reguł scrapingu w: {rysy_rules_path}")

    routes_csv_path = os.path.join(current_project_dir, 'data', 'routes', 'routes.csv')
    weather_csv_path = os.path.join(current_project_dir, 'data', 'weather', 'weather.csv')
    
    if not os.path.exists(routes_csv_path):
        with open(routes_csv_path, 'w', encoding='utf-8') as f:
            f.write("id,name,region,start_lat,start_lon,end_lat,end_lon,length_km,elevation_gain,difficulty,terrain_type,tags,description,extracted_times,extracted_times_minutes,characteristic_points,warnings,extracted_coords,extracted_elevations,reviews,gallery_urls,map_url\n")
        print(f"Stworzono pusty plik CSV: {routes_csv_path}")

    if not os.path.exists(weather_csv_path):
        with open(weather_csv_path, 'w', encoding='utf-8') as f:
            f.write("date,location_id,avg_temp,min_temp,max_temp,precipitation,sunshine_hours,cloud_cover,wind_speed,weather_description,humidity,pressure\n")
        print(f"Stworzono pusty plik CSV: {weather_csv_path}")


    main()