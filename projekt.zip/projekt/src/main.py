import os
from data_loader import load_csv, save_csv
from data_processor import filter_routes, compute_weather_stats, get_difficulty_summary

def main():
    base_path = os.path.join("..", "data")
    routes = load_csv(os.path.join(base_path, "trasy.csv"))
    weather = load_csv(os.path.join(base_path, "pogoda.csv"))

    print("\nWszystkie dostępne trasy:")
    for r in routes:
        print(
            f"\n- {r['name']} ({r['region']})\n"
            f"  Start: ({r['start_lat']}, {r['start_lon']}), Koniec: ({r['end_lat']}, {r['end_lon']})\n"
            f"  Długość: {r['length_km']} km, Przewyższenie: {r['elevation_gain']} m\n"
            f"  Trudność: {r['difficulty']}, Teren: {r['terrain_type']}, Tagi: {r['tags']}"
        )

    regions = sorted(set(r["region"] for r in routes))
    print("\nDostępne regiony:")
    for i, region in enumerate(regions):
        print(f"{i + 1}. {region}")

    try:
        region_index = int(input("\nWybierz numer regionu: ")) - 1
        selected_region = regions[region_index]
    except (ValueError, IndexError):
        print("Nieprawidłowy wybór regionu.")
        return

    try:
        min_length = float(input("Podaj minimalną długość trasy (km): "))
        max_difficulty = int(input("Podaj maksymalną trudność (1-5): "))
    except ValueError:
        print("Nieprawidłowe dane liczbowe.")
        return

    filtered = filter_routes(routes, min_length=min_length, max_difficulty=max_difficulty, region=selected_region)

    print(f"\nPrzefiltrowane trasy dla regionu '{selected_region}':")
    for r in filtered:
        print(f"- {r['name']} | {r['length_km']} km | Trudność: {r['difficulty']} | Przewyższenie: {r['elevation_gain']} m")

    weather_stat = compute_weather_stats(weather, selected_region)

    print("\nStatystyki pogodowe dla wybranego regionu:")
    if weather_stat:
        print(f"- {weather_stat['location_id']}: Śr. temp {weather_stat['avg_temp']}°C, "
              f"Opady {weather_stat['total_precip']} mm, "
              f"Słoneczne dni: {weather_stat['sunny_days']}")
    else:
        print("- Brak danych pogodowych dla wybranego regionu.")

    print("\nPodsumowanie trudności tras:")
    difficulty_counts = get_difficulty_summary(routes)
    for diff, count in sorted(difficulty_counts.items()):
        print(f"  Trudność {diff}: {count} tras")

    save_csv(filtered, os.path.join(base_path, "filtered_routes.csv"), fieldnames=routes[0].keys())

if __name__ == "__main__":
    main()
