# tests/test_route_analyzer.py

import unittest
from src.models.route import Route
from src.analyzers.route_analyzer import RouteAnalyzer

class TestRouteAnalyzer(unittest.TestCase):
    def setUp(self):
        self.route = Route(
            id=101,
            name="Rezerwat Beka",
            region="Puck",
            start_lat=54.6702,
            start_lon=18.4275,
            end_lat=54.6780,
            end_lon=18.4441,
            length_km=5.3,
            elevation_gain=12,
            difficulty=1,
            terrain_type="coastal",
            tags=["birdwatching", "flat"]
        )
        self.analyzer = RouteAnalyzer(self.route)

    def test_estimate_travel_time(self):
        estimated_time = self.analyzer.estimate_travel_time()
        self.assertIsInstance(estimated_time, int)
        self.assertGreater(estimated_time, 0)

    def test_categorize_route(self):
        categories = self.analyzer.categorize_route()
        self.assertIn("Rodzinna", categories)
        self.assertIsInstance(categories, list)

if __name__ == "__main__":
    unittest.main()
