# tests/test_weather_analyzer.py

import unittest
from src.models.weather_data import WeatherData
from src.analyzers.weather_analyzer import WeatherAnalyzer

class TestWeatherAnalyzer(unittest.TestCase):
    def setUp(self):
        self.weather = WeatherData(
            date="2023-08-12",
            location_id="Puck",
            avg_temp=21.5,
            min_temp=17.0,
            max_temp=25.0,
            precipitation=0.2,
            sunshine_hours=8.0,
            cloud_cover=20
        )
        self.analyzer = WeatherAnalyzer(self.weather)

    def test_is_sunny_day(self):
        self.assertTrue(self.analyzer.is_sunny_day())

    def test_is_rainy_day(self):
        self.assertFalse(self.analyzer.is_rainy_day())

    def test_comfort_index(self):
        index = self.analyzer.comfort_index()
        self.assertIsInstance(index, int)
        self.assertGreaterEqual(index, 0)
        self.assertLessEqual(index, 100)

if __name__ == "__main__":
    unittest.main()
