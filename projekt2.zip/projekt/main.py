# main.py

from src.data_handlers.route_data_manager import RouteDataManager
from src.data_handlers.weather_data_manager import WeatherDataManager
from src.recommenders.route_recommender import RouteRecommender
from src.ui.user_interface import UserInterface

# Wczytanie danych
routes = RouteDataManager.load_routes('data/routes/routes.csv')
weather_data = WeatherDataManager.load_weather_data('data/weather/weather.csv')

recommender = RouteRecommender(routes, weather_data)

# Pobieranie preferencji użytkownika
ui = UserInterface()
ui.get_user_preferences()

# Generowanie rekomendacji
recommendations = recommender.generate_recommendations(ui.user_pref)

# Wyświetlanie rekomendacji
ui.display_recommendations(recommendations)
