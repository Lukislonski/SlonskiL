# src/analyzers/weather_analyzer.py

class WeatherAnalyzer:
    def __init__(self, weather_data):
        self.weather = weather_data

    def is_sunny_day(self):
        return self.weather.sunshine_hours >= 6.0 and self.weather.cloud_cover <= 30

    def is_rainy_day(self):
        return self.weather.precipitation > 1.0

    def comfort_index(self):
        score = 100

        # Temperatura
        if self.weather.avg_temp < 16 or self.weather.avg_temp > 26:
            score -= 15
        elif self.weather.avg_temp < 18 or self.weather.avg_temp > 24:
            score -= 5

        # Opady
        if self.weather.precipitation > 5.0:
            score -= 25
        elif self.weather.precipitation > 1.0:
            score -= 10

        # Zachmurzenie
        if self.weather.cloud_cover > 70:
            score -= 15
        elif self.weather.cloud_cover > 40:
            score -= 5

        return max(0, min(score, 100))

    def display_weather_info(self):
        print(f"Data: {self.weather.date}")
        print(f"Średnia temperatura: {self.weather.avg_temp}°C")
        print(f"Opady: {self.weather.precipitation} mm")
        print(f"Godziny słońca: {self.weather.sunshine_hours} h")
        print(f"Zachmurzenie: {self.weather.cloud_cover}%")
        print(f"Indeks komfortu: {self.comfort_index()}")

