# src/analyzers/route_analyzer.py

class RouteAnalyzer:
    def __init__(self, route):
        self.route = route

    def estimate_travel_time(self):
        base_speed = self._terrain_speed(self.route.terrain_type)  # km/h
        if base_speed == 0:
            return None

        # Obliczanie czasu na podstawie długości trasy
        time_distance = (self.route.length_km / base_speed) * 60

        # Czas na przewyższenie
        time_elevation = (self.route.elevation_gain / 600) * 60

        # Mnożnik trudności
        difficulty_multiplier = self._difficulty_factor(self.route.difficulty)

        # Całkowity czas
        total_time = (time_distance + time_elevation) * difficulty_multiplier
        return round(total_time)

    def categorize_route(self):
        tags = set(self.route.tags)
        difficulty = self.route.difficulty
        length = self.route.length_km
        gain = self.route.elevation_gain

        categories = []

        # Kategoria "Rodzinna": łatwe trasy, krótka długość, małe przewyższenie
        if difficulty <= 2 and length <= 8 and gain < 100:
            categories.append("Rodzinna")
        
        # Kategoria "Widokowa": trasy z tagami "viewpoint" lub "scenic"
        if "viewpoint" in tags or "scenic" in tags:
            categories.append("Widokowa")
        
        # Kategoria "Sportowa": trudniejsze trasy lub z dużym przewyższeniem
        if difficulty >= 3 or gain >= 300:
            categories.append("Sportowa")
        
        # Kategoria "Ekstremalna": bardzo trudne trasy lub z alpejskim terenem
        if difficulty >= 4 or "alpine" in tags:
            categories.append("Ekstremalna")

    def _terrain_speed(self, terrain_type):"
        speeds = {
            "coastal": 5,
            "forest": 4,
            "urban-hill": 4,
            "urban-wild": 4,
            "lake": 4,
            "mountain": 3,
            "dunes": 3.5
        }
        return speeds.get(terrain_type, 4)

    def _difficulty_factor(self, difficulty):
        return {
            1: 1.0,
            2: 1.2,
            3: 1.5,
            4: 1.7,
            5: 1.9
        }.get(difficulty, 1.0)
