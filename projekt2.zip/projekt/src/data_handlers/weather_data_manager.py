# src/data_handlers/weather_data_manager.py

import csv
from src.models.weather_data import WeatherData

class WeatherDataManager:
    @staticmethod
    def load_weather_data(path):
        weather_data = []
        with open(path, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                weather = WeatherData(
                    row['date'], 
                    row['location_id'], 
                    row['avg_temp'], 
                    row['min_temp'], 
                    row['max_temp'], 
                    row['precipitation'], 
                    row['sunshine_hours'], 
                    row['cloud_cover']
                )
                weather_data.append(weather)
        return weather_data

    @staticmethod
    def save_weather_data(weather_data, path):
        if not weather_data:
            return
        
        with open(path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'date', 'location_id', 'avg_temp', 'min_temp', 'max_temp', 
                'precipitation', 'sunshine_hours', 'cloud_cover'
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for weather in weather_data:
                weather_data_dict = {
                    'date': weather.date,
                    'location_id': weather.location_id,
                    'avg_temp': weather.avg_temp,
                    'min_temp': weather.min_temp,
                    'max_temp': weather.max_temp,
                    'precipitation': weather.precipitation,
                    'sunshine_hours': weather.sunshine_hours,
                    'cloud_cover': weather.cloud_cover
                }
                writer.writerow(weather_data_dict)
