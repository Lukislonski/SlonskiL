# src/data_handlers/route_data_manager.py

import csv
from src.models.route import Route

class RouteDataManager:
    @staticmethod
    def load_routes(path):
        routes = []
        with open(path, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                route = Route(
                    row['id'], 
                    row['name'], 
                    row['region'], 
                    row['start_lat'], 
                    row['start_lon'], 
                    row['end_lat'], 
                    row['end_lon'], 
                    row['length_km'], 
                    row['elevation_gain'], 
                    row['difficulty'], 
                    row['terrain_type'], 
                    row['tags']
                )
                routes.append(route)
        return routes

    @staticmethod
    def save_routes(routes, path):
        if not routes:
            return
        
        with open(path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'id', 'name', 'region', 'start_lat', 'start_lon', 
                'end_lat', 'end_lon', 'length_km', 'elevation_gain', 
                'difficulty', 'terrain_type', 'tags'
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for route in routes:
                route_data = {
                    'id': route.id,
                    'name': route.name,
                    'region': route.region,
                    'start_lat': route.start_lat,
                    'start_lon': route.start_lon,
                    'end_lat': route.end_lat,
                    'end_lon': route.end_lon,
                    'length_km': route.length_km,
                    'elevation_gain': route.elevation_gain,
                    'difficulty': route.difficulty,
                    'terrain_type': route.terrain_type,
                    'tags': ','.join(route.tags)
                }
                writer.writerow(route_data)
