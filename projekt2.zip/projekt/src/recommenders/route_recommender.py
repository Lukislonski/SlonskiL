# src/recommenders/route_recommender.py

from src.models.weather_data import WeatherData
from src.models.route import Route

class RouteRecommender:
    def __init__(self, routes, weather_data):
        self.routes = routes  # Lista tras
        self.weather_data = weather_data  # Lista danych pogodowych

    def generate_recommendations(self, user_pref):
        recommendations = []

        for route in self.routes:
            if route.matches_preferences(user_pref):
                weather = self.get_weather_for_region(route.region)

                if weather:
                    comfort = weather.comfort_index()

                    # Obliczanie szacowanego czasu przejścia
                    hours, minutes = route.estimate_time()

                    category = self.categorize_route(route)

                    recommendations.append({
                        "name": route.name,
                        "region": route.region,
                        "length_km": route.length_km,
                        "difficulty": f"{route.difficulty}",
                        "estimated_time": f"{hours}h {minutes}min",
                        "comfort_index": f"{comfort}",
                        "category": category
                    })
        
        recommendations.sort(key=lambda x: int(x['comfort_index'].split('/')[0]), reverse=True)
        
        return recommendations

    def get_weather_for_region(self, region):
        for weather in self.weather_data:
            if weather.location_id.strip().lower() == region.strip().lower():
                return weather
        return None

    def categorize_route(self, route):
        categories = []

        # Kategoria Rodzinna
        if route.difficulty <= 2 and route.length_km <= 5:
            categories.append("Rodzinna")

        # Kategoria Widokowa
        if "viewpoint" in route.tags or "scenic" in route.tags:
            categories.append("Widokowa")

        # Kategoria Sportowa
        if route.difficulty >= 3 or route.elevation_gain >= 300:
            categories.append("Sportowa")

        # Kategoria Ekstremalna
        if route.difficulty >= 4 or "alpine" in route.tags:
            categories.append("Ekstremalna")

        if not categories:
            categories.append("Rodzinna")

        return ", ".join(categories)
