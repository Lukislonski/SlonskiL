# src/ui/user_interface.py

from src.models.user_preference import UserPreference

class UserInterface:
    def __init__(self):
        self.user_pref = None

    def get_user_preferences(self):
        
        # Pobieranie preferowanej temperatury
        while True:
            try:
                preferred_temp = float(input("Podaj preferowaną temperaturę (w °C): "))
                if preferred_temp < 1:
                    print("Temperatura musi być większa lub równa 1°C.")
                else:
                    break
            except ValueError:
                print("Proszę podać liczbę.")

        # Pobieranie dopuszczalnych opadów
        while True:
            try:
                max_precipitation = float(input("Podaj dopuszczalne opady (w mm): "))
                if max_precipitation < 0:
                    print("Opady muszą być większe lub równe 0 mm.")
                else:
                    break
            except ValueError:
                print("Proszę podać liczbę.")

        # Pobieranie maksymalnej trudności trasy (1-5)
        while True:
            try:
                max_difficulty = int(input("Podaj maksymalną trudność trasy (1-5): "))
                if 1 <= max_difficulty <= 5:
                    break
                else:
                    print("Trudność trasy musi być liczbą całkowitą z zakresu 1-5.")
            except ValueError:
                print("Proszę podać liczbę całkowitą między 1 a 5.")

        # Pobieranie maksymalnej długości trasy
        while True:
            try:
                max_length = float(input("Podaj maksymalną długość trasy (w km): "))
                if max_length < 1:
                    print("Długość trasy musi być większa lub równa 1 km.")
                else:
                    break
            except ValueError:
                print("Proszę podać liczbę.")

        self.user_pref = UserPreference(preferred_temp, max_precipitation, max_difficulty, max_length)

    def display_recommendations(self, recommendations):
        print("\nRekomendowane trasy:\n")
        for i, rec in enumerate(recommendations):
            print(f"{i + 1}. {rec['name']} ({rec['region']})")
            print(f"  Długość: {rec['length_km']} km")
            print(f"  Trudność: {rec['difficulty']}/5")
            print(f"  Szacowany czas: {rec['estimated_time']}")
            print(f"  Komfort pogodowy: {rec['comfort_index']}/100")
            print(f"  Kategoria: {rec['category']}")
            print("-" * 40)
