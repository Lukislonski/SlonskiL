# src/models/weather_data.py

class WeatherData:
    def __init__(self, date, location_id, avg_temp, min_temp, max_temp, precipitation, sunshine_hours, cloud_cover):
        self._date = date
        self._location_id = location_id
        self._avg_temp = float(avg_temp)
        self._min_temp = float(min_temp)
        self._max_temp = float(max_temp)
        self._precipitation = float(precipitation)
        self._sunshine_hours = float(sunshine_hours)
        self._cloud_cover = float(cloud_cover)

    @property
    def date(self):
        return self._date

    @property
    def location_id(self):
        return self._location_id

    @property
    def avg_temp(self):
        return self._avg_temp

    @property
    def precipitation(self):
        return self._precipitation

    @property
    def sunshine_hours(self):
        return self._sunshine_hours

    @property
    def cloud_cover(self):
        return self._cloud_cover

    def is_sunny(self):
        # Sprawdza, czy dzień był słoneczny.
        return self._sunshine_hours > 6 and self._cloud_cover < 40

    def is_rainy(self):
        # Sprawdza, czy dzień był deszczowy.
        return self._precipitation > 1.0

    def comfort_index(self):
        score = 0

        if 18 <= self._avg_temp <= 24:
            score += 50
        elif 15 <= self._avg_temp < 18 or 24 < self._avg_temp <= 27:
            score += 35
        elif 10 <= self._avg_temp < 15 or 27 < self._avg_temp <= 30:
            score += 20
        else:
            score += 5

        # Opady
        if self._precipitation == 0:
            score += 30
        elif self._precipitation < 1.0:
            score += 15
        elif self._precipitation < 3.0:
            score += 5
        else:
            score -= 10

        # Zachmurzenie
        if self._cloud_cover < 20:
            score += 20
        elif self._cloud_cover < 40:
            score += 10
        elif self._cloud_cover < 70:
            score += 0
        else:
            score -= 10

        return max(0, min(100, score))
