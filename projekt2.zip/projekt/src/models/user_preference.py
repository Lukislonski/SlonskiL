# src/models/user_preference.py

class UserPreference:
    def __init__(self, preferred_temp, max_precipitation, max_difficulty, max_length):
        self.preferred_temp = float(preferred_temp)
        self.max_precipitation = float(max_precipitation)
        self.max_difficulty = int(max_difficulty)
        self.max_length = float(max_length)

    def update_preferences(self, preferred_temp=None, max_precipitation=None, max_difficulty=None, max_length=None):
        if preferred_temp is not None:
            self.preferred_temp = float(preferred_temp)
        if max_precipitation is not None:
            self.max_precipitation = float(max_precipitation)
        if max_difficulty is not None:
            self.max_difficulty = int(max_difficulty)
        if max_length is not None:
            self.max_length = float(max_length)
