# src/models/route.py

class Route:
    def __init__(self, id, name, region, start_lat, start_lon, end_lat, end_lon, length_km, elevation_gain, difficulty, terrain_type, tags):
        self.id = id
        self.name = name
        self.region = region
        self.start_lat = float(start_lat)
        self.start_lon = float(start_lon)
        self.end_lat = float(end_lat)
        self.end_lon = float(end_lon)
        self.length_km = float(length_km)
        self.elevation_gain = float(elevation_gain)
        self.difficulty = int(difficulty)
        self.terrain_type = terrain_type
        self.tags = tags.split(',')

        # Oblicza środek trasy
    def calculate_midpoint(self):
        mid_lat = (self.start_lat + self.end_lat) / 2
        mid_lon = (self.start_lon + self.end_lon) / 2
        return mid_lat, mid_lon

    def estimate_time(self):
        # Szacowanie czasu przejścia na podstawie długości trasy, przewyższenia i trudności
        base_time = self.length_km / 5.0

        # Dodanie czasu za przewyższenie
        time_for_elevation = self.elevation_gain / 600

        # Trudność jako mnożnik (1.0 do 1.8)
        difficulty_multiplier = 1 + (self.difficulty - 1) * 0.2

        total_time = (base_time + time_for_elevation) * difficulty_multiplier
        hours = int(total_time)
        minutes = int((total_time - hours) * 60)

        return hours, minutes

    def matches_preferences(self, user_pref):
        return (self.length_km <= user_pref.max_length and
                self.difficulty <= user_pref.max_difficulty)
