#src/extractors/scraping_rules_manager.py
import json
import os

class ScrapingRulesManager:
    """
    Zarządza regułami scrapingu dla różnych portali turystycznych.
    Reguły są ładowane z plików JSON.
    """
    def __init__(self, rules_dir='data/scraping_rules'):
        self.rules_dir = rules_dir
        self.rules = {}
        self._load_all_rules()

    def _load_all_rules(self):
        """
        Ładuje wszystkie pliki JSON z katalogu reguł.
        """
        if not os.path.exists(self.rules_dir):
            print(f"Błąd: Katalog z regułami scrapingu '{self.rules_dir}' nie istnieje.")
            return

        for filename in os.listdir(self.rules_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(self.rules_dir, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        rule_set = json.load(f)
                        portal_name = rule_set.get('portal_name', os.path.splitext(filename)[0])
                        self.rules[portal_name] = rule_set
                    print(f"Załadowano reguły dla portalu: {portal_name} z pliku {filename}")
                except json.JSONDecodeError:
                    print(f"Błąd: Niepoprawny format JSON w pliku {filename}")
                except Exception as e:
                    print(f"Błąd podczas ładowania pliku {filename}: {e}")

    def get_rules(self, portal_name):
        """
        Zwraca zestaw reguł dla podanego portalu.
        """
        return self.rules.get(portal_name)

    def list_portals(self):
        """
        Zwraca listę dostępnych nazw portali, dla których załadowano reguły.
        """
        return list(self.rules.keys())

# Przykład użycia (do usunięcia po integracji)
if __name__ == "__main__":
    # Utwórz tymczasowy plik reguł dla testu
    os.makedirs('../../data/scraping_rules', exist_ok=True)
    with open('../../data/scraping_rules/test_portal.json', 'w', encoding='utf-8') as f:
        json.dump({"portal_name": "TestPortal", "rules": {"title": {"selector": "h1", "type": "text"}}}, f)

    manager = ScrapingRulesManager('../../data/scraping_rules')
    print("\nDostępne portale:", manager.list_portals())

    rysy_rules = manager.get_rules("TestPortal")
    if rysy_rules:
        print("\nReguły dla TestPortal:", json.dumps(rysy_rules, indent=2))
    else:
        print("Nie znaleziono reguł dla TestPortal.")

    # Usuń tymczasowy plik reguł po teście
    os.remove('../../data/scraping_rules/test_portal.json')
    os.rmdir('../../data/scraping_rules')