# src/models/user_preferences.py

from dataclasses import dataclass
from typing import Optional

@dataclass
class UserPreferences:
    """
    Klasa przechowująca preferencje użytkownika dotyczące tras.
    """
    preferred_temperature: Optional[float] = None
    max_precipitation: Optional[float] = None
    max_difficulty: Optional[int] = None
    max_length_km: Optional[float] = None

    def __post_init__(self):
        # Sprawdzenie i konwersja typów, jeśli wartości zostały przekazane jako str
        # np. z wejścia użytkownika
        if isinstance(self.preferred_temperature, str):
            try:
                self.preferred_temperature = float(self.preferred_temperature)
            except ValueError:
                self.preferred_temperature = None
        
        if isinstance(self.max_precipitation, str):
            try:
                self.max_precipitation = float(self.max_precipitation)
            except ValueError:
                self.max_precipitation = None
        
        if isinstance(self.max_difficulty, str):
            try:
                self.max_difficulty = int(self.max_difficulty)
            except ValueError:
                self.max_difficulty = None
        
        if isinstance(self.max_length_km, str):
            try:
                self.max_length_km = float(self.max_length_km)
            except ValueError:
                self.max_length_km = None

        # Można dodać dodatkową walidację, np. zakresy wartości
        if self.max_difficulty is not None and not (1 <= self.max_difficulty <= 5):
            print("Ostrzeżenie: Maksymalna trudność powinna być w zakresie 1-5.")
            self.max_difficulty = None