# src/analyzers/text_processor.py

import re
from typing import List, Tuple, Optional, Dict

class TextProcessor:
    """
    Klasa do ekstrakcji informacji z tekstu za pomocą wyrażeń regularnych.
    """
    # Wzorce wyrażeń regularnych zgodnie z wytycznymi
    _TIME_PATTERNS = r'(\d+(?:\.\d+)?)\s*(?:h|godz|hours?)|(\d+)\s*(?:min|minut)'
    _ELEVATION_PATTERNS = r'(\d{3,4})\s*m\s*n\.p\.m\.'
    _COORD_PATTERNS = r'([NS]?\d{1,2}[°º]\d{1,2}[\'′]\d{1,2}[\"″]?)\s*,?\s*([EW]?\d{1,3}[°º]\d{1,2}[\'′]\d{1,2}[\"″]?)'

    # Proste wzorce na punkty charakterystyczne i ostrzeżenia (można rozbudować)
    _POINT_KEYWORDS = r'(schronisko|szczyt|przełęcz|jezioro|wodospad|ruiny|punkt widokowy)'
    _WARNING_KEYWORDS = r'(uwaga|ostrzeżenie|zagrożenie|śliskie kamienie|ekspozycja|spadające kamienie|burza)'

    def extract_times(self, text: str) -> List[str]:
        """Wydobywa różne formaty czasów przejścia."""
        found_times = re.findall(self._TIME_PATTERNS, text, re.IGNORECASE)
        result = []
        for h_match, m_match in found_times:
            if h_match:
                result.append(f"{h_match}h") # np. "2.5h"
            if m_match:
                result.append(f"{m_match}min") # np. "150min"
        return result

    def convert_time_to_minutes(self, time_str: str) -> Optional[int]:
        """Konwertuje czas tekstowy (np. '2h 30min') na minuty."""
        total_minutes = 0

        # Sprawdź format Xh Ymin
        match_hm = re.match(r'(\d+)(?:h|godz)?\s*(\d+)(?:min)?', time_str, re.IGNORECASE)
        if match_hm:
            hours = int(match_hm.group(1)) if match_hm.group(1) else 0
            minutes = int(match_hm.group(2)) if match_hm.group(2) else 0
            return hours * 60 + minutes

        # Sprawdź format Xh
        match_h = re.match(r'(\d+(?:\.\d+)?)\s*(?:h|godz|hours?)', time_str, re.IGNORECASE)
        if match_h:
            return int(float(match_h.group(1)) * 60)

        # Sprawdź format Xmin
        match_m = re.match(r'(\d+)\s*(?:min|minut)', time_str, re.IGNORECASE)
        if match_m:
            return int(match_m.group(1))

        return None # Jeśli format nie pasuje

    def identify_characteristic_points(self, text: str) -> List[str]:
        """Identyfikuje punkty charakterystyczne na trasie."""
        found_points = re.findall(self._POINT_KEYWORDS, text, re.IGNORECASE)
        return list(set(found_points)) # Użyj set, żeby usunąć duplikaty

    def recognize_warnings(self, text: str) -> List[str]:
        """Rozpoznaje ostrzeżenia i zagrożenia w opisach tras."""
        found_warnings = re.findall(self._WARNING_KEYWORDS, text, re.IGNORECASE)
        return list(set(found_warnings))

    def standardize_coordinates(self, text: str) -> List[Tuple[str, str]]:
        """Standaryzuje różne formaty zapisu współrzędnych geograficznych."""
        found_coords = re.findall(self._COORD_PATTERNS, text, re.IGNORECASE)
        # W tym miejscu dla "studenta" zakładam, że wystarczy zwrócić znalezione pary.
        # Bardziej zaawansowana standaryzacja (np. na format dziesiętny) wymagałaby więcej kodu.
        return [ (c1.strip(), c2.strip()) for c1, c2 in found_coords ]

    def extract_elevations(self, text: str) -> List[str]:
        """Wydobywa wysokości z tekstu."""
        found_elevations = re.findall(self._ELEVATION_PATTERNS, text, re.IGNORECASE)
        return list(set(found_elevations)) # Użyj set, żeby usunąć duplikaty