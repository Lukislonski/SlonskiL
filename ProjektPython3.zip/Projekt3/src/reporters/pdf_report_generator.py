# src/reporters/pdf_report_generator.py

from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from typing import List, Dict, Any
from datetime import date
import os

# Importy dla obsługi czcionek
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas # Dodajemy import canvas

class PDFReportGenerator:
    """
    Generuje wielostronicowe raporty PDF z rekomendacjami tras.
    """
    def __init__(self, output_dir: str = 'reports/'):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

        # Rejestracja czcionki obsługującej polskie znaki
        try:
            font_path = "C:/Windows/Fonts/arial.ttf"
            pdfmetrics.registerFont(TTFont('ArialUnicode', font_path))
            print(f"Czcionka 'ArialUnicode' zarejestrowana z pliku: {font_path}")
        except Exception as e:
            print(f"Błąd podczas rejestracji czcionki ArialUnicode: {e}. Domyślna czcionka może nie obsługiwać polskich znaków.")

        self.styles = getSampleStyleSheet()
        self.styles['Normal'].fontName = 'ArialUnicode'
        self.styles['h1'].fontName = 'ArialUnicode'
        self.styles['h2'].fontName = 'ArialUnicode'
        self.styles['h3'].fontName = 'ArialUnicode'

        self.styles.add(ParagraphStyle(name='TableCell',
                                       parent=self.styles['Normal'],
                                       fontName='ArialUnicode',
                                       fontSize=8,
                                       leading=9,
                                       wordWrap='CJK'))

    # NOWA FUNKCJA ZWROTNA DLA STOPKI I NUMERACJI STRON
    def _header_footer_callback(self, canvas_obj: canvas.Canvas, doc):
        canvas_obj.saveState()
        
        # Stopka: Informacja o raporcie
        canvas_obj.setFont('ArialUnicode', 9)
        canvas_obj.drawCentredString(A4[0] / 2.0, 30, "Raport rekomendacji tras turystycznych - Wygenerowano " + date.today().strftime('%Y-%m-%d'))
        
        # Numer strony
        page_num_text = f"Strona {doc.page}"
        canvas_obj.drawString(A4[0] - inch, 30, page_num_text) # Prawy dolny róg
        
        # Opcjonalny nagłówek (możesz go dostosować lub usunąć)
        # canvas_obj.drawCentredString(A4[0] / 2.0, A4[1] - 30, "System Rekomendacji Tras")

        canvas_obj.restoreState()

    def generate_report(self, filename: str, recommendations: List[Dict[str, Any]], search_params: Dict[str, Any], charts: List[Any] = None):
        filepath = os.path.join(self.output_dir, filename)
        doc = SimpleDocTemplate(filepath, pagesize=A4)
        story = []

        # Strona tytułowa
        story.append(Paragraph("<b>Raport Rekomendacji Tras Turystycznych</b>", self.styles['h1']))
        story.append(Spacer(1, 0.5 * inch))
        story.append(Paragraph(f"Data generowania: {date.today().strftime('%Y-%m-%d')}", self.styles['Normal']))
        story.append(Paragraph(f"Parametry wyszukiwania: {self._format_params(search_params)}", self.styles['Normal']))
        story.append(PageBreak())

        # Spis treści (uproszczony, ręczny dla studenta)
        story.append(Paragraph("<b>Spis Treści</b>", self.styles['h2']))
        story.append(Paragraph("1. Podsumowanie", self.styles['Normal']))
        story.append(Paragraph("2. Szczegółowe rekomendacje tras", self.styles['Normal']))
        story.append(Paragraph("3. Wykresy porównawcze", self.styles['Normal']))
        story.append(Paragraph("4. Tabela zbiorcza wszystkich analizowanych tras", self.styles['Normal']))
        story.append(PageBreak())

        # Podsumowanie wykonawcze
        story.append(Paragraph("<b>1. Podsumowanie wykonawcze</b>", self.styles['h2']))
        story.append(Paragraph(f"Analizowano {len(recommendations)} potencjalnych tras. Z tego {len(recommendations)} spełniało kryteria i zostało rekomendowanych.", self.styles['Normal']))
        avg_comfort = sum(rec['comfort_index'] for rec in recommendations) / len(recommendations) if recommendations else 0
        story.append(Paragraph(f"Średni komfort pogodowy rekomendowanych tras: {avg_comfort:.0f}%", self.styles['Normal']))
        story.append(Spacer(1, 0.2 * inch))

        story.append(PageBreak())

        # Wykresy porównawcze
        if charts:
            story.append(Paragraph("<b>3. Wykresy porównawcze</b>", self.styles['h2']))
            story.append(Spacer(1, 0.1 * inch))
            for chart_path in charts:
                try:
                    img = Image(chart_path, width=2.8*inch, height=2.8*inch)
                    img.hAlign = 'CENTER'
                    story.append(img)
                    story.append(Spacer(1, 0.2 * inch))
                    story.append(PageBreak())
                except Exception as e:
                    print(f"Błąd podczas wczytywania lub dodawania wykresu '{chart_path}' do PDF: {e}")

        # Szczegółowe opisy rekomendowanych tras
        story.append(Paragraph("<b>2. Szczegółowe rekomendacje tras</b>", self.styles['h2']))
        for i, rec in enumerate(recommendations):
            story.append(Paragraph(f"<b>{i + 1}. {rec.get('name', 'N/A')} ({rec.get('region', 'N/A')})</b>", self.styles['h3']))
            story.append(Paragraph(f"Długość: {rec.get('length_km', 'N/A'):.1f} km", self.styles['Normal']))
            story.append(Paragraph(f"Trudność: {rec.get('difficulty', 'N/A')}/5", self.styles['Normal']))
            story.append(Paragraph(f"Szacowany czas: {rec.get('estimated_time', 'N/A')}", self.styles['Normal']))
            story.append(Paragraph(f"Komfort pogodowy: {rec.get('comfort_index', 'N/A')}/100", self.styles['Normal']))
            story.append(Paragraph(f"Kategoria: {rec.get('category', 'N/A')}", self.styles['Normal']))
            if rec.get('description'):
                story.append(Paragraph(f"Opis: {rec['description'][:200]}...", self.styles['Normal']))

            if rec.get('extracted_points'):
                points_to_display = rec['extracted_points'][:5]
                story.append(Paragraph(f"Punkty charakterystyczne: {', '.join(points_to_display)}", self.styles['Normal']))
            if rec.get('extracted_warnings'):
                warnings_to_display = rec['extracted_warnings'][:3]
                story.append(Paragraph(f"Ostrzeżenia: {', '.join(warnings_to_display)}", self.styles['Normal']))

            if rec.get('reviews'):
                story.append(Paragraph("<i>Wybrane recenzje:</i>", self.styles['Normal']))
                review_data = [['Ocena', 'Sentyment', 'Data', 'Fragment']]
                for r in rec['reviews'][:3]:
                    text_fragment = r.get('text', '')
                    fragment_paragraph = Paragraph(text_fragment, self.styles['TableCell'])
                    review_data.append([
                        Paragraph(str(r.get('rating_normalized', 'N/A')), self.styles['TableCell']),
                        Paragraph(r.get('sentiment', 'N/A'), self.styles['TableCell']),
                        Paragraph(str(r.get('date', 'N/A')), self.styles['TableCell']),
                        fragment_paragraph
                    ])
                
                review_table = Table(review_data, colWidths=[0.8*inch, 0.8*inch, 1.2*inch, 3.2*inch]) 
                review_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'ArialUnicode'),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ]))
                story.append(review_table)
                story.append(Spacer(1, 0.1 * inch))

            story.append(Spacer(1, 0.3 * inch))
            if i < len(recommendations) - 1:
                story.append(PageBreak())

        # Tabela zbiorcza wszystkich analizowanych tras
        story.append(Paragraph("<b>4. Tabela zbiorcza wszystkich analizowanych tras</b>", self.styles['h2']))
        table_data = [
            [Paragraph(header, self.styles['TableCell']) for header in ['Nazwa', 'Region', 'Długość (km)', 'Trudność', 'Szacowany czas', 'Komfort Pogody', 'Kategoria']]
        ]
        for rec in recommendations:
            table_data.append([
                Paragraph(rec.get('name', 'N/A'), self.styles['TableCell']),
                Paragraph(rec.get('region', 'N/A'), self.styles['TableCell']),
                Paragraph(f"{rec.get('length_km', 'N/A'):.1f}", self.styles['TableCell']),
                Paragraph(str(rec.get('difficulty', 'N/A')), self.styles['TableCell']),
                Paragraph(rec.get('estimated_time', 'N/A'), self.styles['TableCell']),
                Paragraph(str(rec.get('comfort_index', 'N/A')), self.styles['TableCell']),
                Paragraph(rec.get('category', 'N/A'), self.styles['TableCell'])
            ])

        col_widths_main_table = [
            1.2*inch,
            0.8*inch,
            0.7*inch,
            0.7*inch,
            1.0*inch,
            0.8*inch,
            0.9*inch
        ]
        table = Table(table_data, colWidths=col_widths_main_table)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.Color(0.8, 0.8, 0.8)),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'ArialUnicode'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ]))
        story.append(table)
        story.append(PageBreak())

        # Aneks z danymi źródłowymi (tylko tekstowo)
        story.append(Paragraph("<b>Aneks - Dane źródłowe</b>", self.styles['h2']))
        story.append(Paragraph("Dane dotyczące tras pochodzą z pliku routes.csv.", self.styles['Normal']))
        story.append(Paragraph("Dane pogodowe pochodzą z pliku weather.csv.", self.styles['Normal']))
        story.append(Paragraph("Opisy tras i recenzje zostały pozyskane z symulowanych stron HTML.", self.styles['Normal']))

        try:
            # Użycie funkcji zwrotnej dla stopek i numeracji stron
            doc.build(story, onFirstPage=self._header_footer_callback, onLaterPages=self._header_footer_callback)
            print(f"Raport PDF '{filename}' został wygenerowany w {self.output_dir}")
        except Exception as e:
            print(f"Błąd podczas generowania raportu PDF: {e}")

    def _format_params(self, params: Dict[str, Any]) -> str:
        return ", ".join(f"{k}: {v}" for k, v in params.items())