# src/reporters/chart_generator.py

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from typing import List, Dict, Any
import os
from math import pi
import time

class ChartGenerator:
    """
    Generuje różne wykresy na podstawie danych o trasach.
    """
    def __init__(self, output_dir: str = 'reports/charts/'):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def generate_length_histogram(self, recommendations: List[Dict[str, Any]], filename: str = 'length_histogram.png'):
        lengths = [rec['length_km'] for rec in recommendations if 'length_km' in rec and rec['length_km'] is not None]
        plt.figure(figsize=(10, 3))
        sns.histplot(lengths, bins=10, kde=True)
        plt.title('Rozkład Długości Tras')
        plt.xlabel('Długość (km)')
        plt.ylabel('Liczba tras')
        plt.tight_layout()
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath, dpi=200)
        plt.close()
        print(f"Wykres '{filename}' zapisany w {self.output_dir}")
        time.sleep(0.1)
        return filepath

    def generate_category_pie_chart(self, recommendations: List[Dict[str, Any]], filename: str = 'category_pie_chart.png'):
        categories = [rec['category'] for rec in recommendations if 'category' in rec and rec['category'] is not None]
        category_counts = pd.Series(categories).value_counts()

        plt.figure(figsize=(6, 4)) # Zmieniono z (3, 3) na (6, 4) - więcej miejsca na tytuł i etykiety
        plt.pie(category_counts, labels=category_counts.index, autopct='%1.1f%%', startangle=140)
        plt.title('Udział Kategorii Tras')
        plt.axis('equal')
        plt.tight_layout()
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath, dpi=200)
        plt.close()
        print(f"Wykres '{filename}' zapisany w {self.output_dir}")
        time.sleep(0.1)
        return filepath

    def generate_user_rating_bar_chart(self, recommendations: List[Dict[str, Any]], filename: str = 'user_rating_bar_chart.png'):
        all_ratings = []
        for rec in recommendations:
            if 'reviews' in rec and rec['reviews']:
                for review in rec['reviews']:
                    if 'rating_normalized' in review and review['rating_normalized'] is not None:
                        all_ratings.append(review['rating_normalized'])

        if not all_ratings:
            print(f"Brak danych o ocenach użytkowników do wygenerowania wykresu '{filename}'.")
            return None

        rating_counts = pd.Series(all_ratings).value_counts().sort_index()

        plt.figure(figsize=(6, 3)) # Zmieniono z (10, 6) na (6, 3) - mniejszy i bardziej kompaktowy
        sns.barplot(x=rating_counts.index, y=rating_counts.values, hue=rating_counts.index, palette='viridis', legend=False)
        plt.title('Rozkład Ocen Użytkowników')
        plt.xlabel('Ocena (0-100)')
        plt.ylabel('Liczba recenzji')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath, dpi=200)
        plt.close()
        print(f"Wykres '{filename}' zapisany w {self.output_dir}")
        time.sleep(0.1)
        return filepath

    def generate_popularity_heatmap(self, recommendations: List[Dict[str, Any]], filename: str = 'popularity_heatmap.png'):
        df_heatmap_data = pd.DataFrame(recommendations)

        if df_heatmap_data.empty or not all(k in df_heatmap_data.columns for k in ['region', 'category', 'comfort_index']):
            print(f"Brak wystarczających danych do wygenerowania heatmapy '{filename}'.")
            return None

        pivot_table = df_heatmap_data.pivot_table(
            index='region',
            columns='category',
            values='comfort_index',
            aggfunc='mean'
        )

        plt.figure(figsize=(14, 6))
        sns.heatmap(pivot_table, annot=True, fmt=".0f", cmap="YlGnBu", linewidths=.5)
        plt.title('Heatmapa Komfortu Pogodowego (Region vs. Kategoria)')
        plt.xlabel('Kategoria')
        plt.ylabel('Region')
        plt.tight_layout()
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath, dpi=200)
        plt.close()
        print(f"Wykres '{filename}' zapisany w {self.output_dir}")
        time.sleep(0.1)
        return filepath

    def generate_elevation_profile(self, route_name: str, elevation_data: List[float], filename_suffix: str = '_elevation_profile.png'):
        if not elevation_data:
            print(f"Brak danych wysokościowych dla '{route_name}'. Nie generuję profilu wysokościowego.")
            return None

        plt.figure(figsize=(12, 5))
        plt.plot(elevation_data, color='blue')
        plt.title(f'Profil Wysokościowy dla Trasy: {route_name}')
        plt.xlabel('Dystans (punkty danych)')
        plt.ylabel('Wysokość (m)')
        plt.grid(True)
        plt.tight_layout()
        safe_route_name = route_name.replace(" ", "_").replace("/", "_").replace("\\", "_").replace(":", "_").replace("-", "_")
        filename = f"elevation_profile_{safe_route_name}{filename_suffix}"
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath, dpi=200)
        plt.close()
        print(f"Wykres '{filename}' zapisany w {self.output_dir}")
        time.sleep(0.1)
        return filepath

    def generate_radar_chart(self, route_name: str, scores: Dict[str, float], filename_suffix: str = '_radar_chart.png'):
        if not scores:
            print(f"Brak danych dla wykresu radarowego dla '{route_name}'. Nie generuję wykresu.")
            return None

        categories = list(scores.keys())
        values = list(scores.values())

        values += values[:1]

        angles = [n / float(len(categories)) * 2 * pi for n in range(len(categories))]
        angles += angles[:1]

        plt.figure(figsize=(8, 8))
        ax = plt.subplot(111, polar=True)

        ax.plot(angles, values, linewidth=2, linestyle='solid', label=route_name)
        ax.fill(angles, values, 'b', alpha=0.1)

        ax.set_yticks([20, 40, 60, 80, 100])
        ax.set_yticklabels(["20", "40", "60", "80", "100"], color="grey", size=8)
        ax.set_ylim(0, 100)

        plt.xticks(angles[:-1], categories)
        plt.title(f'Wykres Radarowy dla Trasy: {route_name}', size=14, color='blue', y=1.1)
        plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))

        plt.tight_layout()
        safe_route_name = route_name.replace(" ", "_").replace("/", "_").replace("\\", "_").replace(":", "_").replace("-", "_")
        filename = f"radar_chart_{safe_route_name}{filename_suffix}"
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath, dpi=200)
        plt.close()
        print(f"Wykres '{filename}' zapisany w {self.output_dir}")
        time.sleep(0.1)
        return filepath