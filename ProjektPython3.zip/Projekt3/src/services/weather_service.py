# src/services/weather_service.py
import requests
import json
from typing import Optional, Dict, Any
from datetime import date
import os

# Importuj klucz API z pliku konfiguracyjnego
from src.config.api_keys import OPENWEATHER_API_KEY 

class WeatherService:
    def __init__(self, api_key: str = OPENWEATHER_API_KEY):
        if not api_key:
            raise ValueError("Klucz API OpenWeatherMap nie został podany.")
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"
        print(f"[WeatherService] Zainicjowano. Używam klucza API (pierwsze 5 znaków): {api_key[:5]}*****")

    def get_current_weather_for_coords(self, lat: float, lon: float) -> Optional[Dict[str, Any]]:
        """
        Pobiera aktualne dane pogodowe dla danej lokalizacji geograficznej z OpenWeatherMap API.
        Zwraca słownik z kluczowymi danymi pogodowymi lub None w przypadku błędu.
        """
        params = {
            "lat": lat,
            "lon": lon,
            "appid": self.api_key,
            "units": "metric",  # Stopnie Celsjusza
            "lang": "pl"        # Język polski
        }
        
        print(f"[WeatherService] Pobieram pogodę z API dla: Lat={lat}, Lon={lon}")
        try:
            response = requests.get(self.base_url, params=params, timeout=10)
            print(f"[WeatherService] Zapytanie do OpenWeatherMap: {response.url}")
            print(f"[WeatherService] Status odpowiedzi API: {response.status_code}")
            
            response.raise_for_status()  # Wyrzuca wyjątek dla statusów 4xx/5xx

            data = response.json()
            # print(f"Pełna odpowiedź JSON z API: {json.dumps(data, indent=2)}") # Odkomentuj dla szczegółowych logów
            
            avg_temp = data.get('main', {}).get('temp')
            # Sumuj opady deszczu i śniegu w ciągu ostatniej godziny, jeśli dostępne
            precipitation = data.get('rain', {}).get('1h', 0.0) + data.get('snow', {}).get('1h', 0.0)
            weather_description = data.get('weather', [{}])[0].get('description', 'N/A')

            result = {
                'date': str(date.today()), # Data dzisiejsza, bo to aktualna pogoda
                'location_id': f"{lat},{lon}", # Możesz użyć współrzędnych jako ID
                'avg_temp': avg_temp,
                'min_temp': data.get('main', {}).get('temp_min'),
                'max_temp': data.get('main', {}).get('temp_max'),
                'precipitation': precipitation,
                'sunshine_hours': None, # OpenWeatherMap Current Weather API zazwyczaj tego nie zwraca
                'cloud_cover': data.get('clouds', {}).get('all'),
                'wind_speed': data.get('wind', {}).get('speed'),
                'weather_description': weather_description,
                'humidity': data.get('main', {}).get('humidity'),
                'pressure': data.get('main', {}).get('pressure')
            }
            print(f"[WeatherService] Pobrana pogoda z API: Temperatura={result['avg_temp']}°C, Opady={result['precipitation']}mm, Opis='{result['weather_description']}'")
            return result
        
        except requests.exceptions.Timeout:
            print(f"[WeatherService] Błąd: Limit czasu dla zapytania do OpenWeatherMap dla Lat={lat}, Lon={lon}.")
            return None
        except requests.exceptions.RequestException as e:
            print(f"[WeatherService] Błąd podczas zapytania do OpenWeatherMap API dla Lat={lat}, Lon={lon}: {e}")
            if response is not None:
                print(f"[WeatherService] Odpowiedź API (tekst): {response.text}")
            return None
        except json.JSONDecodeError as e:
            print(f"[WeatherService] Błąd parsowania odpowiedzi JSON z OpenWeatherMap API dla Lat={lat}, Lon={lon}: {e}")
            return None
        except Exception as e:
            print(f"[WeatherService] Nieoczekiwany błąd w WeatherService dla Lat={lat}, Lon={lon}: {e}")
            return None