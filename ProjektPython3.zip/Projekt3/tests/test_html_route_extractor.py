# tests/test_html_route_extractor.py

import unittest
from src.extractors.html_route_extractor import HTMLRouteExtractor
import os

class TestHTMLRouteExtractor(unittest.TestCase):
    def setUp(self):
        self.extractor = HTMLRouteExtractor()
        self.test_html_content = """
        <div class="route-info">
            <h1>Szlak na Rysy - Opis Trasy</h1>
            <p class="route-description">
                To jest wymagająca trasa w Tatrach Wysokich. Czas przejścia to około <b>8h 30min</b> w jedną stronę.
                Po drodze znajduje się <b>schronisko</b> w Dolinie Pięciu Stawów Polskich. Uważaj na wysokie przewyższenia.
                Szczyt Rysów znajduje się na wysokości 2499 m n.p.m.
                Współrzędne początku trasy: N49°11′46″ E20°05′33″.
                Wiosną (kwiecień) i wczesnym latem (czerwiec) mogą występować płaty śniegu.
                Ostrzeżenie: Trasa bardzo wymagająca technicznie, tylko dla doświadczonych turystów.
            </p>
            <table class="route-params">
                <tr><td>Długość całkowita:</td><td>18.5 km</td></tr>
                <tr><td>Szacowany czas:</td><td>8-10 godzin</td></tr>
                <tr><td>Przewyższenie:</td><td>1650 m</td></tr>
                <tr><td>Trudność:</td><td>5/5</td></tr>
            </table>
            <div class="user-review">
                <span class="rating">★★★★★</span>
                <p>Wspaniałe widoki! Byłem 15.08.2023, pogoda dopisała, trasa super. Ocena 9/10.</p>
            </div>
            <div class="user-review">
                <span class="rating">★★★☆☆</span>
                <p>Trasa trudna, kiepskie oznakowanie miejscami. Byłem w lipcu 2022, lało cały dzień.</p>
            </div>
            <div class="gallery"></div>
            <div id="map"></div>
        </div>
        """

    def test_extract_route_data(self):
        data = self.extractor.extract_route_data(self.test_html_content)

        self.assertEqual(data.get('name'), 'Szlak na Rysy - Opis Trasy')
        self.assertIn('wymagająca trasa', data.get('description'))

        self.assertAlmostEqual(data.get('length_km'), 18.5)
        self.assertEqual(data.get('elevation_gain'), 1650)
        self.assertEqual(data.get('difficulty'), 5)
        self.assertEqual(data.get('estimated_time_str'), '8-10 godzin')

        self.assertIn('8h', data.get('extracted_times'))
        self.assertIn('30min', data.get('extracted_times'))
        self.assertIn('schronisko', data.get('extracted_points'))
        self.assertIn('2499 m n.p.m.', data.get('extracted_elevations'))
        self.assertIn('Trasa bardzo wymagająca technicznie', data.get('extracted_warnings'))
        self.assertIn('N49°11′46″,E20°05′33″', data.get('extracted_coords'))


        self.assertTrue(data.get('has_gallery'))
        self.assertTrue(data.get('has_map'))

        self.assertIsInstance(data.get('reviews'), list)
        self.assertEqual(len(data['reviews']), 2)
        self.assertEqual(data['reviews'][0]['sentiment'], 'pozytywny')
        self.assertAlmostEqual(data['reviews'][0]['rating_normalized'], 5.0) # ★★★★★ == 5.0
        self.assertIn('widoki', data['reviews'][0]['aspects'])
        self.assertEqual(data['reviews'][1]['sentiment'], 'negatywny')
        self.assertAlmostEqual(data['reviews'][1]['rating_normalized'], 3.0) # ★★★☆☆ == 3.0