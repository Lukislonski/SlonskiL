# tests/test_web_data_collector.py

import unittest
import os
import tempfile
from unittest.mock import patch, MagicMock
from src.extractors.web_data_collector import WebDataCollector
from datetime import datetime, timedelta

class TestWebDataCollector(unittest.TestCase):
    def setUp(self):
        # Tworzymy tymczasowy katalog na cache, który zostanie usunięty po testach
        self.temp_cache_dir = tempfile.mkdtemp()
        self.collector = WebDataCollector(cache_dir=self.temp_cache_dir, cache_expiry_hours=0.01) # Krótki czas wygaśnięcia cache dla testów

    def tearDown(self):
        # Usuwamy wszystkie pliki w tymczasowym katalogu i sam katalog
        for f in os.listdir(self.temp_cache_dir):
            os.remove(os.path.join(self.temp_cache_dir, f))
        os.rmdir(self.temp_cache_dir)

    @patch('requests.get')
    def test_fetch_html_from_web(self, mock_get):
        mock_response = MagicMock()
        mock_response.text = "<html>Test</html>"
        mock_response.raise_for_status.return_value = None # Symuluj brak błędów
        mock_get.return_value = mock_response

        url = "http://example.com/test.html"
        filename = "test.html"
        html_content = self.collector.fetch_html(url, filename)

        self.assertEqual(html_content, "<html>Test</html>")
        mock_get.assert_called_once_with(url, timeout=10)
        self.assertTrue(os.path.exists(os.path.join(self.temp_cache_dir, filename)))

    @patch('requests.get')
    def test_fetch_html_from_cache(self, mock_get):
        filename = "cached_test.html"
        filepath = os.path.join(self.temp_cache_dir, filename)

        # Stwórz plik w cache z aktualną datą
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("<html>Cached Test</html>")
        os.utime(filepath, (datetime.now().timestamp(), datetime.now().timestamp())) # Ustaw czas modyfikacji na teraz

        url = "http://example.com/cached.html"
        html_content = self.collector.fetch_html(url, filename)

        self.assertEqual(html_content, "<html>Cached Test</html>")
        mock_get.assert_not_called() # Upewnij się, że nie było pobierania z sieci

    @patch('requests.get')
    def test_fetch_html_cache_expired(self, mock_get):
        filename = "expired_test.html"
        filepath = os.path.join(self.temp_cache_dir, filename)

        # Stwórz plik w cache z wygasłą datą
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("<html>Expired Cached Test</html>")
        # Ustaw czas modyfikacji na przeszłość, żeby cache wygasł
        old_time = datetime.now() - timedelta(hours=1) # 1 godzina temu
        os.utime(filepath, (old_time.timestamp(), old_time.timestamp()))

        mock_response = MagicMock()
        mock_response.text = "<html>New Content</html>"
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response

        url = "http://example.com/expired.html"
        html_content = self.collector.fetch_html(url, filename)

        self.assertEqual(html_content, "<html>New Content</html>")
        mock_get.assert_called_once_with(url, timeout=10) # Powinno być ponowne pobranie

    @patch('requests.get', side_effect=requests.exceptions.RequestException("Network Error"))
    def test_fetch_html_network_error(self, mock_get):
        url = "http://example.com/error.html"
        filename = "error.html"
        html_content = self.collector.fetch_html(url, filename)
        self.assertIsNone(html_content)
        self.assertFalse(os.path.exists(os.path.join(self.temp_cache_dir, filename))) # Plik nie powinien być zapisany