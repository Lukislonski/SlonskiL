# tests/test_text_processor.py

import unittest
from src.analyzers.text_processor import TextProcessor

class TestTextProcessor(unittest.TestCase):
    def setUp(self):
        self.processor = TextProcessor()
        self.test_text = "Trasa zajmuje 2h 30min. Czasem 150 minut. Wysokość: 1234 m n.p.m. Odwiedź schronisko. Uwaga na śliskie kamienie. Współrzędne: N49°11′46″, E20°05′33″."

    def test_extract_times(self):
        times = self.processor.extract_times(self.test_text)
        self.assertIn("2h", times)
        self.assertIn("30min", times)
        self.assertIn("150min", times)
        self.assertEqual(len(times), 3) # Sprawdź dokładną liczbę znalezionych

    def test_convert_time_to_minutes(self):
        self.assertEqual(self.processor.convert_time_to_minutes("2h 30min"), 150)
        self.assertEqual(self.processor.convert_time_to_minutes("2.5 godziny"), 150)
        self.assertEqual(self.processor.convert_time_to_minutes("150 minut"), 150)
        self.assertEqual(self.processor.convert_time_to_minutes("3h"), 180)
        self.assertIsNone(self.processor.convert_time_to_minutes("niewłaściwy format"))

    def test_identify_characteristic_points(self):
        points = self.processor.identify_characteristic_points(self.test_text)
        self.assertIn("schronisko", points)
        self.assertEqual(len(points), 1)

    def test_recognize_warnings(self):
        warnings = self.processor.recognize_warnings(self.test_text)
        self.assertIn("uwaga", warnings)
        self.assertIn("śliskie kamienie", warnings)
        self.assertEqual(len(warnings), 2)

    def test_standardize_coordinates(self):
        coords = self.processor.standardize_coordinates(self.test_text)
        self.assertIn(('N49°11′46″', 'E20°05′33″'), coords)
        self.assertEqual(len(coords), 1)

    def test_extract_elevations(self):
        elevations = self.processor.extract_elevations(self.test_text)
        self.assertIn("1234 m n.p.m.", elevations)
        self.assertEqual(len(elevations), 1)