# tests/test_route_analyzer.py

import unittest
from src.models.route import Route
from src.analyzers.route_analyzer import RouteAnalyzer

class TestRouteAnalyzer(unittest.TestCase):
    def test_estimate_travel_time(self):
        route1 = Route(
            id=101, name="Trasa Testowa 1", region="Test",
            start_lat=0, start_lon=0, end_lat=1, end_lon=1,
            length_km=5.0, elevation_gain=0, difficulty=1, terrain_type="coastal", tags=""
        )
        analyzer1 = RouteAnalyzer(route1)
        self.assertAlmostEqual(analyzer1.estimate_travel_time(), 60.0, places=2)

        route2 = Route(
            id=102, name="Trasa Testowa 2", region="Test",
            start_lat=0, start_lon=0, end_lat=1, end_lon=1,
            length_km=10.0, elevation_gain=300, difficulty=3, terrain_type="mountain", tags=""
        )
        analyzer2 = RouteAnalyzer(route2)
        self.assertAlmostEqual(analyzer2.estimate_travel_time(), 345.0, places=2)

        route3 = Route(
            id=103, name="Trasa Testowa 3", region="Test",
            start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=0.0, elevation_gain=0, difficulty=1, terrain_type="forest", tags=""
        )
        analyzer3 = RouteAnalyzer(route3)
        self.assertEqual(analyzer3.estimate_travel_time(), 0)

        route4 = Route(
            id=104, name="Trasa Testowa 4", region="Test",
            start_lat=0, start_lon=0, end_lat=1, end_lon=1,
            length_km=4.0, elevation_gain=0, difficulty=1, terrain_type="unknown", tags=""
        )
        analyzer4 = RouteAnalyzer(route4)
        self.assertAlmostEqual(analyzer4.estimate_travel_time(), 60.0, places=2)


    def test_categorize_route(self):
        route1 = Route(
            id=101, name="R1", region="T1", start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=5.0, elevation_gain=50, difficulty=1, terrain_type="forest", tags="park,easy"
        )
        analyzer1 = RouteAnalyzer(route1)
        self.assertIn("Rodzinna", analyzer1.categorize_route())
        self.assertCountEqual(analyzer1.categorize_route(), ["Rodzinna"])

        route2 = Route(
            id=102, name="R2", region="T2", start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=10.0, elevation_gain=150, difficulty=2, terrain_type="mountain", tags="scenic,viewpoint"
        )
        analyzer2 = RouteAnalyzer(route2)
        self.assertIn("Widokowa", analyzer2.categorize_route())
        self.assertNotIn("Rodzinna", analyzer2.categorize_route())

        route3 = Route(
            id=103, name="R3", region="T3", start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=15.0, elevation_gain=400, difficulty=3, terrain_type="mountain", tags="challenge"
        )
        analyzer3 = RouteAnalyzer(route3)
        self.assertIn("Sportowa", analyzer3.categorize_route())
        self.assertNotIn("Rodzinna", analyzer3.categorize_route())

        route4 = Route(
            id=104, name="R4", region="T4", start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=20.0, elevation_gain=800, difficulty=4, terrain_type="mountain", tags="alpine"
        )
        analyzer4 = RouteAnalyzer(route4)
        self.assertIn("Ekstremalna", analyzer4.categorize_route())

        route5 = Route(
            id=105, name="R5", region="T5", start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=12.0, elevation_gain=350, difficulty=3, terrain_type="mountain", tags="scenic,challenge"
        )
        analyzer5 = RouteAnalyzer(route5)
        categories5 = analyzer5.categorize_route()
        self.assertIn("Sportowa", categories5)
        self.assertIn("Widokowa", categories5)
        self.assertCountEqual(categories5, ["Sportowa", "Widokowa"])

        route6 = Route(
            id=106, name="R6", region="T6", start_lat=0, start_lon=0, end_lat=0, end_lon=0,
            length_km=10.0, elevation_gain=200, difficulty=2, terrain_type="forest", tags="city"
        )
        analyzer6 = RouteAnalyzer(route6)
        self.assertIn("Ogólna", analyzer6.categorize_route())
        self.assertEqual(len(analyzer6.categorize_route()), 1)