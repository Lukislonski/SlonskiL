# main.py
import sys
import os
import json
import re
import csv
from typing import List, Dict, Any, Optional
from datetime import date, datetime, timedelta

current_project_dir = os.path.dirname(os.path.abspath(__file__))
if current_project_dir not in sys.path:
    sys.sys.path.insert(0, current_project_dir)

from src.data_handlers.route_data_manager import RouteDataManager
from src.data_handlers.weather_data_manager import WeatherDataManager
from src.recommenders.route_recommender import RouteRecommender
from src.ui.user_interface import UserInterface
from src.extractors.web_data_collector import WebDataCollector
from src.extractors.html_route_extractor import HTMLRouteExtractor
from src.extractors.scraping_rules_manager import ScrapingRulesManager
from src.reporters.pdf_report_generator import PDFReportGenerator
from src.reporters.chart_generator import ChartGenerator
from src.models.route import Route
from src.models.weather_data import WeatherData
from src.models.user_preferences import UserPreferences
from src.analyzers.text_processor import TextProcessor
from src.analyzers.review_analyzer import ReviewAnalyzer
from src.config.api_keys import OPENWEATHER_API_KEY, OPENROUTESERVICE_API_KEY
from src.database.database_manager import DatabaseManager
from src.database.migration_tool import MigrationTool
from src.database.repositories.route_repository import RouteRepository
from src.database.repositories.weather_repository import WeatherRepository
from src.database.repositories.user_repository import UserPreferenceRepository
from src.database.backup_manager import BackupManager
from src.database.database_admin import DatabaseAdmin
from src.database.database_reports import DatabaseReports
from src.common.exceptions import DatabaseError, DataParsingError

# Konfiguracja ścieżek
DATA_DIR = os.path.join(current_project_dir, 'data')
LEGACY_DATA_DIR = os.path.join(DATA_DIR, 'legacy')
DATABASE_DIR = os.path.join(DATA_DIR, 'database')
BACKUPS_DIR = os.path.join(DATA_DIR, 'backups')
SQL_SCHEMA_PATH = os.path.join(current_project_dir, 'sql', 'schema.sql')
REPORTS_DIR = os.path.join(current_project_dir, 'reports')
CHARTS_DIR = os.path.join(REPORTS_DIR, 'charts')

DB_NAME = 'routes.db'
DB_PATH = os.path.join(DATABASE_DIR, DB_NAME)

LEGACY_ROUTES_CSV = os.path.join(LEGACY_DATA_DIR, 'routes.csv')
LEGACY_WEATHER_CSV = os.path.join(LEGACY_DATA_DIR, 'weather.csv')

def fetch_route_ors(web_collector: WebDataCollector, start_lon: float, start_lat: float, end_lon: float, end_lat: float) -> Optional[Dict[str, Any]]:
    if not OPENROUTESERVICE_API_KEY:
        print("Błąd: Brak klucza API OpenRouteService. Nie można pobrać danych trasy.")
        return None

    api_url = "https://api.openrouteservice.org/v2/directions/foot-walking"
    headers = {
        "Authorization": OPENROUTESERVICE_API_KEY,
        "Content-Type": "application/json"
    }
    json_body = {
        "coordinates": [
            [start_lon, start_lat],
            [end_lon, end_lat]
        ]
    }

    cache_id = f"ors_route_{start_lon}_{start_lat}_{end_lon}_{end_lat}"

    data = web_collector.fetch_json_post(
        api_url,
        cache_id,
        json_body=json_body,
        headers=headers
    )
    return data

db_manager: Optional[DatabaseManager] = None
route_repo: Optional[RouteRepository] = None
weather_repo: Optional[WeatherRepository] = None
user_repo: Optional[UserPreferenceRepository] = None
data_loader: Optional[RouteDataManager] = None
weather_data_loader: Optional[WeatherDataManager] = None
web_collector: Optional[WebDataCollector] = None
html_extractor: Optional[HTMLRouteExtractor] = None
scraping_rules_manager: Optional[ScrapingRulesManager] = None
text_processor: Optional[TextProcessor] = None
review_analyzer: Optional[ReviewAnalyzer] = None
recommender: Optional[RouteRecommender] = None
ui: Optional[UserInterface] = None
chart_generator: Optional[ChartGenerator] = None
pdf_generator: Optional[PDFReportGenerator] = None
backup_manager: Optional[BackupManager] = None
db_admin: Optional[DatabaseAdmin] = None
db_reports: Optional[DatabaseReports] = None

def initialize_system():
    global db_manager, route_repo, weather_repo, user_repo, \
           data_loader, weather_data_loader, web_collector, \
           html_extractor, scraping_rules_manager, \
           text_processor, review_analyzer, recommender, ui, \
           chart_generator, pdf_generator, backup_manager, db_admin, db_reports

    print("--- Inicjalizacja systemu ---")

    os.makedirs(LEGACY_DATA_DIR, exist_ok=True)
    os.makedirs(DATABASE_DIR, exist_ok=True)
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    os.makedirs(REPORTS_DIR, exist_ok=True)
    os.makedirs(CHARTS_DIR, exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'html_cache'), exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'scraping_rules'), exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'routes'), exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'weather'), exist_ok=True)

    # Inicjalizacja DatabaseManager
    db_manager = DatabaseManager(DB_PATH)
    try:
        db_manager.initialize_database(SQL_SCHEMA_PATH)
    except Exception as e:
        print(f"KRYTYCZNY BŁĄD: Nie udało się zainicjalizować bazy danych: {e}")
        sys.exit(1)

    route_repo = RouteRepository(db_manager)
    weather_repo = WeatherRepository(db_manager)
    user_repo = UserPreferenceRepository(db_manager)

    data_loader = RouteDataManager(route_repo)
    weather_data_loader = WeatherDataManager(weather_repo)

    ui = UserInterface()
    web_collector = WebDataCollector(cache_dir=os.path.join(DATA_DIR, 'html_cache'))
    html_extractor = HTMLRouteExtractor()
    scraping_rules_manager = ScrapingRulesManager(rules_dir=os.path.join(DATA_DIR, 'scraping_rules'))
    text_processor = TextProcessor()
    review_analyzer = ReviewAnalyzer()
    chart_generator = ChartGenerator(CHARTS_DIR)
    pdf_generator = PDFReportGenerator(REPORTS_DIR, CHARTS_DIR)
    
    backup_manager = BackupManager(DB_PATH, BACKUPS_DIR)
    db_admin = DatabaseAdmin(db_manager, backup_manager)
    db_reports = DatabaseReports(db_manager)

    print("--- System zainicjalizowany ---")


def perform_migration():
    print("\n--- Migracja danych z plików legacy ---")
    migration_tool = MigrationTool(db_manager)
    migration_tool.migrate_routes_from_csv(LEGACY_ROUTES_CSV)
    migration_tool.migrate_weather_from_csv(LEGACY_WEATHER_CSV)
    print("--- Migracja zakończona ---")


def run_recommendation_flow():
    print("\n--- Znajdź rekomendowane trasy ---")
    
    # 1. Ładowanie danych z bazy
    routes = data_loader.load_routes()
    print(f"DEBUG: Załadowano {len(routes)} tras przed dalszym przetwarzaniem.")
    for i, route in enumerate(routes):
        print(f"DEBUG: Trasa {i+1}: ID={route.id}, Name='{route.name}', Difficulty={route.difficulty}, Length={route.length_km}")

    weather_objects = weather_data_loader.load_all_weather_data()
    print(f"DEBUG: Załadowano {len(weather_objects)} obiektów pogodowych.")


    # 2. Przetwarzanie i uzupełnianie danych tras (HTML, TextProcessor, ReviewAnalyzer)
    rysy_html_filepath = os.path.join(DATA_DIR, 'html_cache', 'rysy.html')
    portal_name_for_rysy = "RysyPortalExample"
    rysy_rules = scraping_rules_manager.get_rules(portal_name_for_rysy)

    if rysy_rules and os.path.exists(rysy_html_filepath):
        try:
            with open(rysy_html_filepath, 'r', encoding='utf-8') as f:
                html_content = f.read()
            extracted_route_details = html_extractor.extract_route_data(html_content, rysy_rules['rules'])
            if extracted_route_details:
                route_description = extracted_route_details.get('description', '')
                processed_data = text_processor.process_route_text_full(route_description)
                
                length_km_html = extracted_route_details.get('length_km')
                elevation_gain_html = extracted_route_details.get('elevation_gain')
                difficulty_html = extracted_route_details.get('difficulty')

                try:
                    if isinstance(length_km_html, str):
                        length_km_html = float(length_km_html.replace(',', '.'))
                except (ValueError, TypeError):
                    length_km_html = None

                try:
                    if isinstance(elevation_gain_html, str):
                        elevation_gain_html = int(elevation_gain_html)
                except (ValueError, TypeError):
                    elevation_gain_html = None
                
                try:
                    if isinstance(difficulty_html, str):
                        difficulty_html = int(difficulty_html)
                except (ValueError, TypeError):
                    difficulty_html = None

                analyzed_reviews = []
                raw_reviews = extracted_route_details.get('reviews', [])
                for review_entry in raw_reviews:
                    review_text = review_entry.get('text', '') if isinstance(review_entry, dict) else str(review_entry)
                    if review_text:
                        analyzed_review_data = review_analyzer.analyze_review(review_text)
                        rating_raw = review_entry.get('rating') if isinstance(review_entry, dict) else None
                        numerical_rating = None
                        if rating_raw:
                            numerical_rating = len(re.findall(r'\u2605', rating_raw))
                        analyzed_reviews.append({**review_entry, 'rating_normalized': numerical_rating, **analyzed_review_data})

                rysy_route_id = "rysy_html_extracted"
                rysy_route_name = extracted_route_details.get('name', 'Szlak na Rysy (z HTML)')
                
                existing_rysy_route = route_repo.get_route_by_id(rysy_route_id)
                
                rysy_route_data = {
                    "id": rysy_route_id,
                    "name": rysy_route_name,
                    "region": "Tatry",
                    "start_lat": processed_data.get('start_lat') or (existing_rysy_route.start_lat if existing_rysy_route else None),
                    "start_lon": processed_data.get('start_lon') or (existing_rysy_route.start_lon if existing_rysy_route else None),
                    "end_lat": extracted_route_details.get('end_lat') or (existing_rysy_route.end_lat if existing_rysy_route else None) or 49.18,
                    "end_lon": extracted_route_details.get('end_lon') or (existing_rysy_route.end_lon if existing_rysy_route else None) or 20.07,
                    "length_km": length_km_html or processed_data.get('length_km') or (existing_rysy_route.length_km if existing_rysy_route else None),
                    "elevation_gain": elevation_gain_html or processed_data.get('elevation_gain') or (existing_rysy_route.elevation_gain if existing_rysy_route else None),
                    "difficulty": difficulty_html or processed_data.get('difficulty') or (existing_rysy_route.difficulty if existing_rysy_route else None),
                    "terrain_type": "mountain",
                    "tags": extracted_route_details.get('tags', []) or processed_data.get('tags', []),
                    "description": route_description,
                    "reviews": analyzed_reviews,
                    "extracted_times": processed_data.get('extracted_times', []),
                    "extracted_times_minutes": processed_data.get('extracted_times_minutes'),
                    "characteristic_points": processed_data.get('characteristic_points', []),
                    "warnings": processed_data.get('warnings', []),
                    "extracted_coords": processed_data.get('extracted_coords'),
                    "extracted_elevations": processed_data.get('extracted_elevations', [])
                }
                
                rysy_route_data_filtered = {k: v for k, v in rysy_route_data.items() if v is not None}

                rysy_route = Route(**rysy_route_data_filtered)

                if existing_rysy_route:
                    route_repo.update_route(rysy_route)
                    print(f"Trasa '{rysy_route.name}' (ID: {rysy_route.id}) została zaktualizowana w bazie o dane z HTML i przetworzone.")
                else:
                    route_repo.add_route(rysy_route)
                    print(f"Trasa '{rysy_route.name}' (ID: {rysy_route.id}) została dodana do bazy na podstawie danych z HTML i przetworzona.")
            else:
                print("Nie udało się wyodrębnić danych z HTML dla Rysów.")
        except Exception as e:
            print(f"Błąd podczas przetwarzania lokalnego pliku HTML dla Rysów: {e}")
    else:
        print("Brak reguł lub pliku HTML dla Rysów. Pomijam przetwarzanie HTML dla Rysów.")

    ors_route_id = "ors_example_gda_or_rysy"
    ors_route_name = "Przykładowa trasa OpenRouteService"
    ors_start_lat, ors_start_lon = 54.352, 18.646
    ors_end_lat, ors_end_lon = 54.355, 18.650

    rysy_from_db = route_repo.get_route_by_id("rysy_html_extracted")
    if rysy_from_db and rysy_from_db.start_lat and rysy_from_db.start_lon and rysy_from_db.end_lat and rysy_from_db.end_lon:
        ors_start_lat, ors_start_lon = rysy_from_db.start_lat, rysy_from_db.start_lon
        ors_end_lat, ors_end_lon = rysy_from_db.end_lat, rysy_from_db.end_lon
        ors_route_name = "Przykładowa trasa OpenRouteService (Rysy)"
        print("Używam współrzędnych z trasy Rysy (z bazy) do pobrania trasy ORS.")
    else:
        print("Używam domyślnych współrzędnych (Gdańsk) do pobrania trasy ORS.")

    route_data_ors = fetch_route_ors(web_collector, ors_start_lon, ors_start_lat, ors_end_lon, ors_end_lat)

    if route_data_ors:
        try:
            if 'routes' in route_data_ors and route_data_ors['routes']:
                route_entry = route_data_ors['routes'][0]
                if 'summary' in route_entry and 'segments' in route_entry and 'geometry' in route_entry:
                    summary = route_entry['summary']
                    distance_km = summary.get('distance') / 1000 if summary.get('distance') is not None else None
                    duration_min = summary.get('duration') / 60 if summary.get('duration') is not None else None
                    
                    extracted_elevations_ors = []

                    ors_route = Route(
                        id=ors_route_id,
                        name=ors_route_name,
                        region="Gdańsk" if ors_route_name == "Przykładowa trasa OpenRouteService" else "Tatry",
                        start_lat=ors_start_lat, start_lon=ors_start_lon,
                        end_lat=ors_end_lat, end_lon=ors_end_lon,
                        length_km=distance_km,
                        elevation_gain=None,
                        difficulty=3,
                        terrain_type="urban" if "Gdańsk" in ors_route_name else "mountain",
                        tags=["city_walk", "historical"] if "Gdańsk" in ors_route_name else ["api", "dynamic"],
                        description="Trasa piesza pobrana z OpenRouteService API.",
                        reviews=[],
                        extracted_times=[],
                        extracted_times_minutes=duration_min,
                        characteristic_points=[],
                        warnings=[],
                        extracted_coords=[(ors_start_lat, ors_start_lon), (ors_end_lat, ors_end_lon)] if ors_start_lat is not None else None,
                        extracted_elevations=extracted_elevations_ors
                    )
                    existing_ors_route = route_repo.get_route_by_id(ors_route_id)
                    if existing_ors_route:
                        route_repo.update_route(ors_route)
                        print(f"Trasa '{ors_route.name}' została zaktualizowana w bazie.")
                    else:
                        route_repo.add_route(ors_route)
                        print(f"Trasa '{ors_route.name}' (ID: {ors_route.id}) została dodana do bazy.")
                else:
                    print(f"Błąd: Odpowiedź ORS (klucz 'routes') nie zawiera oczekiwanej struktury ('summary', 'segments', 'geometry').")
                    print(f"Odpowiedź ORS: {route_data_ors}")
            else:
                print(f"Błąd: Odpowiedź ORS nie zawiera klucza 'routes' lub jest pusta. Sprawdź klucz API i limit zapytań.")
                print(f"Odpowiedź ORS: {route_data_ors}")

        except Exception as e:
            print(f"Błąd podczas przetwarzania danych ORS lub zapisu do bazy: {e}")
            print(f"Pełna odpowiedź ORS (jeśli dostępna): {route_data_ors}")
    else:
        print("Nie udało się pobrać trasy z OpenRouteService (pusta odpowiedź).")
    
    all_current_routes = data_loader.load_routes()
    recommender = RouteRecommender(all_current_routes, weather_objects)

    user_preferences = ui.get_user_preferences()
    
    user_repo.save_preferences(user_preferences)
    print("Preferencje użytkownika zapisane w bazie danych.")

    recommendations = recommender.generate_recommendations(user_preferences)

    ui.display_recommendations(recommendations)

    print("\nGenerowanie wykresów do raportu PDF...")
    charts_to_add = {}

    if recommendations:
        if chart_path := chart_generator.generate_length_histogram(recommendations):
            charts_to_add['length_histogram'] = chart_path
        if chart_path := chart_generator.generate_category_pie_chart(recommendations):
            charts_to_add['terrain_type_pie_chart'] = chart_path

        if any(rec.get('num_reviews', 0) > 0 for rec in recommendations):
            if chart_path := chart_generator.generate_user_rating_bar_chart(recommendations):
                charts_to_add['user_rating_bar_chart'] = chart_path
        else:
            print("Brak danych o ocenach użytkowników do wygenerowania wykresu 'user_rating_bar_chart.png'.")

        # Heatmapa popularności tras
        mappable_coords = []
        for rec in recommendations:
            if rec.get('start_lat') is not None and rec.get('start_lon') is not None:
                mappable_coords.append({'lat': rec['start_lat'], 'lon': rec['start_lon']})
            elif rec.get('extracted_coords'):
                coords = rec['extracted_coords']
                if isinstance(coords, str):
                    nums = re.findall(r'(\d+\.?\d*)', coords)
                    if len(nums) >= 2:
                        try:
                            lat_val = float(nums[0])
                            lon_val = float(nums[1])
                            if 'S' in coords: lat_val *= -1
                            if 'W' in coords: lon_val *= -1
                            mappable_coords.append({'lat': lat_val, 'lon': lon_val})
                        except ValueError:
                            pass
                elif isinstance(coords, list) and all(isinstance(c_pair, tuple) and len(c_pair) == 2 for c_pair in coords):
                    for lat_str, lon_str in coords:
                        try:
                            lat_val = float(re.search(r'(\d+\.?\d*)', lat_str).group(1)) if re.search(r'(\d+\.?\d*)', lat_str) else 0.0
                            lon_val = float(re.search(r'(\d+\.?\d*)', lon_str).group(1)) if re.search(r'(\d+\.?\d*)', lon_str) else 0.0
                            if 'S' in lat_str: lat_val *= -1
                            if 'W' in lon_str: lon_val *= -1
                            mappable_coords.append({'lat': lat_val, 'lon': lon_val})
                        except (ValueError, AttributeError):
                            pass

        if mappable_coords:
            if chart_path := chart_generator.generate_popularity_heatmap(mappable_coords):
                charts_to_add['popularity_heatmap'] = chart_path
        else:
            print("Brak wystarczających danych do wygenerowania heatmapy 'popularity_heatmap.png'.")

        for rec_route_data in recommendations:
            rec_route = Route.from_dict(rec_route_data)

            # Wykres profilu wysokości
            if rec_route.extracted_elevations:
                cleaned_elevations = [e for e in rec_route.extracted_elevations if isinstance(e, (int, float))]
                if cleaned_elevations:
                    elevation_profile_data = [(i, elev) for i, elev in enumerate(cleaned_elevations)]
                    if chart_path := chart_generator.generate_elevation_profile(rec_route.name, elevation_profile_data):
                        charts_to_add[f'elevation_profile_{rec_route.id}'] = chart_path
                else:
                    print(f"Brak liczbowych danych elewacji dla trasy '{rec_route.name}' do wygenerowania wykresu profilu wysokości.")

            # Wykres radarowy
            if (rec_route.difficulty is not None and rec_route.length_km is not None and 
                rec_route.elevation_gain is not None and rec_route.avg_review_rating is not None and
                rec_route.comfort_index is not None):
                
                avg_sentiments = review_analyzer.aggregate_sentiments_by_aspect(rec_route.reviews)
                
                radar_scores = {
                    "Trudność": rec_route.difficulty,
                    "Długość (km)": rec_route.length_km,
                    "Przewyższenie (m)": rec_route.elevation_gain,
                    "Ocena Recenzji": rec_route.avg_review_rating * 5,
                    "Komfort": rec_route.comfort_index,
                    "Widoki Sent.": avg_sentiments.get('widoki', 0.0),
                    "Pogoda Sent.": avg_sentiments.get('pogoda', 0.0),
                    "Oznakowanie Sent.": avg_sentiments.get('oznakowanie', 0.0)
                }
                
                max_values = {
                    'Trudność': 5, 'Długość (km)': 30.0, 'Przewyższenie (m)': 2000.0,
                    'Ocena Recenzji': 5.0, 'Komfort': 10.0,
                    'Widoki Sent.': 1.0, 'Pogoda Sent.': 1.0, 'Oznakowanie Sent.': 1.0
                }
                
                if chart_path := chart_generator.generate_radar_chart(rec_route.name, radar_scores, max_values):
                    charts_to_add[f'radar_chart_{rec_route.id}'] = chart_path
            else:
                print(f"Brak wystarczających danych metryk dla trasy '{rec_route.name}' do wygenerowania wykresu radarowego.")
    else:
        print("Brak rekomendacji, nie generuję wykresów.")

    report_filename = f"raport_tras_{date.today().strftime('%Y%m%d')}.pdf"
    pdf_generator.generate_report(report_filename, recommendations, user_preferences.to_dict(), list(charts_to_add.values()))

    print(f"Raport PDF '{report_filename}' został wygenerowany w {REPORTS_DIR}")


def admin_menu():
    """Menu administracyjne bazy danych."""
    while True:
        print("\n=== Menu Administracyjne Bazy Danych ===")
        print("1. Wyświetl statystyki bazy danych")
        print("2. Sprawdź integralność danych")
        print("3. Utwórz kopię zapasową bazy")
        print("4. Przywróć kopię zapasową bazy")
        print("5. Wyczyść stare dane pogodowe (starsze niż X dni)")
        print("0. Powrót do głównego menu")
        
        choice = input("Wybierz opcję: ").strip()

        if choice == '1':
            db_admin.display_database_stats()
        elif choice == '2':
            db_admin.check_data_integrity()
        elif choice == '3':
            db_admin.create_backup()
        elif choice == '4':
            db_admin.restore_backup()
        elif choice == '5':
            days_str = input("Podaj liczbę dni (rekordy starsze niż X dni zostaną usunięte): ").strip()
            try:
                days = int(days_str)
                if days < 0:
                    print("Liczba dni musi być nieujemna.")
                else:
                    db_admin.clean_old_data("weather_data", days)
            except ValueError:
                print("Nieprawidłowa liczba dni.")
        elif choice == '0':
            break
        else:
            print("Nieprawidłowa opcja. Spróbuj ponownie.")

def reports_menu():
    """Menu raportów konsolowych."""
    while True:
        print("\n=== Menu Raportów Konsolowych ===")
        print("1. Najpopularniejsze regiony")
        print("2. Statystyki pogodowe dla regionów")
        print("3. Podsumowanie tras według trudności")
        print("4. Lista tras bez danych pogodowych")
        print("0. Powrót do głównego menu")

        choice = input("Wybierz opcję: ").strip()

        if choice == '1':
            db_reports.get_most_popular_regions()
        elif choice == '2':
            region = input("Podaj nazwę regionu (pozostaw puste dla wszystkich): ").strip()
            db_reports.get_weather_statistics_for_regions(region if region else None)
        elif choice == '3':
            db_reports.get_route_summary_by_difficulty()
        elif choice == '4':
            db_reports.get_routes_without_weather_data()
        elif choice == '0':
            break
        else:
            print("Nieprawidłowa opcja. Spróbuj ponownie.")

def main_menu():
    """Główne menu aplikacji."""
    while True:
        print("\n=== REKOMENDATOR TRAS TURYSTYCZNYCH ===")
        print("1. Znajdź rekomendowane trasy")
        print("2. Narzędzia administracyjne bazy danych")
        print("3. Generuj raporty konsolowe")
        print("4. Wykonaj migrację danych (legacy CSV do DB)")
        print("0. Wyjście")
        
        choice = input("Wybierz opcję: ").strip()

        if choice == '1':
            run_recommendation_flow()
        elif choice == '2':
            admin_menu()
        elif choice == '3':
            reports_menu()
        elif choice == '4':
            perform_migration()
        elif choice == '0':
            print("Do widzenia!")
            break
        else:
            print("Nieprawidłowa opcja. Spróbuj ponownie.")

if __name__ == "__main__":
    os.makedirs(os.path.join(DATA_DIR, 'html_cache'), exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'scraping_rules'), exist_ok=True)
    os.makedirs(os.path.join(LEGACY_DATA_DIR), exist_ok=True)
    
    rysy_html_path = os.path.join(DATA_DIR, 'html_cache', 'rysy.html')
    if not os.path.exists(rysy_html_path):
        with open(rysy_html_path, 'w', encoding='utf-8') as f:
            f.write("""
            <div class="route-info">
                <h1>Szlak na Rysy - Opis Trasy</h1>
                <p class="route-description">
                    To jest wymagająca trasa w Tatrach Wysokich. Czas przejścia to około <b>8h 30min</b> w jedną stronę.
                    Po drodze znajduje się <b>schronisko</b> w Dolinie Pięciu Stawów Polskich. Uważaj na wysokie przewyższenia.
                    Szczyt Rysów znajduje się na wysokości 2499 m n.p.m.
                    Współrzędne początku trasy: N49°11′46″ E20°05′33″.
                    Wiosną (kwiecień) i wczesnym latem (czerwiec) mogą występować płaty śniegu.
                    Ostrzeżenie: Trasa bardzo wymagająca technicznie, tylko dla doświadczonych turystów.
                </p>
                <table class="route-params">
                    <tr><td>Długość całkowita:</td><td>18.5 km</td></tr>
                    <tr><td>Szacowany czas:</td><td>8-10 godzin</td></tr>
                    <tr><td>Przewyższenie:</td><td>1650 m</td></tr>
                    <tr><td>Trudność:</td><td>5/5</td></tr>
                </table>
                <div class="user-review">
                    <span class="rating">★★★★★</span>
                    <p>Wspaniałe widoki! Byłem 15.08.2023, pogoda dopisała, trasa super. Ocena 9/10.</p>
                </div>
                <div class="user-review">
                    <span class="rating">★★★☆☆</span>
                    <p>Trasa trudna, kiepskie oznakowanie miejscami. Byłem w lipcu 2022, lało cały dzień.</p>
                </div>
                <div class="gallery"></div>
                <div id="map"></div>
            </div>
            """)
        print(f"Stworzono przykładowy plik HTML w: {rysy_html_path}")
    
    rysy_rules_path = os.path.join(DATA_DIR, 'scraping_rules', 'rysy_portal.json')
    if not os.path.exists(rysy_rules_path):
        with open(rysy_rules_path, 'w', encoding='utf-8') as f:
            json.dump({
                "portal_name": "RysyPortalExample",
                "base_url": "https://www.example.com/",
                "rules": {
                    "name": {"selector": "div.route-info h1", "type": "text"},
                    "description": {"selector": "p.route-description", "type": "text"},
                    "length_km": {"selector": "table.route-params tr:nth-child(1) td:nth-child(2)", "type": "text", "regex": "([\\d.]+)\\s*km"},
                    "estimated_time": {"selector": "table.route-params tr:nth-child(2) td:nth-child(2)", "type": "text"},
                    "elevation_gain": {"selector": "table.route-params tr:nth-child(3) td:nth-child(2)", "type": "text", "regex": "([\\d.]+)\\s*m"},
                    "difficulty": {"selector": "table.route-params tr:nth-child(4) td:nth-child(2)", "type": "text", "regex": "(\\d+)/5"},
                    "reviews": {
                        "selector": "div.user-review",
                        "type": "list",
                        "item_rules": {
                            "rating": {"selector": "span.rating", "type": "text", "regex": "(\u2605+)"},
                            "text": {"selector": "p", "type": "text"}
                        }
                    }   
                }
            }, f, indent=4)
        print(f"Stworzono przykładowy plik reguł scrapingu w: {rysy_rules_path}")

    if not os.path.exists(LEGACY_ROUTES_CSV):
        with open(LEGACY_ROUTES_CSV, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f, quoting=csv.QUOTE_ALL)
            writer.writerow(["id","name","region","start_lat","start_lon","end_lat","end_lon","length_km","elevation_gain","difficulty","terrain_type","tags","description","extracted_times","extracted_times_minutes","characteristic_points","warnings","extracted_coords","extracted_elevations","reviews","gallery_urls","map_url"])
            writer.writerow(["101","Rezerwat Beka","Puck","54.67","18.52","54.68","18.53","5.3","12","1","coastal","[]","Idealny na spacery i obserwację ptaków.","[]","","[]","[]","null","[]","[]",""])
            writer.writerow(["102","Kamienne Kręgi Węsiory","Kaszuby","54.10","17.90","54.11","17.91","2.8","30","1","forest","[]","Pradawne kręgi kamienne, otoczone tajemnicą.","[]","","[]","[]","null","[]","[]",""])
            writer.writerow(["103","Dolina Pięciu Stawów Polskich","Tatry","49.20","20.04","49.21","20.05","4.7","310","3","mountain","[]","Malownicza dolina z pięcioma jeziorami.","[]","","[]","[]","null","[]","[]",""])
            writer.writerow(["104","Fort Góry Gradowej","Gdańsk","54.352","18.646","54.354","18.648","2.1","50","1","urban-hill","[]","Trasa historyczna w centrum Gdańska.","[]","","[]","[]","null","[]","[]",""])
            writer.writerow(["105","Jezioro Turkusowe w Wapnicy","Pomorze Zachodnie","53.882","14.453","53.884","14.455","1.8","20","1","lake","[]","Malownicze jezioro o turkusowej wodzie.","[]","","[]","[]","null","[]","[]",""])
            writer.writerow(["106","Stara Linia Kolejowa Kartuzy-Somnino","Kaszuby","54.321","18.150","54.330","18.250","11.2","70","2","urban-wild","[]","Długa trasa po nieczynnej linii kolejowej.","[]","","[]","[]","null","[]","[]",""])
            writer.writerow(["107","Słowiński Park Narodowy – Wydmy Ruchome","Pomorze","54.757","17.300","54.760","17.305","3.9","15","2","dunes","[]","Unikalne ruchome wydmy nad morzem.","[]","","[]","[]","null","[]","[]",""])
        print(f"Stworzono przykładowy plik CSV tras w: {LEGACY_ROUTES_CSV}")

    if not os.path.exists(LEGACY_WEATHER_CSV):
        with open(LEGACY_WEATHER_CSV, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f, quoting=csv.QUOTE_ALL)
            writer.writerow(["date","location_id","avg_temp","min_temp","max_temp","precipitation","sunshine_hours","cloud_cover","wind_speed","weather_description","humidity","pressure"])
            writer.writerow(["2025-06-20","54.352,18.646","15.0","10.0","20.0","0.5","8.0","20","10.0","zachmurzenie małe","70","1012"])
            writer.writerow(["2025-06-21","54.352,18.646","18.0","12.0","22.0","0.0","10.0","10","8.0","bezchmurnie","65","1015"])
            writer.writerow(["2025-06-20","49.22,20.08","5.0","0.0","10.0","1.0","4.0","80","15.0","opady śniegu","90","900"])
            writer.writerow(["2025-06-21","49.22,20.08","8.0","3.0","12.0","0.2","6.0","50","10.0","częściowe zachmurzenie","80","905"])
        print(f"Stworzono przykładowy plik CSV pogody w: {LEGACY_WEATHER_CSV}")

    initialize_system()
    main_menu()

