class DataParsingError(Exception):
    """
    Wyjątek zgłaszany, gdy wystąpi błąd podczas parsowania danych
    (np. z pliku CSV/JSON do obiektu modelu).
    """
    def __init__(self, message="Błąd parsowania danych.", original_exception=None):
        super().__init__(message)
        self.original_exception = original_exception
        if original_exception:
            self.message = f"{message} Oryginalny błąd: {original_exception}"

class DatabaseError(Exception):
    """
    Wyjątek zgłaszany, gdy wystąpi błąd podczas operacji na bazie danych.
    """
    def __init__(self, message="Błąd bazy danych.", original_exception=None):
        super().__init__(message)
        self.original_exception = original_exception
        if original_exception:
            self.message = f"{message} Oryginalny błąd: {original_exception}"
