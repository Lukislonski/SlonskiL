# src/models/weather_data.py
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from datetime import date, datetime

@dataclass
class WeatherData:
    date: date
    location_lat: float
    location_lon: float
    
    id: Optional[int] = None
    avg_temp: Optional[float] = None
    min_temp: Optional[float] = None
    max_temp: Optional[float] = None
    precipitation: Optional[float] = None
    sunshine_hours: Optional[float] = None
    cloud_cover: Optional[int] = None
    wind_speed: Optional[float] = None
    weather_description: Optional[str] = None
    humidity: Optional[float] = None
    pressure: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "date": self.date.isoformat(),
            "location_lat": self.location_lat,
            "location_lon": self.location_lon,
            "avg_temp": self.avg_temp,
            "min_temp": self.min_temp,
            "max_temp": self.max_temp,
            "precipitation": self.precipitation,
            "sunshine_hours": self.sunshine_hours,
            "cloud_cover": self.cloud_cover,
            "wind_speed": self.wind_speed,
            "weather_description": self.weather_description,
            "humidity": self.humidity,
            "pressure": self.pressure
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WeatherData':
        date_obj = None
        if isinstance(data.get('date'), date):
            date_obj = data['date']
        elif isinstance(data.get('date'), str):
            try:
                date_obj = datetime.fromisoformat(data['date']).date()
            except ValueError:
                print(f"OSTRZEŻENIE: Błąd parsowania daty '{data.get('date')}' w WeatherData.from_dict. Ustawiam na None.")
                date_obj = None 
        
        return cls(
            date=date_obj,
            location_lat=data['location_lat'],
            location_lon=data['location_lon'],
            id=data.get('id'),
            avg_temp=data.get('avg_temp'),
            min_temp=data.get('min_temp'),
            max_temp=data.get('max_temp'),
            precipitation=data.get('precipitation'),
            sunshine_hours=data.get('sunshine_hours'),
            cloud_cover=data.get('cloud_cover'),
            wind_speed=data.get('wind_speed'),
            weather_description=data.get('weather_description'),
            humidity=data.get('humidity'),
            pressure=data.get('pressure')
        )

    def __str__(self):
        return (f"Pogoda dla ({self.location_lat:.2f}, {self.location_lon:.2f}) w dniu {self.date}: "
                f"Temp: {self.avg_temp}°C (min: {self.min_temp}°C, max: {self.max_temp}°C), "
                f"Opady: {self.precipitation}mm, Zachmurzenie: {self.cloud_cover}%, "
                f"Wiatr: {self.wind_speed} km/h, Opis: {self.weather_description}")