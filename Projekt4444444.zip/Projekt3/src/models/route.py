# src/models/route.py
import json
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, Union

@dataclass
class Route:
    id: str
    name: str
    region: Optional[str] = None
    start_lat: Optional[float] = None
    start_lon: Optional[float] = None
    end_lat: Optional[float] = None
    end_lon: Optional[float] = None
    length_km: Optional[float] = None
    elevation_gain: Optional[int] = None
    difficulty: Optional[int] = None
    terrain_type: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    description: Optional[str] = None
    reviews: List[Dict[str, Any]] = field(default_factory=list)
    extracted_times: List[str] = field(default_factory=list)
    extracted_times_minutes: Optional[int] = None
    characteristic_points: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    extracted_coords: Optional[Union[List[Tuple[str, str]], str]] = None
    extracted_elevations: List[int] = field(default_factory=list)
    created_at: Optional[str] = None
    
    avg_review_rating: Optional[float] = None
    comfort_index: Optional[float] = None


    def __post_init__(self):
        if self.length_km is not None and self.length_km < 0:
            raise ValueError("Length cannot be negative")
        if self.difficulty is not None and not (1 <= self.difficulty <= 5):
            raise ValueError("Difficulty must be between 1 and 5")
        
        self.tags = [str(t).strip() for t in self.tags if t is not None and str(t).strip()]
        self.extracted_times = [str(t).strip() for t in self.extracted_times if t is not None and str(t).strip()]
        self.characteristic_points = [str(p).strip() for p in self.characteristic_points if p is not None and str(p).strip()]
        self.warnings = [str(w).strip() for w in self.warnings if w is not None and str(w).strip()]
        
        self.reviews = [r for r in self.reviews if r and isinstance(r, dict)]
        
        self.extracted_elevations = [e for e in self.extracted_elevations if isinstance(e, (int, float))]


    def to_dict(self) -> Dict[str, Any]:
        clean_tags = [str(t).strip() for t in self.tags if t is not None and str(t).strip()]
        clean_reviews = [r for r in self.reviews if r and isinstance(r, dict)]
        clean_extracted_times = [str(t).strip() for t in self.extracted_times if t is not None and str(t).strip()]
        clean_characteristic_points = [str(p).strip() for p in self.characteristic_points if p is not None and str(p).strip()]
        clean_warnings = [str(w).strip() for w in self.warnings if w is not None and str(w).strip()]
        clean_extracted_elevations = [e for e in self.extracted_elevations if isinstance(e, (int, float))]

        data = {
            "id": int(self.id) if isinstance(self.id, str) and self.id.isdigit() else (self.id if self.id is not None else None),
            "name": self.name,
            "region": self.region,
            "start_lat": self.start_lat,
            "start_lon": self.start_lon,
            "end_lat": self.end_lat,
            "end_lon": self.end_lon,
            "length_km": self.length_km,
            "elevation_gain": self.elevation_gain,
            "difficulty": self.difficulty,
            "terrain_type": self.terrain_type,
            "tags": json.dumps(clean_tags),
            "description": self.description,
            "reviews": json.dumps(clean_reviews),
            "extracted_times": json.dumps(clean_extracted_times),
            "extracted_times_minutes": self.extracted_times_minutes,
            "characteristic_points": json.dumps(clean_characteristic_points),
            "warnings": json.dumps(clean_warnings),
            "extracted_coords": json.dumps(self.extracted_coords) if self.extracted_coords is not None else 'null',
            "extracted_elevations": json.dumps(clean_extracted_elevations),
            "created_at": self.created_at
        }
        if data.get('id') is None:
            del data['id']
        return data


    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Route':
        
        def _safe_json_load_str_list(json_data: Any) -> List[str]:
            if isinstance(json_data, list):
                return [str(item).strip() for item in json_data if item is not None and str(item).strip()]
            
            if isinstance(json_data, str):
                json_str = json_data.strip()
                if json_str.lower() in ['', 'null']:
                    return []
                try:
                    loaded = json.loads(json_data)
                    if isinstance(loaded, list):
                        return [str(item).strip() for item in loaded if item is not None and str(item).strip()]
                    return []
                except json.JSONDecodeError:
                    return [json_str] if json_str else []
            return []

        def _safe_json_load_dict_list(json_data: Any) -> List[Dict[str, Any]]:
            if isinstance(json_data, list):
                return [item for item in json_data if item and isinstance(item, dict)]
            
            if isinstance(json_data, str):
                json_str = json_data.strip()
                if json_str.lower() in ['', 'null']:
                    return []
                try:
                    loaded = json.loads(json_data)
                    if isinstance(loaded, list):
                        return [item for item in loaded if item and isinstance(item, dict)]
                    return []
                except json.JSONDecodeError:
                    print(f"OSTRZEŻENIE: Błąd JSONDecodeError dla listy słowników '{json_data}'. Zwracam pustą listę.")
                    return []
            return []


        extracted_coords_parsed = None
        raw_extracted_coords = data.get('extracted_coords')
        if isinstance(raw_extracted_coords, str) and raw_extracted_coords.strip().lower() != 'null':
            try:
                loaded_coords = json.loads(raw_extracted_coords)
                if isinstance(loaded_coords, list):
                    cleaned_coords = []
                    for item in loaded_coords:
                        if isinstance(item, (list, tuple)) and len(item) == 2:
                            try:
                                cleaned_coords.append((float(item[0]) if isinstance(item[0], (int, float, str)) else item[0], 
                                                       float(item[1]) if isinstance(item[1], (int, float, str)) else item[1]))
                            except (ValueError, TypeError):
                                cleaned_coords.append(tuple(item)) 
                        elif isinstance(item, str) and ',' in item:
                            try:
                                lat, lon = map(float, item.split(','))
                                cleaned_coords.append((lat, lon))
                            except ValueError:
                                pass
                    extracted_coords_parsed = cleaned_coords if cleaned_coords else None
                else:
                    extracted_coords_parsed = raw_extracted_coords
            except json.JSONDecodeError:
                extracted_coords_parsed = raw_extracted_coords
        elif raw_extracted_coords is not None:
            extracted_coords_parsed = raw_extracted_coords


        return cls(
            id=str(data['id']),
            name=data['name'],
            region=data.get('region'),
            start_lat=data.get('start_lat'),
            start_lon=data.get('start_lon'),
            end_lat=data.get('end_lat'),
            end_lon=data.get('end_lon'),
            length_km=data.get('length_km'),
            elevation_gain=data.get('elevation_gain'),
            difficulty=data.get('difficulty'),
            terrain_type=data.get('terrain_type'),
            tags=_safe_json_load_str_list(data.get('tags')),
            description=data.get('description'),
            reviews=_safe_json_load_dict_list(data.get('reviews')),
            extracted_times=_safe_json_load_str_list(data.get('extracted_times')),
            extracted_times_minutes=data.get('extracted_times_minutes'),
            characteristic_points=_safe_json_load_str_list(data.get('characteristic_points')),
            warnings=_safe_json_load_str_list(data.get('warnings')),
            extracted_coords=extracted_coords_parsed,
            extracted_elevations=_safe_json_load_str_list(data.get('extracted_elevations')),
            created_at=data.get('created_at'),
            avg_review_rating=data.get('avg_review_rating'),
            comfort_index=data.get('comfort_index')
        )

