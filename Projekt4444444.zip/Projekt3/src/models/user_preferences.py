# src/models/user_preferences.py
import json
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime

@dataclass
class UserPreferences:
    id: Optional[int] = None
    user_name: str = 'default'
    preferred_temp_min: Optional[float] = None
    preferred_temp_max: Optional[float] = None
    max_precipitation: Optional[float] = None
    max_difficulty: Optional[int] = None
    max_length_km: Optional[float] = None
    min_length_km: Optional[float] = None
    preferred_terrain_types: List[str] = field(default_factory=list)
    preferred_tags: List[str] = field(default_factory=list)
    include_warnings: Optional[bool] = True
    updated_at: Optional[str] = None

    def __post_init__(self):
        if self.max_difficulty is not None and not (1 <= self.max_difficulty <= 5):
            raise ValueError("Max difficulty must be between 1 and 5")
        if self.min_length_km is not None and self.max_length_km is not None \
           and self.min_length_km > self.max_length_km:
            raise ValueError("Min length cannot be greater than max length")

    def to_dict(self) -> Dict[str, Any]:
        """Konwertuje obiekt UserPreferences do słownika, gotowego do zapisu w bazie danych."""
        return {
            "id": self.id,
            "user_name": self.user_name,
            "preferred_temp_min": self.preferred_temp_min,
            "preferred_temp_max": self.preferred_temp_max,
            "max_precipitation": self.max_precipitation,
            "max_difficulty": self.max_difficulty,
            "max_length_km": self.max_length_km,
            "preferred_terrain_types": json.dumps(self.preferred_terrain_types) if self.preferred_terrain_types else '[]',
            "preferred_tags": json.dumps(self.preferred_tags) if self.preferred_tags else '[]',
            "include_warnings": 1 if self.include_warnings else 0,
            "updated_at": self.updated_at
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UserPreferences':
        """Tworzy obiekt UserPreferences ze słownika (np. z bazy danych)."""
        preferred_terrain_types = json.loads(data.get('preferred_terrain_types', '[]')) if isinstance(data.get('preferred_terrain_types'), str) else (data.get('preferred_terrain_types', []) or [])
        preferred_tags = json.loads(data.get('preferred_tags', '[]')) if isinstance(data.get('preferred_tags'), str) else (data.get('preferred_tags', []) or [])
        include_warnings = bool(data.get('include_warnings', 1))

        return cls(
            id=data.get('id'),
            user_name=data.get('user_name', 'default'),
            preferred_temp_min=data.get('preferred_temp_min'),
            preferred_temp_max=data.get('preferred_temp_max'),
            max_precipitation=data.get('max_precipitation'),
            max_difficulty=data.get('max_difficulty'),
            max_length_km=data.get('max_length_km'),
            min_length_km=data.get('min_length_km'),
            preferred_terrain_types=preferred_terrain_types,
            preferred_tags=preferred_tags,
            include_warnings=include_warnings,
            updated_at=data.get('updated_at')
        )