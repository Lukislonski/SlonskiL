# src/reporters/pdf_report_generator.py
import os
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from typing import List, Dict, Any, Optional

class PDFReportGenerator:
    """
    Generuje raporty PDF z rekomendacjami tras, statystykami i wykresami.
    """
    def __init__(self, output_dir: str, charts_dir: str):
        self.output_dir = output_dir
        self.charts_dir = charts_dir
        self.styles = getSampleStyleSheet()
        self._register_font()

    def _register_font(self):
        font_path = "C:/Windows/Fonts/arial.ttf"
        if not os.path.exists(font_path):
            print(f"OSTRZEŻENIE: Czcionka '{font_path}' nie znaleziona. Raport może mieć problemy z polskimi znakami.")
            pdfmetrics.registerFont(TTFont('ArialUnicode', 'Helvetica'))
        else:
            pdfmetrics.registerFont(TTFont('ArialUnicode', font_path))
            print(f"Czcionka 'ArialUnicode' zarejestrowana z pliku: {font_path}")
        
        self.styles.add(ParagraphStyle(name='NormalPolish', fontName='ArialUnicode', fontSize=10, leading=12))
        self.styles.add(ParagraphStyle(name='H1Polish', fontName='ArialUnicode', fontSize=18, leading=22, spaceAfter=10))
        self.styles.add(ParagraphStyle(name='H2Polish', fontName='ArialUnicode', fontSize=14, leading=18, spaceAfter=8))
        self.styles.add(ParagraphStyle(name='BulletPolish', fontName='ArialUnicode', fontSize=10, leading=12, leftIndent=36, bulletIndent=12, bulletText='• '))


    def generate_report(self, filename: str, recommendations: List[Dict[str, Any]], user_prefs: Dict[str, Any], chart_paths: List[str]):
        filepath = os.path.join(self.output_dir, filename)
        doc = SimpleDocTemplate(filepath, pagesize=A4)
        story = []

        # Tytuł raportu
        story.append(Paragraph("Raport Rekomendacji Tras Turystycznych", self.styles['H1Polish']))
        story.append(Spacer(1, 0.2 * inch))

        # Sekcja Preferencje Użytkownika
        story.append(Paragraph("Preferencje Użytkownika", self.styles['H2Polish']))
        for key, value in user_prefs.items():
            if isinstance(value, list):
                value_str = ", ".join(map(str, value))
            elif value is None:
                value_str = "Brak / Nieokreślono"
            else:
                value_str = str(value)
            story.append(Paragraph(f"<b>{key.replace('_', ' ').title()}:</b> {value_str}", self.styles['NormalPolish']))
        story.append(Spacer(1, 0.2 * inch))

        # Sekcja Podsumowanie rekomendacji
        story.append(Paragraph("Podsumowanie Rekomendacji", self.styles['H2Polish']))
        
        # Obliczanie podstawowych statystyk z rekomendacji
        total_routes = len(recommendations)
        avg_difficulty = sum(rec.get('difficulty', 0) for rec in recommendations if rec.get('difficulty') is not None) / total_routes if total_routes > 0 else 0
        avg_length = sum(rec.get('length_km', 0) for rec in recommendations if rec.get('length_km') is not None) / total_routes if total_routes > 0 else 0
        avg_elevation = sum(rec.get('elevation_gain', 0) for rec in recommendations if rec.get('elevation_gain') is not None) / total_routes if total_routes > 0 else 0
        avg_comfort = sum(rec.get('comfort_index', 0) for rec in recommendations if rec.get('comfort_index') is not None) / total_routes if total_routes > 0 else 0


        story.append(Paragraph(f"Liczba rekomendowanych tras: {total_routes}", self.styles['NormalPolish']))
        story.append(Paragraph(f"Średnia trudność: {avg_difficulty:.1f}/5", self.styles['NormalPolish']))
        story.append(Paragraph(f"Średnia długość: {avg_length:.1f} km", self.styles['NormalPolish']))
        story.append(Paragraph(f"Średnie przewyższenie: {avg_elevation:.0f} m", self.styles['NormalPolish']))
        story.append(Paragraph(f"Średni indeks komfortu: {avg_comfort:.2f}", self.styles['NormalPolish']))

        story.append(Spacer(1, 0.2 * inch))

        # Sekcja Wykresy
        story.append(Paragraph("Wykresy", self.styles['H2Polish']))
        story.append(Spacer(1, 0.1 * inch))

        for chart_path in chart_paths:
            if os.path.exists(chart_path):
                try:
                    img = Image(chart_path, width=4.5*inch, height=3*inch) # Dostosuj rozmiar
                    story.append(img)
                    story.append(Spacer(1, 0.1 * inch))
                    chart_title = os.path.basename(chart_path).replace('.png', '').replace('_', ' ').title()
                    story.append(Paragraph(f"<i>{chart_title}</i>", self.styles['NormalPolish']))
                    story.append(Spacer(1, 0.2 * inch))
                except Exception as e:
                    print(f"Błąd podczas dodawania wykresu '{chart_path}' do PDF: {e}")
            else:
                print(f"OSTRZEŻENIE: Wykres nie znaleziony: {chart_path}. Nie zostanie dodany do raportu.")

        story.append(PageBreak())

        # Sekcja Szczegóły Rekomendowanych Tras
        story.append(Paragraph("Szczegóły Rekomendowanych Tras", self.styles['H1Polish']))
        story.append(Spacer(1, 0.2 * inch))

        for i, rec in enumerate(recommendations):
            story.append(Paragraph(f"{i+1}. {rec.get('name', 'N/A')}", self.styles['H2Polish']))
            story.append(Paragraph(f"<b>Region:</b> {rec.get('region', 'N/A')}", self.styles['NormalPolish']))
            story.append(Paragraph(f"<b>Długość:</b> {rec.get('length_km', 'N/A')} km", self.styles['NormalPolish']))
            story.append(Paragraph(f"<b>Trudność:</b> {rec.get('difficulty', 'N/A')}/5", self.styles['NormalPolish']))
            story.append(Paragraph(f"<b>Typ terenu:</b> {rec.get('terrain_type', 'N/A')}", self.styles['NormalPolish']))
            story.append(Paragraph(f"<b>Opis:</b> {rec.get('description', 'Brak opisu')}", self.styles['NormalPolish']))
            
            story.append(Paragraph(f"<b>Szacowany czas (minuty):</b> {rec.get('extracted_times_minutes', 'N/A')} min", self.styles['NormalPolish']))
            
            extracted_coords = rec.get('extracted_coords')
            coords_display = "Brak"
            if extracted_coords:
                if isinstance(extracted_coords, str):
                    coords_display = extracted_coords
                elif isinstance(extracted_coords, list):
                    coords_display = ", ".join([f"({lat}, {lon})" for lat, lon in extracted_coords])
            story.append(Paragraph(f"<b>Wyodrębnione współrzędne:</b> {coords_display}", self.styles['NormalPolish']))

            story.append(Paragraph(f"<b>Liczba recenzji:</b> {rec.get('num_reviews', 0)}", self.styles['NormalPolish']))
            story.append(Paragraph(f"<b>Średnia ocena:</b> {rec.get('avg_review_rating', 0.0):.2f}", self.styles['NormalPolish']))
            story.append(Paragraph(f"<b>Indeks komfortu:</b> {rec.get('comfort_index', 0.0):.2f}", self.styles['NormalPolish']))

            aspect_mentions = rec.get('aspect_mentions', {})
            if aspect_mentions:
                story.append(Paragraph("<b>Wzmianki o aspektach w recenzjach:</b>", self.styles['NormalPolish']))
                for aspect, count in aspect_mentions.items():
                    story.append(Paragraph(f"  • {aspect}: {count}", self.styles['BulletPolish']))

            story.append(Spacer(1, 0.2 * inch))

        try:
            doc.build(story)
            print(f"Raport PDF '{filepath}' został pomyślnie wygenerowany.")
        except Exception as e:
            print(f"BŁĄD: Nie udało się wygenerować raportu PDF: {e}")