# src/ui/user_interface.py
from typing import List, Optional, Dict, Any
from src.models.route import Route
from src.models.user_preferences import UserPreferences
from datetime import date, datetime

class UserInterface:

    def get_user_preferences(self) -> UserPreferences:
        """
        Pobiera preferencje użytkownika dotyczące tras.
        """
        print("\n--- Podaj swoje preferencje dotyczące tras ---")
        
        user_name = input("Podaj swoją nazwę użytkownika (domyślnie 'default'): ").strip()
        if not user_name:
            user_name = 'default'

        preferred_temp_min = self._get_float_input("Podaj preferowaną MINIMALNĄ temperaturę (np. 15.0, pozostaw puste aby pominąć): ")
        preferred_temp_max = self._get_float_input("Podaj preferowaną MAKSYMALNĄ temperaturę (np. 25.0, pozostaw puste aby pominąć): ")
        
        max_precipitation = self._get_float_input("Podaj maksymalne opady (mm) (np. 5.0, pozostaw puste aby pominąć): ")
        max_difficulty = self._get_int_input("Podaj maksymalną trudność trasy (1-5, pozostaw puste aby pominąć): ", min_val=1, max_val=5)
        
        min_length_km = self._get_float_input("Podaj minimalną długość trasy (km) (np. 5.0, pozostaw puste aby pominąć): ")
        max_length_km = self._get_float_input("Podaj maksymalną długość trasy (km) (np. 20.0, pozostaw puste aby pominąć): ")

        # Obsługa wielu preferowanych typów terenu
        preferred_terrain_types_input = input("Podaj preferowane typy terenu (np. 'mountain, forest, city', rozdziel przecinkami, pozostaw puste aby pominąć): ").strip()
        preferred_terrain_types = [t.strip().lower() for t in preferred_terrain_types_input.split(',') if t.strip()] if preferred_terrain_types_input else []

        # Obsługa wielu preferowanych tagów
        preferred_tags_input = input("Podaj preferowane tagi (np. 'scenic, historical', rozdziel przecinkami, pozostaw puste aby pominąć): ").strip()
        preferred_tags = [t.strip().lower() for t in preferred_tags_input.split(',') if t.strip()] if preferred_tags_input else []

        include_warnings_input = input("Czy chcesz uwzględnić trasy z ostrzeżeniami? (tak/nie, domyślnie tak): ").strip().lower()
        include_warnings = True if include_warnings_input in ['tak', 't'] else (False if include_warnings_input in ['nie', 'n'] else True)

        try:
            preferences = UserPreferences(
                user_name=user_name,
                preferred_temp_min=preferred_temp_min,
                preferred_temp_max=preferred_temp_max,
                max_precipitation=max_precipitation,
                max_difficulty=max_difficulty,
                min_length_km=min_length_km,
                max_length_km=max_length_km,
                preferred_terrain_types=preferred_terrain_types,
                preferred_tags=preferred_tags,
                include_warnings=include_warnings
            )
            return preferences
        except ValueError as e:
            print(f"Błąd walidacji preferencji: {e}. Spróbuj ponownie.")
            return self.get_user_preferences()

    def _get_float_input(self, prompt: str) -> Optional[float]:
        while True:
            value = input(prompt).strip()
            if not value:
                return None
            try:
                return float(value)
            except ValueError:
                print("Nieprawidłowy format. Podaj liczbę dziesiętną.")

    def _get_int_input(self, prompt: str, min_val: Optional[int] = None, max_val: Optional[int] = None) -> Optional[int]:
        while True:
            value = input(prompt).strip()
            if not value:
                return None
            try:
                int_val = int(value)
                if min_val is not None and int_val < min_val:
                    print(f"Wartość musi być większa lub równa {min_val}.")
                elif max_val is not None and int_val > max_val:
                    print(f"Wartość musi być mniejsza lub równa {max_val}.")
                else:
                    return int_val
            except ValueError:
                print("Nieprawidłowy format. Podaj liczbę całkowitą.")

    def display_recommendations(self, recommendations: List[Dict[str, Any]]):
        if not recommendations:
            print("\nBrak rekomendacji spełniających Twoje kryteria.")
            return

        print("\n--- Rekomendowane Trasy ---")
        for i, route_data in enumerate(recommendations):
            print(f"\n{i+1}. {route_data.get('name', 'N/A')}")
            print(f"   Region: {route_data.get('region', 'N/A')}")
            print(f"   Długość: {route_data.get('length_km', 'N/A'):.1f} km")
            print(f"   Trudność: {route_data.get('difficulty', 'N/A')}/5")
            print(f"   Typ terenu: {route_data.get('terrain_type', 'N/A')}")
            
            description_text = route_data.get('description', 'Brak opisu')
            if description_text is None:
                description_text = 'Brak opisu'
            print(f"   Opis: {description_text[:100]}...")
            
            if route_data.get('extracted_times_minutes') is not None:
                print(f"   Szacowany czas: {route_data['extracted_times_minutes']} min")
            
            characteristic_points = [p for p in route_data.get('characteristic_points', []) if p is not None and str(p).strip()]
            if characteristic_points:
                print(f"   Punkty charakterystyczne: {', '.join(characteristic_points)}")
            
            warnings = [w for w in route_data.get('warnings', []) if w is not None and str(w).strip()]
            if warnings:
                print(f"   Ostrzeżenia: {', '.join(warnings)}")
            
            if route_data.get('num_reviews') is not None:
                print(f"   Liczba recenzji: {route_data['num_reviews']}")
            if route_data.get('avg_review_rating') is not None:
                print(f"   Średnia ocena: {route_data['avg_review_rating']:.2f}")
            if route_data.get('sentiment_score') is not None:
                print(f"   Sentyment ogólny: {route_data['sentiment_score']:.2f}")
            if route_data.get('comfort_index') is not None:
                print(f"   Indeks komfortu: {route_data['comfort_index']:.2f}")
            
            print("-" * 30)

    def display_message(self, message: str):
        """Wyświetla ogólny komunikat użytkownikowi."""
        print(f"\n[INFO] {message}")

    def get_confirmation(self, prompt: str) -> bool:
        """Pobiera potwierdzenie od użytkownika (tak/nie)."""
        while True:
            response = input(f"{prompt} (tak/nie): ").strip().lower()
            if response in ['tak', 't']:
                return True
            elif response in ['nie', 'n']:
                return False
            else:
                print("Nieprawidłowa odpowiedź. Proszę odpowiedzieć 'tak' lub 'nie'.")