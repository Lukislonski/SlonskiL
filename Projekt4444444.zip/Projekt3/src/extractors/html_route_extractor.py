# src/extractors/html_route_extractor.py
import re
from bs4 import BeautifulSoup
from typing import Dict, Any, List, Optional, Union, Tuple

class HTMLRouteExtractor:
   
    def extract_route_data(self, html_content: str, rules: Dict[str, Any]) -> Dict[str, Any]:
       
        soup = BeautifulSoup(html_content, 'html.parser')
        extracted_data: Dict[str, Any] = {}

        for field_name, rule in rules.items():
            selector = rule.get('selector')
            extract_type = rule.get('type', 'text')
            regex = rule.get('regex')
            item_rules = rule.get('item_rules')

            if not selector:
                continue

            elements = soup.select(selector)

            if extract_type == 'text':
                if elements:
                    text_content = elements[0].get_text(strip=True)
                    if regex:
                        match = re.search(regex, text_content)
                        if match:
                            extracted_data[field_name] = match.group(1).strip()
                        else:
                            extracted_data[field_name] = None
                    else:
                        extracted_data[field_name] = text_content
                else:
                    extracted_data[field_name] = None
            
            elif extract_type == 'attribute':
                attribute = rule.get('attribute')
                if elements and attribute:
                    extracted_data[field_name] = elements[0].get(attribute, None)
                else:
                    extracted_data[field_name] = None
            
            elif extract_type == 'list':
                if elements and item_rules:
                    items_list = []
                    for item_element in elements:
                        item_data = {}
                        for item_field, item_rule in item_rules.items():
                            item_selector = item_rule.get('selector')
                            item_extract_type = item_rule.get('type', 'text')
                            item_regex = item_rule.get('regex')

                            if item_selector:
                                sub_elements = item_element.select(item_selector)
                                if sub_elements:
                                    sub_text = sub_elements[0].get_text(strip=True)
                                    if item_regex:
                                        match = re.search(item_regex, sub_text)
                                        if match:
                                            item_data[item_field] = match.group(1).strip()
                                        else:
                                            item_data[item_field] = None
                                    else:
                                        item_data[item_field] = sub_text
                                else:
                                    item_data[item_field] = None
                        if item_data:
                            items_list.append(item_data)
                    extracted_data[field_name] = items_list
                else:
                    extracted_data[field_name] = []

        return extracted_data