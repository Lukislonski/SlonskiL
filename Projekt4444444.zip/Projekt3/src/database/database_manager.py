import sqlite3
import os
from typing import List, Tuple, Any, Optional
from src.common.exceptions import DatabaseError

class DatabaseManager:
    """
    Zarządza połączeniem z bazą danych SQLite i podstawowymi operacjami.
    """
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._ensure_db_dir_exists()

    def _ensure_db_dir_exists(self):
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
            print(f"Utworzono katalog bazy danych: {db_dir}")

    def _get_connection(self) -> sqlite3.Connection:
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.Error as e:
            raise DatabaseError(f"Nie udało się połączyć z bazą danych: {self.db_path}", original_exception=e)

    def initialize_database(self, schema_path: str):
        if not os.path.exists(schema_path):
            raise FileNotFoundError(f"Plik schematu SQL nie znaleziony: {schema_path}")

        try:
            with self._get_connection() as conn:
                with open(schema_path, 'r', encoding='utf-8') as f:
                    schema_script = f.read()
                conn.executescript(schema_script)
            print(f"Baza danych '{self.db_path}' została zainicjalizowana/zaktualizowana.")
        except sqlite3.Error as e:
            raise DatabaseError(f"Błąd podczas inicjalizacji bazy danych z pliku {schema_path}", original_exception=e)

    def execute_query(self, query: str, params: Optional[Tuple] = None) -> List[sqlite3.Row]:
        """
        Wykonuje zapytanie SQL i zwraca wyniki.
        """
        if params is None:
            params = ()
        try:
            with self._get_connection() as conn:
                cursor = conn.execute(query, params)
                return cursor.fetchall()
        except sqlite3.Error as e:
            raise DatabaseError(f"Błąd podczas wykonywania zapytania: {query} z parametrami: {params}", original_exception=e)

    def execute_non_query(self, query: str, params: Optional[Tuple] = None) -> int:
        """
        Wykonuje zapytanie SQL, które nie zwraca wyników (INSERT, UPDATE, DELETE).
        """
        if params is None:
            params = ()
        try:
            with self._get_connection() as conn:
                cursor = conn.execute(query, params)
                conn.commit()
                return cursor.rowcount
        except sqlite3.Error as e:
            raise DatabaseError(f"Błąd podczas wykonywania non-query: {query} z parametrami: {params}", original_exception=e)

    def get_last_inserted_rowid(self) -> Optional[int]:
        try:
            with self._get_connection() as conn:
                cursor = conn.execute("SELECT last_insert_rowid()")
                return cursor.fetchone()[0]
        except sqlite3.Error as e:
            raise DatabaseError("Błąd podczas pobierania ostatniego ID wstawionego wiersza.", original_exception=e)

    def close(self):
        print("Połączenie z bazą danych zamknięte.")