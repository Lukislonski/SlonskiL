# src/database/database_reports.py
from typing import Dict, Any, List, Optional
from src.database.database_manager import DatabaseManager
from src.common.exceptions import DatabaseError

class DatabaseReports:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager

    def get_most_popular_regions(self, limit: int = 5) -> List[Dict[str, Any]]:
        print("\n--- Najpopularniejsze Regiony ---")
        query = """
        SELECT region, COUNT(id) AS route_count
        FROM routes
        WHERE region IS NOT NULL AND region != ''
        GROUP BY region
        ORDER BY route_count DESC
        LIMIT ?
        """
        try:
            rows = self.db_manager.execute_query(query, (limit,))
            if not rows:
                print("Brak danych o regionach tras.")
                return []
            
            regions_data = []
            for row in rows:
                regions_data.append(dict(row))
                print(f"- {row['region']}: {row['route_count']} tras")
            return regions_data
        except DatabaseError as e:
            print(f"Błąd podczas pobierania najpopularniejszych regionów: {e}")
            return []

    def get_weather_statistics_for_regions(self, region: Optional[str] = None) -> List[Dict[str, Any]]:
        print("\n--- Statystyki Pogodowe dla Regionów ---")
        base_query = """
        SELECT
            r.region,
            w.location_lat,
            w.location_lon,
            AVG(w.avg_temp) AS avg_temperature,
            SUM(w.precipitation) AS total_precipitation,
            AVG(w.cloud_cover) AS avg_cloud_cover
        FROM routes r
        JOIN weather_data w ON r.start_lat = w.location_lat AND r.start_lon = w.location_lon
        """
        params = []
        if region:
            base_query += " WHERE r.region = ?"
            params.append(region)
        
        base_query += " GROUP BY r.region, w.location_lat, w.location_lon ORDER BY r.region"

        try:
            rows = self.db_manager.execute_query(base_query, tuple(params))
            if not rows:
                print("Brak danych pogodowych dla regionów lub brak powiązań między trasami a pogodą.")
                return []

            stats_data = []
            current_region = None
            for row in rows:
                data = dict(row)
                if data['region'] != current_region:
                    if current_region is not None:
                        print("")
                    print(f"Region: {data['region']}")
                    current_region = data['region']
                
                print(f"  - Lokalizacja ({data['location_lat']:.2f}, {data['location_lon']:.2f}):")
                print(f"    Średnia temp: {data['avg_temperature']:.2f}°C")
                print(f"    Łączne opady: {data['total_precipitation']:.2f} mm")
                print(f"    Średnie zachmurzenie: {data['avg_cloud_cover']:.0f}%")
                stats_data.append(data)
            return stats_data
        except DatabaseError as e:
            print(f"Błąd podczas pobierania statystyk pogodowych dla regionów: {e}")
            return []

    def get_route_summary_by_difficulty(self) -> List[Dict[str, Any]]:
        print("\n--- Podsumowanie Tras według Trudności ---")
        query = """
        SELECT
            difficulty,
            COUNT(id) AS route_count,
            AVG(length_km) AS avg_length_km,
            AVG(elevation_gain) AS avg_elevation_gain
        FROM routes
        WHERE difficulty IS NOT NULL
        GROUP BY difficulty
        ORDER BY difficulty
        """
        try:
            rows = self.db_manager.execute_query(query)
            if not rows:
                print("Brak danych o trudności tras.")
                return []
            
            summary_data = []
            for row in rows:
                data = dict(row)
                print(f"Trudność {data['difficulty']}/5:")
                print(f"  - Liczba tras: {data['route_count']}")
                print(f"  - Średnia długość: {data['avg_length_km']:.2f} km")
                print(f"  - Średnie przewyższenie: {data['avg_elevation_gain']:.0f} m")
                summary_data.append(data)
            return summary_data
        except DatabaseError as e:
            print(f"Błąd podczas pobierania podsumowania tras według trudności: {e}")
            return []

    def get_routes_without_weather_data(self) -> List[Dict[str, Any]]:
        print("\n--- Trasy bez Danych Pogodowych dla Punktu Startowego ---")
        query = """
        SELECT
            r.id,
            r.name,
            r.start_lat,
            r.start_lon
        FROM routes r
        LEFT JOIN weather_data w ON r.start_lat = w.location_lat AND r.start_lon = w.location_lon
        WHERE w.id IS NULL AND r.start_lat IS NOT NULL AND r.start_lon IS NOT NULL;
        """
        try:
            rows = self.db_manager.execute_query(query)
            if not rows:
                print("Wszystkie trasy z zdefiniowanymi współrzędnymi startowymi mają dane pogodowe.")
                return []
            
            missing_weather_routes = []
            for row in rows:
                data = dict(row)
                missing_weather_routes.append(data)
                print(f"- ID: {data['id']}, Nazwa: '{data['name']}', Współrzędne: ({data['start_lat']:.2f}, {data['start_lon']:.2f})")
            return missing_weather_routes
        except DatabaseError as e:
            print(f"Błąd podczas pobierania tras bez danych pogodowych: {e}")
            return []