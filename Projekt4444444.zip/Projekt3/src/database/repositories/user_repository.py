# src/database/repositories/user_repository.py
import json
import sqlite3
from typing import List, Dict, Any, Optional
from datetime import datetime
from src.database.database_manager import DatabaseManager
from src.models.user_preferences import UserPreferences
from src.common.exceptions import DatabaseError, DataParsingError

class UserPreferenceRepository:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager

    def _parse_row_to_user_preferences(self, row: sqlite3.Row) -> UserPreferences:
        if row is None:
            return None
        try:
            data = dict(row)
            data['preferred_terrain_types'] = json.loads(data.get('preferred_terrain_types') or '[]')
            data['preferred_tags'] = json.loads(data.get('preferred_tags') or '[]')
            data['include_warnings'] = bool(data.get('include_warnings', 1))

            return UserPreferences.from_dict(data)
        except (json.JSONDecodeError, ValueError, TypeError, KeyError) as e:
            raise DataParsingError(f"Błąd parsowania preferencji użytkownika z bazy danych: {e}. Dane: {dict(row)}", original_exception=e)

    def save_preferences(self, preferences: UserPreferences) -> Optional[int]:
        prefs_data = preferences.to_dict()
        
        prefs_data['updated_at'] = datetime.now().isoformat(timespec='seconds')

        if preferences.id is None:
            existing_prefs = self.get_preferences_by_user(preferences.user_name)
            if existing_prefs:
                preferences.id = existing_prefs.id
                print(f"Preferencje dla użytkownika '{preferences.user_name}' już istnieją, aktualizuję...")
                return self.update_preferences(preferences)
            else:
                if 'id' in prefs_data: del prefs_data['id']
                columns = ', '.join(prefs_data.keys())
                placeholders = ', '.join(['?'] * len(prefs_data))
                query = f"INSERT INTO user_preferences ({columns}) VALUES ({placeholders})"
                values = tuple(prefs_data[key] for key in prefs_data.keys())

                try:
                    self.db_manager.execute_non_query(query, values)
                    return self.db_manager.get_last_inserted_rowid()
                except DatabaseError:
                    raise
        else:
            print(f"ID podane ({preferences.id}), próbuję aktualizować preferencje dla użytkownika '{preferences.user_name}'...")
            return self.update_preferences(preferences)

    def update_preferences(self, preferences: UserPreferences) -> bool:
        if preferences.id is None:
            print("OSTRZEŻENIE: Brak ID preferencji do aktualizacji. Użyj save_preferences dla nowych rekordów.")
            return False

        prefs_data = preferences.to_dict()
        prefs_id = prefs_data.pop('id')
        prefs_data['updated_at'] = datetime.now().isoformat(timespec='seconds')

        set_clauses = [f"{col} = ?" for col in prefs_data.keys()]
        query = f"UPDATE user_preferences SET {', '.join(set_clauses)} WHERE id = ?"
        values = tuple(prefs_data[key] for key in prefs_data.keys()) + (prefs_id,)

        try:
            row_count = self.db_manager.execute_non_query(query, values)
            return row_count > 0
        except DatabaseError:
            raise

    def get_preferences_by_user(self, user_name: str = 'default') -> Optional[UserPreferences]:
        query = "SELECT * FROM user_preferences WHERE user_name = ?"
        rows = self.db_manager.execute_query(query, (user_name,))
        if rows:
            return self._parse_row_to_user_preferences(rows[0])
        return None
    
    def get_all_preferences(self) -> List[UserPreferences]:
        query = "SELECT * FROM user_preferences"
        rows = self.db_manager.execute_query(query)
        return [self._parse_row_to_user_preferences(row) for row in rows]