# src/database/repositories/weather_repository.py
import sqlite3
from typing import List, Dict, Any, Optional, Tuple
from datetime import date, datetime
from src.database.database_manager import DatabaseManager
from src.models.weather_data import WeatherData
from src.common.exceptions import DatabaseError, DataParsingError

class WeatherRepository:
    
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager

    def _parse_row_to_weather_data(self, row: sqlite3.Row) -> WeatherData:
        if row is None:
            return None
        try:
            data = dict(row)
            return WeatherData.from_dict(data)
        except (ValueError, TypeError, KeyError) as e:
            raise DataParsingError(f"Błąd parsowania danych pogodowych z bazy danych: {e}. Dane: {dict(row)}", original_exception=e)

    def add_weather_data(self, weather: WeatherData) -> Optional[int]:
        weather_data = weather.to_dict()
        
        if 'id' in weather_data:
            del weather_data['id']

        columns = ', '.join(weather_data.keys())
        placeholders = ', '.join(['?'] * len(weather_data))
        query = f"INSERT OR IGNORE INTO weather_data ({columns}) VALUES ({placeholders})"
        values = tuple(weather_data[key] for key in weather_data.keys())

        try:
            self.db_manager.execute_non_query(query, values)
            return self.db_manager.get_last_inserted_rowid()
        except DatabaseError:
            raise

    def get_weather_by_date_and_location(self, target_date: date, lat: float, lon: float) -> Optional[WeatherData]:
        """Pobiera dane pogodowe dla podanej daty i lokalizacji."""
        query = "SELECT * FROM weather_data WHERE date = ? AND location_lat = ? AND location_lon = ?"
        rows = self.db_manager.execute_query(query, (target_date.isoformat(), lat, lon))
        if rows:
            return self._parse_row_to_weather_data(rows[0])
        return None

    def get_all_weather_for_location(self, lat: float, lon: float, limit: Optional[int] = None) -> List[WeatherData]:
        query = "SELECT * FROM weather_data WHERE location_lat = ? AND location_lon = ? ORDER BY date DESC"
        params = (lat, lon)
        if limit:
            query += " LIMIT ?"
            params += (limit,)

        rows = self.db_manager.execute_query(query, params)
        return [self._parse_row_to_weather_data(row) for row in rows]

    def get_all_weather_data(self) -> List[WeatherData]:
        query = "SELECT * FROM weather_data ORDER BY date DESC, location_lat, location_lon"
        rows = self.db_manager.execute_query(query)
        return [self._parse_row_to_weather_data(row) for row in rows]


    def calculate_basic_weather_stats(self, lat: float, lon: float, start_date: Optional[date] = None, end_date: Optional[date] = None) -> Dict[str, Any]:
        """
        Oblicza podstawowe statystyki pogodowe
        """
        query = """
        SELECT
            AVG(avg_temp) as avg_temperature,
            MAX(max_temp) as max_temperature,
            MIN(min_temp) as min_temperature,
            SUM(precipitation) as total_precipitation,
            AVG(humidity) as avg_humidity,
            AVG(wind_speed) as avg_wind_speed
        FROM weather_data
        WHERE location_lat = ? AND location_lon = ?
        """
        params = [lat, lon]

        if start_date:
            query += " AND date >= ?"
            params.append(start_date.isoformat())
        if end_date:
            query += " AND date <= ?"
            params.append(end_date.isoformat())

        try:
            rows = self.db_manager.execute_query(query, tuple(params))
            stats = dict(rows[0]) if rows and rows[0]['avg_temperature'] is not None else {}
            return {k: v if v is not None else 0 for k, v in stats.items()}
        except DatabaseError:
            raise
