# src/database/repositories/route_repository.py
import json
import sqlite3
from typing import List, Dict, Any, Optional, Tuple, Union
from src.database.database_manager import DatabaseManager
from src.models.route import Route
from src.common.exceptions import DatabaseError, DataParsingError
from datetime import datetime

class RouteRepository:

    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager

    def _parse_row_to_route(self, row: sqlite3.Row) -> Route:
        if row is None:
            return None
        try:
            data = dict(row)
            return Route.from_dict(data)
        except (ValueError, TypeError, KeyError, DataParsingError) as e:
            print(f"BŁĄD PARSOWANIA: Nie udało się sparsować wiersza bazy danych do obiektu Route: {e}. Dane: {dict(row)}")
            return None

    def add_route(self, route: Route) -> Optional[int]:
        route_data = route.to_dict()
        
        if route_data.get('id') == "rysy_html_extracted" or (route_data.get('id') is not None and not isinstance(route_data.get('id'), int)):
            pass
        else:
            if route_data.get('id') is not None:
                try:
                    route_data['id'] = int(route_data['id'])
                except (ValueError, TypeError):
                    route_data['id'] = None

        if 'created_at' in route_data:
            del route_data['created_at']

        columns = ', '.join(route_data.keys())
        placeholders = ', '.join(['?'] * len(route_data))
        query = f"INSERT OR REPLACE INTO routes ({columns}) VALUES ({placeholders})"
        values = tuple(route_data[key] for key in route_data.keys())

        try:
            self.db_manager.execute_non_query(query, values)
            if route.id:
                return int(route.id) if isinstance(route.id, str) and route.id.isdigit() else None
            return self.db_manager.get_last_inserted_rowid()
        except DatabaseError as e:
            print(f"Błąd podczas dodawania/aktualizowania trasy: {e}")
            raise

    def get_route_by_id(self, route_id: Union[int, str]) -> Optional[Route]:
        query = "SELECT * FROM routes WHERE id = ?"
        try:
            numeric_id = int(route_id)
        except (ValueError, TypeError):

            return None 

        rows = self.db_manager.execute_query(query, (numeric_id,))
        if rows:
            return self._parse_row_to_route(rows[0])
        return None

    def get_all_routes(self) -> List[Route]:
        query = "SELECT * FROM routes"
        rows = self.db_manager.execute_query(query)
        return [route for route in (self._parse_row_to_route(row) for row in rows) if route is not None]

    def update_route(self, route: Route) -> bool:
        route_data = route.to_dict()
        
        route_id = route_data.pop('id', None)
        if route_id is None:
            raise ValueError("ID trasy jest wymagane do aktualizacji.")
        
        try:
            route_id_int = int(route_id)
        except (ValueError, TypeError):
            raise ValueError(f"Nieprawidłowy format ID trasy do aktualizacji: {route_id}")

        if 'created_at' in route_data:
            del route_data['created_at']

        set_clauses = [f"{col} = ?" for col in route_data.keys()]
        query = f"UPDATE routes SET {', '.join(set_clauses)} WHERE id = ?"
        values = tuple(route_data[key] for key in route_data.keys()) + (route_id_int,)

        try:
            row_count = self.db_manager.execute_non_query(query, values)
            return row_count > 0
        except DatabaseError:
            raise

    def delete_route(self, route_id: Union[int, str]) -> bool:
        query = "DELETE FROM routes WHERE id = ?"
        try:
            numeric_id = int(route_id)
        except (ValueError, TypeError):
            return False

        try:
            row_count = self.db_manager.execute_non_query(query, (numeric_id,))
            return row_count > 0
        except DatabaseError:
            raise

    def find_routes_by_params(
        self,
        region: Optional[str] = None,
        min_length_km: Optional[float] = None,
        max_length_km: Optional[float] = None,
        min_difficulty: Optional[int] = None,
        max_difficulty: Optional[int] = None,
        terrain_type: Optional[str] = None,
        tags: Optional[List[str]] = None,
        include_warnings: Optional[bool] = None
    ) -> List[Route]:
     
        base_query = "SELECT * FROM routes WHERE 1=1"
        params = []
        
        if region:
            base_query += " AND region = ?"
            params.append(region)
        if min_length_km is not None:
            base_query += " AND length_km >= ?"
            params.append(min_length_km)
        if max_length_km is not None:
            base_query += " AND length_km <= ?"
            params.append(max_length_km)
        if min_difficulty is not None:
            base_query += " AND difficulty >= ?"
            params.append(min_difficulty)
        if max_difficulty is not None:
            base_query += " AND difficulty <= ?"
            params.append(max_difficulty)
        if terrain_type:
            base_query += " AND terrain_type = ?"
            params.append(terrain_type)
        
        if tags:
            for tag in tags:
                base_query += " AND tags LIKE ?"
                params.append(f'%"{tag}"%')
        
        if include_warnings is not None:
            if include_warnings:
                base_query += " AND (warnings IS NOT '[]' AND warnings IS NOT 'null' AND warnings IS NOT NULL)"
            else:
                base_query += " AND (warnings IS '[]' OR warnings IS 'null' OR warnings IS NULL)"

        try:
            rows = self.db_manager.execute_query(base_query, tuple(params))
            return [route for route in (self._parse_row_to_route(row) for row in rows) if route is not None]
        except DatabaseError:
            raise

    def find_routes_within_radius(self, center_lat: float, center_lon: float, radius_km: float) -> List[Route]:
    
        all_routes = self.get_all_routes()
        filtered_routes = []
        for route in all_routes:
            if route.start_lat is not None and route.start_lon is not None:
                dist = self._haversine_distance(
                    center_lat, center_lon, route.start_lat, route.start_lon
                )
                if dist <= radius_km:
                    filtered_routes.append(route)
        return filtered_routes

    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    
        from math import radians, sin, cos, sqrt, atan2

        R = 6371

        lat1_rad = radians(lat1)
        lon1_rad = radians(lon1)
        lat2_rad = radians(lat2)
        lon2_rad = radians(lon2)

        dlon = lon2_rad - lon1_rad
        dlat = lat2_rad - lat1_rad

        a = sin(dlat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2)**2
        c = 2 * atan2(sqrt(a), sqrt(1 - a))

        distance = R * c
        return distance
