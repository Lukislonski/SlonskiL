# src/database/database_admin.py
from typing import Dict, Any, List, Tuple, Optional
from src.database.database_manager import DatabaseManager
from src.database.backup_manager import BackupManager
from src.common.exceptions import DatabaseError

class DatabaseAdmin:
    """
    Narzędzia administracyjne do zarządzania bazą danych (statystyki, integralność, czyszczenie).
    """
    def __init__(self, db_manager: DatabaseManager, backup_manager: BackupManager):
        self.db_manager = db_manager
        self.backup_manager = backup_manager

    def display_database_stats(self):
        print("\n--- Statystyki Bazy Danych ---")
        try:
            route_count = self.db_manager.execute_query("SELECT COUNT(*) FROM routes")[0][0]
            weather_count = self.db_manager.execute_query("SELECT COUNT(*) FROM weather_data")[0][0]
            user_pref_count = self.db_manager.execute_query("SELECT COUNT(*) FROM user_preferences")[0][0]

            print(f"Liczba tras (routes): {route_count}")
            print(f"Liczba rekordów pogodowych (weather_data): {weather_count}")
            print(f"Liczba preferencji użytkowników (user_preferences): {user_pref_count}")
        except DatabaseError as e:
            print(f"Błąd podczas pobierania statystyk bazy danych: {e}")

    def check_data_integrity(self):
        print("\n--- Sprawdzanie Integralności Danych ---")
        errors_found = False

        # Sprawdzenie tras
        try:
            invalid_difficulty_routes = self.db_manager.execute_query(
                "SELECT id, name, difficulty FROM routes WHERE difficulty NOT BETWEEN 1 AND 5 AND difficulty IS NOT NULL"
            )
            if invalid_difficulty_routes:
                errors_found = True
                print("BŁĄD INTEGRALNOŚCI: Trasy z nieprawidłową trudnością (poza zakresem 1-5):")
                for row in invalid_difficulty_routes:
                    print(f"  - ID: {row['id']}, Nazwa: '{row['name']}', Trudność: {row['difficulty']}")
            
            # Sprawdzenie nulli w wymaganych polach (np. name)
            null_name_routes = self.db_manager.execute_query(
                "SELECT id FROM routes WHERE name IS NULL OR name = ''"
            )
            if null_name_routes:
                errors_found = True
                print("BŁĄD INTEGRALNOŚCI: Trasy z pustą nazwą:")
                for row in null_name_routes:
                    print(f"  - ID: {row['id']}")

        except DatabaseError as e:
            print(f"Błąd podczas sprawdzania integralności tras: {e}")
            errors_found = True

        # Sprawdzenie danych pogodowych
        try:
            invalid_weather_loc = self.db_manager.execute_query(
                "SELECT id, date, location_lat, location_lon FROM weather_data WHERE location_lat IS NULL OR location_lon IS NULL"
            )
            if invalid_weather_loc:
                errors_found = True
                print("BŁĄD INTEGRALNOŚCI: Rekordy pogodowe z brakującymi współrzędnymi lokalizacji:")
                for row in invalid_weather_loc:
                    print(f"  - ID: {row['id']}, Data: {row['date']}, Lat/Lon: ({row['location_lat']}, {row['location_lon']})")
        except DatabaseError as e:
            print(f"Błąd podczas sprawdzania integralności danych pogodowych: {e}")
            errors_found = True

        if not errors_found:
            print("Wstępne sprawdzenie integralności danych zakończone pomyślnie. Brak rażących błędów.")

    def clean_old_data(self, table_name: str, days_old: int) -> int:
        """
        Czyści stare dane z określonej tabeli.
        Obecnie tylko dla weather_data (na podstawie daty).
        """
        print(f"\n--- Czyszczenie starych danych w tabeli '{table_name}' (starszych niż {days_old} dni) ---")
        if table_name not in ["weather_data"]: 
            print(f"Błąd: Czyszczenie danych nie jest obsługiwane dla tabeli '{table_name}'.")
            return 0
        
        try:
            threshold_date = datetime.now() - datetime.timedelta(days=days_old)
            threshold_date_str = threshold_date.strftime('%Y-%m-%d')

            query = f"DELETE FROM {table_name} WHERE date < ?"
            deleted_count = self.db_manager.execute_non_query(query, (threshold_date_str,))
            print(f"Usunięto {deleted_count} rekordów z tabeli '{table_name}'.")
            return deleted_count
        except DatabaseError as e:
            print(f"Błąd podczas czyszczenia starych danych z tabeli '{table_name}': {e}")
            return 0
        except Exception as e:
            print(f"Nieoczekiwany błąd podczas czyszczenia danych: {e}")
            return 0

    def create_backup(self):
        return self.backup_manager.create_backup()

    def restore_backup(self):
        backups = self.backup_manager.list_backups()
        if not backups:
            return

        while True:
            choice_str = input("Podaj numer kopii zapasowej do przywrócenia (0 aby anulować): ")
            try:
                choice = int(choice_str)
                if choice == 0:
                    print("Anulowano przywracanie kopii zapasowej.")
                    return
                if 1 <= choice <= len(backups):
                    selected_backup_filename = backups[choice - 1]
                    confirm = input(f"Czy na pewno chcesz przywrócić bazę danych z '{selected_backup_filename}'? Spowoduje to nadpisanie bieżącej bazy. (tak/nie): ").lower()
                    if confirm == 'tak':
                        self.backup_manager.restore_backup(selected_backup_filename)
                    else:
                        print("Przywracanie anulowane przez użytkownika.")
                    break
                else:
                    print("Nieprawidłowy numer kopii zapasowej.")
            except ValueError:
                print("Nieprawidłowe dane wejściowe. Podaj numer.")
            except DatabaseError as e:
                print(f"Błąd podczas przywracania: {e}")
                break