# src/database/migration_tool.py
import csv
import json
import os
from typing import List, Dict, Any, Optional
from datetime import date, datetime
from src.database.database_manager import DatabaseManager
from src.database.repositories.route_repository import RouteRepository
from src.database.repositories.weather_repository import WeatherRepository
from src.models.route import Route
from src.models.weather_data import WeatherData
from src.common.exceptions import DatabaseError, DataParsingError

class MigrationTool:
  
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
        self.route_repo = RouteRepository(db_manager)
        self.weather_repo = WeatherRepository(db_manager)

    def migrate_routes_from_csv(self, csv_filepath: str):
      
        if not os.path.exists(csv_filepath):
            print(f"Plik CSV tras nie znaleziony: {csv_filepath}. Pomijam migrację tras.")
            return

        print(f"Rozpoczynam migrację tras z: {csv_filepath}")
        migrated_count = 0
        skipped_count = 0

        with open(csv_filepath, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                try:
                    route_id = row.get('id', '')
                    if not route_id:
                        skipped_count += 1
                        print(f"Pominięto wiersz z brakującym ID: {row}")
                        continue

                    route_data = {
                        "id": str(route_id),
                        "name": row.get('name'),
                        "region": row.get('region'),
                        "start_lat": float(row['start_lat']) if row.get('start_lat') else None,
                        "start_lon": float(row['start_lon']) if row.get('start_lon') else None,
                        "end_lat": float(row['end_lat']) if row.get('end_lat') else None,
                        "end_lon": float(row['end_lon']) if row.get('end_lon') else None,
                        "length_km": float(row['length_km']) if row.get('length_km') else None,
                        "elevation_gain": int(float(row['elevation_gain'])) if row.get('elevation_gain') else None,
                        "difficulty": int(row['difficulty']) if row.get('difficulty') else None,
                        "terrain_type": row.get('terrain_type'),
                        "tags": json.loads(row.get('tags', '[]')),
                        "description": row.get('description'),
                        "reviews": json.loads(row.get('reviews', '[]')),
                        "extracted_times": json.loads(row.get('extracted_times', '[]')),
                        "extracted_times_minutes": int(float(row['extracted_times_minutes'])) if row.get('extracted_times_minutes') and row.get('extracted_times_minutes').lower() != 'null' else None,
                        "characteristic_points": json.loads(row.get('characteristic_points', '[]')),
                        "warnings": json.loads(row.get('warnings', '[]')),
                        "extracted_coords": json.loads(row['extracted_coords']) if row.get('extracted_coords') and row.get('extracted_coords').lower() != 'null' else None,
                        "extracted_elevations": json.loads(row.get('extracted_elevations', '[]')),
                        "created_at": row.get('created_at')
                    }
                    
                    route_data_cleaned = {k: v for k, v in route_data.items() if v is not None or k in ['description']}
                    route = Route(**route_data_cleaned)
                    self.route_repo.add_route(route)
                    migrated_count += 1
                except (ValueError, KeyError, DataParsingError, json.JSONDecodeError) as e:
                    skipped_count += 1
                    print(f"Błąd migracji wiersza tras: {row}. Błąd: {e}")
                except DatabaseError as e:
                    skipped_count += 1
                    print(f"Błąd bazy danych podczas migracji trasy {row.get('id')}: {e}")

        print(f"Zakończono migrację tras. Zmigrowano: {migrated_count}, Pominięto: {skipped_count}")


    def migrate_weather_from_csv(self, csv_filepath: str):
     
        if not os.path.exists(csv_filepath):
            print(f"Plik CSV pogody nie znaleziony: {csv_filepath}. Pomijam migrację pogody.")
            return

        print(f"Rozpoczynam migrację pogody z: {csv_filepath}")
        migrated_count = 0
        skipped_count = 0

        with open(csv_filepath, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                print(f"DEBUG: Surowy wiersz z CSV: {row}") # LINIA DIAGNOSTYCZNA
                
                location_id_str = row.get('location_id', '')
                
                try:
                    lat, lon = map(float, location_id_str.split(','))
                    
                    weather = WeatherData(
                        date=date.fromisoformat(row['date']),
                        location_lat=lat,
                        location_lon=lon,
                        avg_temp=float(row['avg_temp']) if row.get('avg_temp') else None,
                        min_temp=float(row['min_temp']) if row.get('min_temp') else None,
                        max_temp=float(row['max_temp']) if row.get('max_temp') else None,
                        precipitation=float(row['precipitation']) if row.get('precipitation') else None,
                        sunshine_hours=float(row['sunshine_hours']) if row.get('sunshine_hours') else None,
                        cloud_cover=int(row['cloud_cover']) if row.get('cloud_cover') else None,
                        wind_speed=float(row['wind_speed']) if row.get('wind_speed') else None,
                        weather_description=row.get('weather_description'),
                        humidity=int(row['humidity']) if row.get('humidity') else None,
                        pressure=int(row['pressure']) if row.get('pressure') else None
                    )
                    self.weather_repo.add_weather_data(weather)
                    migrated_count += 1
                except (ValueError, KeyError, DataParsingError, IndexError) as e:
                    skipped_count += 1
                    print(f"Błąd migracji wiersza pogody: nieprawidłowy format location_id lub inne pole. Wiersz: {row}. Błąd: {e}")
                except DatabaseError as e:
                    skipped_count += 1
                    print(f"Błąd bazy danych podczas migracji pogody {row.get('date')} dla {location_id_str}: {e}")

        print(f"Zakończono migrację pogody. Zmigrowano: {migrated_count}, Pominięto: {skipped_count}")

