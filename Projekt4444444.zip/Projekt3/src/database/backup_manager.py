# src/database/backup_manager.py
import shutil
import os
from datetime import datetime
from typing import List, Optional
from src.common.exceptions import DatabaseError

class BackupManager:
    def __init__(self, db_path: str, backup_dir: str):
        self.db_path = db_path
        self.backup_dir = backup_dir
        self._ensure_backup_dir_exists()

    def _ensure_backup_dir_exists(self):
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir, exist_ok=True)
            print(f"Utworzono katalog kopii zapasowych: {self.backup_dir}")

    def create_backup(self) -> Optional[str]:
        if not os.path.exists(self.db_path):
            print(f"Błąd: Główna baza danych nie istnieje w '{self.db_path}'. Nie można utworzyć kopii zapasowej.")
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"routes_backup_{timestamp}.db"
        backup_path = os.path.join(self.backup_dir, backup_filename)

        try:
            shutil.copy2(self.db_path, backup_path)
            print(f"Pomyślnie utworzono kopię zapasową: '{backup_path}'")
            return backup_path
        except Exception as e:
            raise DatabaseError(f"Błąd podczas tworzenia kopii zapasowej bazy danych: {e}", original_exception=e)

    def restore_backup(self, backup_filename: str) -> bool:
        source_backup_path = os.path.join(self.backup_dir, backup_filename)

        if not os.path.exists(source_backup_path):
            print(f"Błąd: Plik kopii zapasowej nie istnieje w '{source_backup_path}'.")
            return False

        try:
            shutil.copy2(source_backup_path, self.db_path)
            print(f"Pomyślnie przywrócono bazę danych z '{source_backup_path}' do '{self.db_path}'.")
            return True
        except Exception as e:
            raise DatabaseError(f"Błąd podczas przywracania kopii zapasowej bazy danych: {e}", original_exception=e)

    def list_backups(self) -> List[str]:
        self._ensure_backup_dir_exists()
        backups = [f for f in os.listdir(self.backup_dir) if f.startswith("routes_backup_") and f.endswith(".db")]
        backups.sort(reverse=True)
        
        if not backups:
            print("Brak dostępnych kopii zapasowych.")
        else:
            print("\nDostępne kopie zapasowe:")
            for i, backup_name in enumerate(backups):
                print(f"{i+1}. {backup_name}")
        return backups
