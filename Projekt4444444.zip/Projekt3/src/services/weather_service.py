# src/services/weather_service.py
import requests
from typing import Optional, Dict, Any
from datetime import date, datetime
from src.models.weather_data import WeatherData

class WeatherService:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"
        if not self.api_key:
            print("[WeatherService] OSTRZEŻENIE: Brak klucza API OpenWeatherMap. Funkcjonalność pogodowa będzie ograniczona.")
        print(f"[WeatherService] Zainicjowano. Używam klucza API (pierwsze 5 znaków): {self.api_key[:5]}*****")


    def get_current_weather(self, lat: float, lon: float) -> Optional[WeatherData]:

        if not self.api_key:
            return None

        params = {
            'lat': lat,
            'lon': lon,
            'appid': self.api_key,
            'units': 'metric', 
            'lang': 'pl'       
        }
        try:
            response = requests.get(self.base_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            weather_desc = data['weather'][0]['description'] if data['weather'] else None
            main_data = data['main']
            wind_data = data['wind']
            clouds_data = data['clouds']

            return WeatherData(
                date=date.today(),
                location_lat=lat,
                location_lon=lon,
                avg_temp=main_data.get('temp'),
                min_temp=main_data.get('temp_min'),
                max_temp=main_data.get('temp_max'),
                precipitation=data.get('rain', {}).get('1h', 0.0) + data.get('snow', {}).get('1h', 0.0),
                sunshine_hours=None,
                cloud_cover=clouds_data.get('all'),
                wind_speed=wind_data.get('speed'),
                weather_description=weather_desc,
                humidity=main_data.get('humidity'),
                pressure=main_data.get('pressure')
            )
        except requests.exceptions.RequestException as e:
            print(f"[WeatherService] Błąd podczas pobierania pogody z API: {e}")
        except (KeyError, IndexError) as e:
            print(f"[WeatherService] Błąd parsowania odpowiedzi API OpenWeatherMap: {e}. Odpowiedź: {data}")
        return None
