# src/data_handlers/route_data_manager.py
from typing import List
from src.models.route import Route
from src.database.repositories.route_repository import RouteRepository

class RouteDataManager:
    def __init__(self, route_repository: RouteRepository):
        self.route_repository = route_repository

    def load_routes(self) -> List[Route]:
        try:
            routes = self.route_repository.get_all_routes()
            print(f"Załadowano {len(routes)} tras z bazy danych.")
            return routes
        except Exception as e:
            print(f"Błąd podczas ładowania tras z bazy danych: {e}")
            return []