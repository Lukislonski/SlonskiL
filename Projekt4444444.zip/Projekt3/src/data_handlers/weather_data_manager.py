# src/data_handlers/weather_data_manager.py
from typing import List
from src.models.weather_data import WeatherData
from src.database.repositories.weather_repository import WeatherRepository

class WeatherDataManager:
    def __init__(self, weather_repository: WeatherRepository):
        self.weather_repository = weather_repository

    def load_all_weather_data(self) -> List[WeatherData]:
        print("Ładowanie WSZYSTKICH danych pogodowych z bazy danych (może być wolne dla dużej bazy)...")
        try:

            return self.weather_repository.get_all_weather_data()

        except Exception as e:
            print(f"Błąd podczas ładowania wszystkich danych pogodowych z bazy danych: {e}")
            return []