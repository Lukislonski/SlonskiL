# src/analyzers/text_processor.py
import re
from typing import Dict, Any, Optional, List, Tuple, Union
from math import radians, sin, cos, sqrt, atan2

class TextProcessor:
    def __init__(self):
        self.time_pattern = re.compile(
            r'(\d+)\s*(?:godz|godzin|h)(?:\s*(\d+)\s*(?:min|minut))?|'
            r'(\d+)\s*(?:min|minut)',
            re.IGNORECASE
        )
        self.coord_pattern = re.compile(
            r'([NS])(\d+)(?:°(\d+)(?:′(\d+)(?:″)?)?)?\s*([EW])(\d+)(?:°(\d+)(?:′(\d+)(?:″)?)?)?|'
            r'(\d{1,3}\.\d+)\s*([NS]),?\s*(\d{1,3}\.\d+)\s*([EW])',
        )
        self.elevation_pattern = re.compile(r'(\d+)\s*m(?:\s*n\.p\.m\.)?', re.IGNORECASE)
        self.characteristic_points_pattern = re.compile(r'(?:schronisko|szczyt|jezioro|wodospad|ruiny|jaskinia)', re.IGNORECASE)
        self.warnings_pattern = re.compile(r'(?:uwaga|ostrzeżenie|niebezpiecznie|ślisk(?:o|a)|lawiny|zamknięt(?:e|a)|remont)', re.IGNORECASE)

    def process_route_text_full(self, text: str) -> Dict[str, Any]:
        if not text:
            text = ""

        extracted_times = self.extract_times(text)
        extracted_times_minutes = None
        if extracted_times:
            extracted_times_minutes = self.convert_time_to_minutes(extracted_times[0])
        
        extracted_coords_raw = self.standardize_coordinates(text)
        start_lat, start_lon = None, None
        
        if isinstance(extracted_coords_raw, str):
            parsed_lat, parsed_lon = self._parse_coord_string_to_float_pair(extracted_coords_raw)
            start_lat = parsed_lat
            start_lon = parsed_lon
        
        extracted_elevations_raw = self.extract_elevations(text)
        extracted_elevations_int = []
        for elev_str in extracted_elevations_raw:
            try:
                num_match = re.search(r'(\d+)', elev_str)
                if num_match:
                    extracted_elevations_int.append(int(num_match.group(1)))
            except ValueError:
                pass

        return {
            "extracted_times": extracted_times,
            "extracted_times_minutes": extracted_times_minutes,
            "characteristic_points": self.identify_characteristic_points(text),
            "warnings": self.recognize_warnings(text),
            "extracted_coords": extracted_coords_raw,
            "start_lat": start_lat,
            "start_lon": start_lon,
            "extracted_elevations": extracted_elevations_int
        }

    def _parse_coord_string_to_float_pair(self, coord_str: str) -> Tuple[Optional[float], Optional[float]]:
        """
        Parsuje string współrzędnych (DMS lub dziesiętne) na parę float (lat, lon).
        """
        dms_match = re.search(
            r'([NS])(\d+)(?:°(\d+)(?:′(\d+)(?:″)?)?)?\s*([EW])(\d+)(?:°(\d+)(?:′(\d+)(?:″)?)?)?',
            coord_str, re.IGNORECASE
        )
        if dms_match:
            try:
                lat_dir, lat_deg_str, lat_min_str, lat_sec_str = dms_match.group(1, 2, 3, 4)
                lat_deg = float(lat_deg_str)
                lat_min = float(lat_min_str) if lat_min_str else 0.0
                lat_sec = float(lat_sec_str) if lat_sec_str else 0.0
                lat_val = lat_deg + lat_min/60 + lat_sec/3600
                if lat_dir.upper() == 'S':
                    lat_val *= -1

                lon_dir, lon_deg_str, lon_min_str, lon_sec_str = dms_match.group(5, 6, 7, 8)
                lon_deg = float(lon_deg_str)
                lon_min = float(lon_min_str) if lon_min_str else 0.0
                lon_sec = float(lon_sec_str) if lon_sec_str else 0.0
                lon_val = lon_deg + lon_min/60 + lon_sec/3600
                if lon_dir.upper() == 'W':
                    lon_val *= -1
                
                print(f"  [DEBUG - TextProcessor] Parsowano DMS na floaty: ({lat_val:.6f}, {lon_val:.6f}) z '{coord_str}'")
                return lat_val, lon_val
            except (ValueError, TypeError) as e:
                print(f"  [DEBUG - TextProcessor] Błąd parsowania DMS '{coord_str}': {e}")
                return None, None

        decimal_match = re.search(
            r'(\d{1,3}\.\d+)\s*([NS]),?\s*(\d{1,3}\.\d+)\s*([EW])',
            coord_str, re.IGNORECASE
        )
        if decimal_match:
            try:
                lat_val = float(decimal_match.group(1))
                lat_dir = decimal_match.group(2)
                lon_val = float(decimal_match.group(3))
                lon_dir = decimal_match.group(4)

                if lat_dir.upper() == 'S':
                    lat_val *= -1
                if lon_dir.upper() == 'W':
                    lon_val *= -1
                print(f"  [DEBUG - TextProcessor] Parsowano dziesiętne floaty: ({lat_val:.6f}, {lon_val:.6f}) z '{coord_str}'")
                return lat_val, lon_val
            except (ValueError, TypeError) as e:
                print(f"  [DEBUG - TextProcessor] Błąd parsowania dziesiętnego '{coord_str}': {e}")
                return None, None
        
        print(f"  [DEBUG - TextProcessor] Nie udało się sparsować współrzędnych na parę float: '{coord_str}'")
        return None, None


    def extract_times(self, text: str) -> List[str]:
        times = []
        for match in self.time_pattern.finditer(text):
            times.append(match.group(0).strip())
        return times if times else []

    def convert_time_to_minutes(self, time_str: str) -> Optional[int]:
        match = self.time_pattern.match(time_str)
        if match:
            total_minutes = 0
            hours_g1 = match.group(1)
            minutes_g2 = match.group(2)
            minutes_g3 = match.group(3)

            if hours_g1:
                total_minutes += int(hours_g1) * 60
                if minutes_g2:
                    total_minutes += int(minutes_g2)
            elif minutes_g3:
                total_minutes += int(minutes_g3)
            return total_minutes
        return None


    def standardize_coordinates(self, text: str) -> Optional[str]:
        match = self.coord_pattern.search(text)
        if match:
            coord_str = match.group(0).strip()
            print(f"  [DEBUG - TextProcessor] Wykryto współrzędne jako sformatowany string: '{coord_str}' z tekstu: '{text[:50]}...'")
            return coord_str
        
        print(f"  [DEBUG - TextProcessor] Nie wykryto współrzędnych w tekście: '{text[:50]}...'")
        return None


    def extract_elevations(self, text: str) -> List[str]:
        elevations = []
        for match in self.elevation_pattern.finditer(text):
            elevations.append(match.group(0).strip())
        print(f"  [DEBUG - TextProcessor] Wykryto elewacje: {elevations} z tekstu: '{text[:50]}...'")
        return elevations if elevations else []

    def identify_characteristic_points(self, text: str) -> List[str]:
        points = list(set(self.characteristic_points_pattern.findall(text)))
        print(f"  [DEBUG - TextProcessor] Wykryto punkty charakterystyczne: {points} z tekstu: '{text[:50]}...'")
        return points if points else []

    def recognize_warnings(self, text: str) -> List[str]:
        warnings = list(set(self.warnings_pattern.findall(text)))
        print(f"  [DEBUG - TextProcessor] Wykryto ostrzeżenia: {warnings} z tekstu: '{text[:50]}...'")
        return warnings if warnings else []

