# src/analyzers/review_analyzer.py
from typing import Dict, Any, List, Optional

class ReviewAnalyzer:
    def __init__(self):
        self.positive_keywords = ["wspaniałe", "piękne", "super", "polecam", "świetne", "cudowne", "rewelacyjne"]
        self.negative_keywords = ["trudno", "kiepskie", "słabe", "fatalne", "problemy", "trudna", "deszcz", "zimno"]
        
        self.aspect_keywords = {
            "widoki": ["widok", "krajobraz", "sceneria", "panorama"],
            "pogoda": ["pogoda", "słońce", "deszcz", "śnieg", "wiatr", "upał", "zimno"],
            "oznakowanie": ["oznakowanie", "szlak", "mapa", "droga", "ścieżka"],
            "trudność": ["trudność", "wymagająca", "łatwa", "stromo", "kondycja"],
            "atrakcje": ["atrakcja", "ciekawe miejsce", "coś zobaczyć", "punkt widokowy"]
        }

    def analyze_review(self, review_text: str) -> Dict[str, Any]:
    
        text_lower = review_text.lower()
        
        sentiment_score = 0.0
        found_keywords = []

        for word in self.positive_keywords:
            if word in text_lower:
                sentiment_score += 1
                found_keywords.append(word)
        for word in self.negative_keywords:
            if word in text_lower:
                sentiment_score -= 1
                found_keywords.append(word)
        
        if sentiment_score > 0:
            sentiment_score = min(1.0, sentiment_score / 3.0)
        elif sentiment_score < 0:
            sentiment_score = max(-1.0, sentiment_score / 3.0)

        return {
            "sentiment_score": sentiment_score,
            "keywords": found_keywords,
            "aspect_mentions": self._get_aspect_mentions_from_keywords(found_keywords)
        }

    def _get_aspect_mentions_from_keywords(self, keywords: List[str]) -> Dict[str, int]:
    
        aspects = {aspect: 0 for aspect in self.aspect_keywords.keys()}
        for kw in keywords:
            for aspect, terms in self.aspect_keywords.items():
                if any(term in kw for term in terms):
                    aspects[aspect] += 1
        return aspects
    
    def aggregate_sentiments_by_aspect(self, reviews: List[Dict[str, Any]]) -> Dict[str, float]:
 
        aspect_sentiments_sum: Dict[str, float] = {aspect: 0.0 for aspect in self.aspect_keywords.keys()}
        aspect_counts: Dict[str, int] = {aspect: 0 for aspect in self.aspect_keywords.keys()}

        for review in reviews:
            review_sentiment = review.get('sentiment_score')
            review_keywords = review.get('keywords', [])

            if review_sentiment is not None:
                for kw in review_keywords:
                    kw_lower = kw.lower()
                    for aspect, terms in self.aspect_keywords.items():
                        if any(term in kw_lower for term in terms):
                            aspect_sentiments_sum[aspect] += review_sentiment
                            aspect_counts[aspect] += 1
        
        aggregated_sentiments = {}
        for aspect in self.aspect_keywords.keys():
            if aspect_counts[aspect] > 0:
                aggregated_sentiments[aspect] = aspect_sentiments_sum[aspect] / aspect_counts[aspect]
            else:
                aggregated_sentiments[aspect] = 0.0
        
        return aggregated_sentiments
