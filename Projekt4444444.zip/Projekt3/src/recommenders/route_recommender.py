# src/recommenders/route_recommender.py
import pandas as pd
from typing import List, Dict, Any, Optional
from datetime import date, timedelta

from src.models.route import Route
from src.models.weather_data import WeatherData
from src.models.user_preferences import UserPreferences
from src.extractors.web_data_collector import WebDataCollector
from src.config.api_keys import OPENWEATHER_API_KEY
from src.services.weather_service import WeatherService
from src.analyzers.review_analyzer import ReviewAnalyzer

class RouteRecommender:
 
    def __init__(self, routes: List[Route], historical_weather_data: List[WeatherData]):
        self.routes = routes
        self.historical_weather_df = self._create_weather_dataframe(historical_weather_data)
        self.weather_service = WeatherService(OPENWEATHER_API_KEY)
        self.review_analyzer = ReviewAnalyzer()


    def _create_weather_dataframe(self, weather_data: List[WeatherData]) -> pd.DataFrame:

        if not weather_data:
            print("  [RouteRecommender] Brak danych pogodowych (historycznych/plikowych) do utworzenia DataFrame.")
            return pd.DataFrame()
        
        data_dicts = [wd.to_dict() for wd in weather_data]
        df = pd.DataFrame(data_dicts)
        
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
        
        return df

    def generate_recommendations(self, preferences: UserPreferences) -> List[Dict[str, Any]]:

        print("  [RouteRecommender] Rozpoczynam generowanie rekomendacji ---")
        
        print(f"  [RouteRecommender] Preferencje użytkownika: "
              f"Temp min={preferences.preferred_temp_min}°C, Temp max={preferences.preferred_temp_max}°C, "
              f"Opady<={preferences.max_precipitation}mm, "
              f"Trudność<={preferences.max_difficulty}, "
              f"Długość min={preferences.min_length_km}km, Długość max={preferences.max_length_km}km, "
              f"Teren='{', '.join(preferences.preferred_terrain_types)}', "
              f"Tagi='{', '.join(preferences.preferred_tags)}', "
              f"Ostrzeżenia={preferences.include_warnings}")

        filtered_routes_objects = self.routes
        print(f"  [RouteRecommender] Początkowa liczba tras do filtrowania: {len(filtered_routes_objects)}.")

        if preferences.preferred_terrain_types:
            initial_count = len(filtered_routes_objects)
            filtered_routes_objects = [
                route for route in filtered_routes_objects
                if route.terrain_type and route.terrain_type.lower() in preferences.preferred_terrain_types
            ]
            print(f"  [RouteRecommender] Po filtracji terenu: {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).")

        if preferences.max_difficulty is not None:
            initial_count = len(filtered_routes_objects)
            filtered_routes_objects = [
                route for route in filtered_routes_objects
                if route.difficulty is not None and route.difficulty <= preferences.max_difficulty
            ]
            print(f"  [RouteRecommender] Po filtracji trudności: {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).")
            if len(filtered_routes_objects) == 0:
                print("  [RouteRecommender] WAŻNE: Wszystkie trasy zostały odrzucone przez filtr trudności. Sprawdź dane tras i preferencje.")

        if preferences.min_length_km is not None:
            initial_count = len(filtered_routes_objects) 
            filtered_routes_objects = [
                route for route in filtered_routes_objects
                if route.length_km is not None and route.length_km >= preferences.min_length_km
            ]
            print(f"  [RouteRecommender] Po filtracji min długości: {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).") 
        
        if preferences.max_length_km is not None:
            initial_count = len(filtered_routes_objects) 
            filtered_routes_objects = [
                route for route in filtered_routes_objects
                if route.length_km is not None and route.length_km <= preferences.max_length_km
            ]
            print(f"  [RouteRecommender] Po filtracji max długości: {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).")

        if preferences.preferred_tags:
            initial_count = len(filtered_routes_objects)
            filtered_routes_objects = [
                route for route in filtered_routes_objects
                if any(tag.lower() in [rt.lower() for rt in route.tags] for tag in preferences.preferred_tags)
            ]
            print(f"  [RouteRecommender] Po filtracji tagów: {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).") 

        if not preferences.include_warnings:
            initial_count = len(filtered_routes_objects)
            filtered_routes_objects = [
                route for route in filtered_routes_objects
                if not route.warnings
            ]
            print(f"  [RouteRecommender] Po filtracji ostrzeżeń (nie włączono): {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).") 

        if preferences.preferred_temp_min is not None or \
           preferences.preferred_temp_max is not None or \
           preferences.max_precipitation is not None:
            
            initial_count = len(filtered_routes_objects)
            unique_locations = set()
            for route in filtered_routes_objects:
                if route.start_lat and route.start_lon:
                    unique_locations.add((route.start_lat, route.start_lon))
            
            current_weather_data: Dict[Tuple[float, float], WeatherData] = {}
            for lat, lon in unique_locations:
                today = date.today()
                
                current_forecast = self.weather_service.get_current_weather(lat, lon)
                if current_forecast:
                    current_weather_data[(lat, lon)] = current_forecast
                else:
                    print(f"  [RouteRecommender] Brak bieżącej pogody z API dla ({lat:.2f}, {lon:.2f}).")
                    closest_historical_weather = self._get_closest_historical_weather(lat, lon, today)
                    if closest_historical_weather:
                        current_weather_data[(lat, lon)] = closest_historical_weather
                        print(f"  [RouteRecommender] Używam historycznej pogody dla ({lat:.2f}, {lon:.2f}) z dnia {closest_historical_weather.date}.")
            
            routes_after_weather_filter = []
            for route in filtered_routes_objects:
                route_loc = (route.start_lat, route.start_lon)
                if route_loc in current_weather_data:
                    weather = current_weather_data[route_loc]
                    
                    temp_ok = True
                    if preferences.preferred_temp_min is not None and weather.avg_temp is not None and weather.avg_temp < preferences.preferred_temp_min:
                        temp_ok = False
                    if preferences.preferred_temp_max is not None and weather.avg_temp is not None and weather.avg_temp > preferences.preferred_temp_max:
                        temp_ok = False
                    
                    precipitation_ok = True
                    if preferences.max_precipitation is not None and weather.precipitation is not None and weather.precipitation > preferences.max_precipitation:
                        precipitation_ok = False

                    if temp_ok and precipitation_ok:
                        route.current_weather_temp = weather.avg_temp
                        route.current_weather_desc = weather.weather_description
                        route.current_weather_precip = weather.precipitation
                        routes_after_weather_filter.append(route)
                    else:
                        print(f"  [RouteRecommender] Trasa '{route.name}' odrzucona przez warunki pogodowe: Temp ok={temp_ok}, Opady ok={precipitation_ok}")
                else:
                    print(f"  [RouteRecommender] Brak danych pogodowych dla trasy '{route.name}'. Pomijam w filtracji pogodowej.")
            filtered_routes_objects = routes_after_weather_filter
            print(f"  [RouteRecommender] Po filtracji pogody: {len(filtered_routes_objects)} tras (odrzucono {initial_count - len(filtered_routes_objects)}).")
        
        final_recommendations_dicts = []
        for route_obj in filtered_routes_objects:
            route_obj.avg_review_rating = self._calculate_average_review_rating(route_obj.reviews)
            route_obj.sentiment_score = self._calculate_average_sentiment(route_obj.reviews)
            route_obj.comfort_index = self._calculate_comfort_index(route_obj)

            route_obj.aspect_mentions = self._count_aspect_mentions(route_obj.reviews)
            
            final_recommendations_dicts.append(route_obj.to_dict())


        final_recommendations_dicts.sort(key=lambda x: x.get('comfort_index', -1) if x.get('comfort_index') is not None else -1, reverse=True)

        print(f"  [RouteRecommender] Zakończono generowanie rekomendacji. Łącznie: {len(final_recommendations_dicts)} tras.")
        return final_recommendations_dicts

    def _get_closest_historical_weather(self, lat: float, lon: float, target_date: date) -> Optional[WeatherData]:
        if self.historical_weather_df.empty or 'date' not in self.historical_weather_df.columns:
            return None
        
        loc_weather = self.historical_weather_df[
            (self.historical_weather_df['location_lat'] == lat) &
            (self.historical_weather_df['location_lon'] == lon)
        ].copy()

        if loc_weather.empty:
            return None

        loc_weather['day_diff'] = (loc_weather['date'] - pd.to_datetime(target_date)).dt.days.abs()
        closest_row = loc_weather.loc[loc_weather['day_diff'].idxmin()]
        
        return WeatherData.from_dict(closest_row.to_dict())


    def _calculate_average_review_rating(self, reviews: List[Dict[str, Any]]) -> float:
        if not reviews:
            return 0.0
        ratings = [r.get('rating_normalized') for r in reviews if r.get('rating_normalized') is not None]
        return sum(ratings) / len(ratings) if ratings else 0.0

    def _calculate_average_sentiment(self, reviews: List[Dict[str, Any]]) -> float:
        if not reviews:
            return 0.0
        sentiments = [r.get('sentiment_score') for r in reviews if r.get('sentiment_score') is not None]
        return sum(sentiments) / len(sentiments) if sentiments else 0.0
    
    def _calculate_comfort_index(self, route: Route) -> float:
        comfort = 10.0

        if route.difficulty is not None:
            comfort -= (route.difficulty - 1) * 0.5

        if route.length_km is not None:
            if route.length_km < 5: comfort += 0.5
            elif route.length_km > 20: comfort -= 1.0

        if route.elevation_gain is not None:
            if route.elevation_gain > 500: comfort -= 1.0
            if route.elevation_gain > 1000: comfort -= 1.0

        if route.warnings:
            comfort -= len(route.warnings) * 0.5

        if route.avg_review_rating is not None:
            comfort += (route.avg_review_rating - 0.5) * 2

        return max(0.0, min(10.0, comfort))

    def _count_aspect_mentions(self, reviews: List[Dict[str, Any]]) -> Dict[str, int]:

        aspect_counts = {
            "widoki": 0,
            "pogoda": 0,
            "oznakowanie": 0,
            "trudność": 0,
            "atrakcje": 0
        }
        
        for review in reviews:
            keywords = review.get('keywords', [])
            for kw in keywords:
                kw_lower = kw.lower()
                if any(term in kw_lower for term in ['widok', 'krajobraz', 'sceneria', 'piękno']):
                    aspect_counts['widoki'] += 1
                if any(term in kw_lower for term in ['pogoda', 'słońce', 'deszcz', 'śnieg', 'wiatr', 'upał', 'zimno']):
                    aspect_counts['pogoda'] += 1
                if any(term in kw_lower for term in ['oznakowanie', 'szlak', 'mapa', 'orientacja']):
                    aspect_counts['oznakowanie'] += 1
                if any(term in kw_lower for term in ['trudność', 'wymagająca', 'łatwa', 'ciężka', 'stromo']):
                    aspect_counts['trudność'] += 1
                if any(term in kw_lower for term in ['atrakcja', 'ciekawe miejsce', 'coś zobaczyć']):
                    aspect_counts['atrakcje'] += 1
        
        return aspect_counts
