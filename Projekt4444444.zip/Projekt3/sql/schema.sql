-- sql/schema.sql

-- Tabela tras
CREATE TABLE IF NOT EXISTS routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    region TEXT,
    start_lat REAL,
    start_lon REAL,
    end_lat REAL,
    end_lon REAL,
    length_km REAL,
    elevation_gain INTEGER,
    difficulty INTEGER CHECK (difficulty BETWEEN 1 AND 5),
    terrain_type TEXT,
    tags TEXT,
    description TEXT,
    extracted_times TEXT,
    extracted_times_minutes INTEGER,
    characteristic_points TEXT,
    warnings TEXT,
    extracted_coords TEXT,
    extracted_elevations TEXT,
    reviews TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela danych pogodowych
CREATE TABLE IF NOT EXISTS weather_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date DATE NOT NULL,
    location_lat REAL NOT NULL,
    location_lon REAL NOT NULL,
    avg_temp REAL,
    min_temp REAL,
    max_temp REAL,
    precipitation REAL,
    sunshine_hours REAL,
    cloud_cover INTEGER,
    wind_speed REAL,
    weather_description TEXT,
    humidity REAL,
    pressure REAL,
    UNIQUE(date, location_lat, location_lon)
);

-- Tabela preferencji użytkownika
CREATE TABLE IF NOT EXISTS user_preferences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_name TEXT DEFAULT 'default',
    preferred_temp_min REAL,
    preferred_temp_max REAL,
    max_precipitation REAL,
    max_difficulty INTEGER,
    max_length_km REAL,
    min_length_km REAL,
    preferred_terrain_types TEXT,
    preferred_tags TEXT, 
    include_warnings INTEGER,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_routes_region ON routes(region);
CREATE INDEX IF NOT EXISTS idx_routes_difficulty ON routes(difficulty);
CREATE INDEX IF NOT EXISTS idx_weather_date_loc ON weather_data(date, location_lat, location_lon);
CREATE INDEX IF NOT EXISTS idx_user_prefs_user_name ON user_preferences(user_name);