from functools import reduce

def filter_routes(routes, min_length=0, max_difficulty=3, region=None):
    return list(filter(
        lambda r: float(r["length_km"]) >= min_length and 
                  int(r["difficulty"]) <= max_difficulty and 
                  (region is None or r["region"] == region),
        routes
    ))

def compute_weather_stats(weather_data, location_id):
    data = list(filter(lambda w: w["location_id"] == location_id, weather_data))
    
    if not data:
        return None

    avg_temp = sum(map(lambda x: float(x["avg_temp"]), data)) / len(data)
    total_precip = reduce(lambda acc, x: acc + float(x["precipitation"]), data, 0.0)
    sunny_days = len([x for x in data if float(x["sunshine_hours"]) >= 8])

    return {
        "location_id": location_id,
        "avg_temp": round(avg_temp, 2),
        "total_precip": round(total_precip, 2),
        "sunny_days": sunny_days
    }

def get_difficulty_summary(routes):
    return {level: len(list(filter(lambda r: int(r["difficulty"]) == level, routes)))
            for level in range(1, 6)}
