from data_loader import load_csv, save_csv
from data_processor import filter_routes, compute_weather_stats, get_difficulty_summary
import os

def main():
    base_path = os.path.join("..", "data")
    routes = load_csv(os.path.join(base_path, "trasy.csv"))
    weather = load_csv(os.path.join(base_path, "pogoda.csv"))

    print("\n Wszystkie dostępne trasy:")
    for r in routes:
        print(
            f" - {r['name']} ({r['region']})\n"
            f"    Start: ({r['start_lat']}, {r['start_lon']}) | Koniec: ({r['end_lat']}, {r['end_lon']})\n"
            f"    Długość: {r['length_km']} km, Przewyższenie: {r['elevation_gain']} m\n"
            f"    Trudność: {r['difficulty']}, Teren: {r['terrain_type']}, Tag: {r['tags']}"
        )
        print()

    filtered = filter_routes(routes, min_length=5, max_difficulty=2, region="Kaszuby")

    print("\n Filtrowane trasy (Kaszuby, min 5km, trudność ≤ 2):")
    for r in filtered:
        print(
            f" - {r['name']} | {r['length_km']} km | Przewyższenie: {r['elevation_gain']} m | "
            f"Teren: {r['terrain_type']} | Trudność: {r['difficulty']}"
        )

    locations = {r["region"] for r in routes}
    stats = [compute_weather_stats(weather, loc) for loc in locations if compute_weather_stats(weather, loc)]

    print("\n Statystyki pogodowe:")
    for s in stats:
        print(f" - {s['location_id']}: Śr. temp {s['avg_temp']}°C, Opady {s['total_precip']} mm, Słoneczne dni: {s['sunny_days']}")

    print("\n Podsumowanie trudności tras:")
    difficulty_counts = get_difficulty_summary(routes)
    for diff, count in difficulty_counts.items():
        print(f" - Trudność {diff}: {count} tras")

    save_csv(filtered, os.path.join(base_path, "filtered_routes.csv"), fieldnames=routes[0].keys())

if __name__ == "__main__":
    main()
